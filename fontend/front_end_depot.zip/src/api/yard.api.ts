import apiClient from './axios';
import { API_ENDPOINTS } from './endpoints';
import { ApiResponse } from '../types/common';

export const yardApi = {
  forkliftMove: async (jobId: string, targetBlock: string, targetBay: number, targetRow: number, targetTier: number) => {
    const res = await apiClient.post<ApiResponse<any>>(API_ENDPOINTS.DEPOT_JOBS.FORKLIFT_MOVE, { jobId, targetBlock, targetBay, targetRow, targetTier });
    return res.data;
  },
};

