import React, { useState } from 'react';
import {
  MOCK_CUSTOMERS,
  MOCK_CUSTOMER_USERS,
  MOCK_DRIVERS,
  MOCK_VEHICLES,
  MOCK_BOOKINGS,
  MOCK_CUSTOMER_CONTAINERS,
  MOCK_GATEIN_REGISTRATIONS
} from '../data/customerPortalMockData';
import {
  CustomerCompany,
  CustomerUser,
  DriverRecord,
  VehicleRecord,
  CustomerBooking,
  CustomerContainerItem,
  GateInRegistration,
  PortalRole
} from '../types/customerPortal';

// Component Views
import { CustomerListView } from '../components/CustomerListView';
import { CustomerAccountProfileTab } from '../components/CustomerAccountProfileTab';
import { CustomerAccountsTab } from '../components/CustomerAccountsTab';
import { CustomerDashboardView } from '../components/CustomerDashboardView';
import { GateInListView } from '../components/GateInListView';
import { GateInOnlineWizard } from '../components/GateInOnlineWizard';
import { CustomerBookingView } from '../components/CustomerBookingView';
import { CustomerContainerView } from '../components/CustomerContainerView';
import { CustomerDriverManagementView } from '../components/CustomerDriverManagementView';
import { CustomerVehicleManagementView } from '../components/CustomerVehicleManagementView';
import { GateInQRCodeModal } from '../components/GateInQRCodeModal';
import { GateInDetailModal } from '../components/GateInDetailModal';

import {
  ArrowLeft,
  LayoutDashboard,
  FileText,
  Box,
  Truck,
  Car,
  Building2,
  Users,
  UserCheck,
  Key
} from 'lucide-react';

export const CustomerPage: React.FC = () => {
  // Navigation mode: 'LIST' (shows only customer directory) or 'DETAIL' (shows clicked customer's account & workspace)
  const [pageView, setPageView] = useState<'LIST' | 'DETAIL'>('LIST');

  // Master state
  const [customers, setCustomers] = useState<CustomerCompany[]>(MOCK_CUSTOMERS);
  const [currentCustomerId, setCurrentCustomerId] = useState<string>(MOCK_CUSTOMERS[0].id);
  const [currentRole, setCurrentRole] = useState<PortalRole>('CUSTOMER_ADMIN');
  const [activeDetailTab, setActiveDetailTab] = useState<string>('profile');

  const [users, setUsers] = useState<CustomerUser[]>(MOCK_CUSTOMER_USERS);
  const [drivers, setDrivers] = useState<DriverRecord[]>(MOCK_DRIVERS);
  const [vehicles, setVehicles] = useState<VehicleRecord[]>(MOCK_VEHICLES);
  const [bookings, setBookings] = useState<CustomerBooking[]>(MOCK_BOOKINGS);
  const [containers, setContainers] = useState<CustomerContainerItem[]>(MOCK_CUSTOMER_CONTAINERS);
  const [gateIns, setGateIns] = useState<GateInRegistration[]>(MOCK_GATEIN_REGISTRATIONS);

  // Modals & Wizards
  const [isWizardOpen, setIsWizardOpen] = useState<boolean>(false);
  const [prefilledBooking, setPrefilledBooking] = useState<CustomerBooking | null>(null);
  const [qrGateIn, setQrGateIn] = useState<GateInRegistration | null>(null);
  const [detailGateIn, setDetailGateIn] = useState<GateInRegistration | null>(null);

  const currentCustomer = customers.find((c) => c.id === currentCustomerId) || customers[0];

  // Select customer to view detail & account info
  const handleSelectCustomer = (customer: CustomerCompany) => {
    setCurrentCustomerId(customer.id);
    setActiveDetailTab('profile');
    setPageView('DETAIL');
  };

  const handleAddCustomer = (newCustomer: CustomerCompany) => {
    setCustomers((prev) => [newCustomer, ...prev]);
  };

  const handleUpdateCustomer = (updatedCustomer: CustomerCompany) => {
    setCustomers((prev) =>
      prev.map((c) => (c.id === updatedCustomer.id ? updatedCustomer : c))
    );
  };

  const handleAddUser = (newUser: CustomerUser) => {
    setUsers((prev) => [newUser, ...prev]);
  };

  const handleUpdateUser = (updatedUser: CustomerUser) => {
    setUsers((prev) =>
      prev.map((u) => (u.id === updatedUser.id ? updatedUser : u))
    );
  };

  const handleDeleteUser = (userId: string) => {
    setUsers((prev) => prev.filter((u) => u.id !== userId));
  };

  const handleAddDriver = (newDriver: DriverRecord, userAccount?: CustomerUser) => {
    setDrivers((prev) => [newDriver, ...prev]);
    if (userAccount) {
      setUsers((prev) => [userAccount, ...prev]);
    }
  };

  const handleUpdateDriver = (updatedDriver: DriverRecord) => {
    setDrivers((prev) =>
      prev.map((d) => (d.id === updatedDriver.id ? updatedDriver : d))
    );
  };

  const handleAddVehicle = (newVehicle: VehicleRecord) => {
    setVehicles((prev) => [newVehicle, ...prev]);
  };

  const handleCreateGateIn = (newGateIn: GateInRegistration) => {
    setGateIns((prev) => [newGateIn, ...prev]);
    setIsWizardOpen(false);
    setPrefilledBooking(null);
    setQrGateIn(newGateIn);
  };

  const handleCancelGateIn = (gateInId: string) => {
    setGateIns((prev) =>
      prev.map((g) => (g.id === gateInId ? { ...g, status: 'CANCELLED' } : g))
    );
  };

  const handleOpenGateInWithBooking = (booking: CustomerBooking) => {
    setPrefilledBooking(booking);
    setIsWizardOpen(true);
  };

  const getCategoryLabel = (cat?: string) => {
    switch (cat) {
      case 'DOANH_NGHIEP':
        return { text: 'Doanh Nghiệp / Tập Đoàn', color: 'text-blue-400 bg-blue-500/10 border-blue-500/30' };
      case 'CONG_TY':
        return { text: 'Công Ty Vận Tải / FWD', color: 'text-purple-400 bg-purple-500/10 border-purple-500/30' };
      case 'KHACH_LE':
        return { text: 'Khách Lẻ / Chủ Xe Cá Nhân', color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30' };
      default:
        return { text: 'Doanh Nghiệp Vận Tải', color: 'text-blue-400 bg-blue-500/10 border-blue-500/30' };
    }
  };

  const catMeta = getCategoryLabel(currentCustomer.category);

  // 1. LIST VIEW (Default): Display clean list of customers
  if (pageView === 'LIST') {
    return (
      <div className="space-y-6">
        <CustomerListView
          customers={customers}
          users={users}
          drivers={drivers}
          vehicles={vehicles}
          onSelectCustomer={handleSelectCustomer}
          onAddCustomer={handleAddCustomer}
          onUpdateCustomer={handleUpdateCustomer}
          onAddUser={handleAddUser}
        />
      </div>
    );
  }

  // 2. DETAIL VIEW: Display selected customer's full account information & workspace
  return (
    <div className="space-y-6">
      {/* Top Breadcrumb & Navigation Bar */}
      <div className="flex items-center justify-between gap-3">
        <button
          onClick={() => setPageView('LIST')}
          className="flex items-center gap-2 px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white rounded-xl border border-slate-800 text-xs font-bold transition shadow-sm cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4 text-blue-400" />
          <span>Danh Sách Khách Hàng</span>
        </button>

        <div className="text-xs text-slate-400 font-mono hidden sm:block">
          Quản Lý Khách Hàng / <strong className="text-white">{currentCustomer.code}</strong> - {currentCustomer.name}
        </div>
      </div>

      {/* Top Banner: Customer Identity & Switcher */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 sm:p-5 shadow-2xl flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
        {/* Left: Customer selector */}
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 p-0.5 flex items-center justify-center shadow-lg shadow-blue-500/20 shrink-0">
            <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center text-blue-400">
              <Building2 className="w-6 h-6" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className={`px-2 py-0.5 rounded-md text-[10px] font-mono font-bold border ${catMeta.color}`}>
                {catMeta.text}
              </span>
              <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                {currentCustomer.status === 'ACTIVE' ? 'Đang hoạt động' : 'Tạm khóa'}
              </span>
              <span className="px-2 py-0.5 rounded-md text-[10px] font-mono font-bold bg-amber-500/10 text-amber-300 border border-amber-500/30">
                Admin: @{currentCustomer.adminUsername || 'admin'}
              </span>
            </div>
            <div className="relative mt-1">
              <select
                value={currentCustomerId}
                onChange={(e) => setCurrentCustomerId(e.target.value)}
                className="appearance-none pr-8 pl-0 py-0 bg-transparent text-base sm:text-lg font-black text-white focus:outline-none cursor-pointer border-none"
              >
                {customers.map((c) => (
                  <option key={c.id} value={c.id} className="bg-slate-900 text-white text-sm">
                    {c.name} ({c.code}) - [{c.category === 'DOANH_NGHIEP' ? 'Doanh nghiệp' : c.category === 'CONG_TY' ? 'Công ty' : 'Khách lẻ'}]
                  </option>
                ))}
              </select>
            </div>
            <p className="text-xs text-slate-400 mt-0.5 font-mono">
              {currentCustomer.category === 'KHACH_LE' ? 'CCCD' : 'MST'}: {currentCustomer.taxCode} • SĐT: {currentCustomer.phone} • Email: {currentCustomer.email}
            </p>
          </div>
        </div>

        {/* Right: Role Preview Switcher */}
        <div className="flex flex-wrap items-center gap-2.5 self-stretch sm:self-auto justify-end">
          <div className="flex items-center bg-slate-950 border border-slate-800 rounded-xl p-1 text-xs">
            <button
              onClick={() => setCurrentRole('CUSTOMER_ADMIN')}
              className={`px-3 py-1.5 rounded-lg font-bold transition cursor-pointer ${
                currentRole === 'CUSTOMER_ADMIN'
                  ? 'bg-blue-600 text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Admin KH
            </button>
            <button
              onClick={() => setCurrentRole('DISPATCHER')}
              className={`px-3 py-1.5 rounded-lg font-bold transition cursor-pointer ${
                currentRole === 'DISPATCHER'
                  ? 'bg-blue-600 text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Điều Độ
            </button>
            <button
              onClick={() => setCurrentRole('DRIVER')}
              className={`px-3 py-1.5 rounded-lg font-bold transition cursor-pointer ${
                currentRole === 'DRIVER'
                  ? 'bg-blue-600 text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Tài Xế
            </button>
          </div>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-thin border-b border-slate-800/80">
        <button
          onClick={() => setActiveDetailTab('profile')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap ${
            activeDetailTab === 'profile'
              ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Key className="w-4 h-4" />
          <span>Hồ Sơ &amp; Tài Khoản Admin</span>
        </button>

        <button
          onClick={() => setActiveDetailTab('accounts')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap ${
            activeDetailTab === 'accounts'
              ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Tài Khoản &amp; Phân Quyền</span>
          <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-emerald-500/20 text-emerald-300 font-mono">
            {users.filter((u) => u.customerId === currentCustomerId).length}
          </span>
        </button>

        <button
          onClick={() => setActiveDetailTab('gate_in_online')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap ${
            activeDetailTab === 'gate_in_online'
              ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Truck className="w-4 h-4" />
          <span>Đăng Ký Gate-In Online</span>
          <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-cyan-500/20 text-cyan-300 font-mono">
            {gateIns.filter((g) => g.customerId === currentCustomerId).length}
          </span>
        </button>

        <button
          onClick={() => setActiveDetailTab('bookings')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap ${
            activeDetailTab === 'bookings'
              ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Lệnh / Booking</span>
          <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-purple-500/20 text-purple-300 font-mono">
            {bookings.filter((b) => b.customerId === currentCustomerId).length}
          </span>
        </button>

        <button
          onClick={() => setActiveDetailTab('containers')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap ${
            activeDetailTab === 'containers'
              ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Box className="w-4 h-4" />
          <span>Container Tại Bãi</span>
          <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-indigo-500/20 text-indigo-300 font-mono">
            {containers.filter((c) => c.customerId === currentCustomerId).length}
          </span>
        </button>

        <button
          onClick={() => setActiveDetailTab('drivers')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap ${
            activeDetailTab === 'drivers'
              ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <UserCheck className="w-4 h-4" />
          <span>Đội Ngũ Tài Xế</span>
          <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-emerald-500/20 text-emerald-300 font-mono">
            {drivers.filter((d) => d.customerId === currentCustomerId).length}
          </span>
        </button>

        <button
          onClick={() => setActiveDetailTab('vehicles')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap ${
            activeDetailTab === 'vehicles'
              ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Car className="w-4 h-4" />
          <span>Phương Tiện / Đầu Kéo</span>
          <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-amber-500/20 text-amber-300 font-mono">
            {vehicles.filter((v) => v.customerId === currentCustomerId).length}
          </span>
        </button>

        <button
          onClick={() => setActiveDetailTab('dashboard')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap ${
            activeDetailTab === 'dashboard'
              ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <LayoutDashboard className="w-4 h-4" />
          <span>Tổng Quan (Dashboard)</span>
        </button>
      </div>

      {/* Main Tab Views */}
      <div>
        {activeDetailTab === 'profile' && (
          <CustomerAccountProfileTab
            customer={currentCustomer}
            users={users}
            drivers={drivers}
            vehicles={vehicles}
            bookings={bookings}
            containers={containers}
            gateIns={gateIns}
            onNavigateSubTab={setActiveDetailTab}
            onUpdateCustomer={handleUpdateCustomer}
          />
        )}

        {activeDetailTab === 'accounts' && (
          <CustomerAccountsTab
            currentCustomer={currentCustomer}
            users={users}
            drivers={drivers}
            vehicles={vehicles}
            onAddUser={handleAddUser}
            onUpdateUser={handleUpdateUser}
            onDeleteUser={handleDeleteUser}
            onSelectRole={(r) => setCurrentRole(r)}
          />
        )}

        {activeDetailTab === 'gate_in_online' && (
          <GateInListView
            currentCustomer={currentCustomer}
            gateIns={gateIns}
            onAddNew={() => setIsWizardOpen(true)}
            onViewDetail={(g) => setDetailGateIn(g)}
            onOpenQR={(g) => setQrGateIn(g)}
            onCancelGateIn={handleCancelGateIn}
          />
        )}

        {activeDetailTab === 'bookings' && (
          <CustomerBookingView
            currentCustomer={currentCustomer}
            bookings={bookings}
            onRegisterGateInWithBooking={handleOpenGateInWithBooking}
          />
        )}

        {activeDetailTab === 'containers' && (
          <CustomerContainerView
            currentCustomer={currentCustomer}
            containers={containers}
          />
        )}

        {activeDetailTab === 'drivers' && (
          <CustomerDriverManagementView
            currentCustomer={currentCustomer}
            drivers={drivers}
            onAddDriver={handleAddDriver}
            onUpdateDriver={handleUpdateDriver}
          />
        )}

        {activeDetailTab === 'vehicles' && (
          <CustomerVehicleManagementView
            currentCustomer={currentCustomer}
            vehicles={vehicles}
            drivers={drivers}
            onAddVehicle={handleAddVehicle}
          />
        )}

        {activeDetailTab === 'dashboard' && (
          <CustomerDashboardView
            currentCustomer={currentCustomer}
            gateIns={gateIns}
            bookings={bookings}
            containers={containers}
            currentRole={currentRole}
            onNavigateTab={setActiveDetailTab}
            onOpenGateInWizard={() => setIsWizardOpen(true)}
            onViewGateInDetail={(g) => setDetailGateIn(g)}
            onOpenQR={(g) => setQrGateIn(g)}
          />
        )}
      </div>

      {/* Gate-In Online Wizard Modal */}
      {isWizardOpen && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-4xl w-full max-h-[90vh] overflow-y-auto p-6 shadow-2xl relative">
            <button
              onClick={() => {
                setIsWizardOpen(false);
                setPrefilledBooking(null);
              }}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-lg transition cursor-pointer"
            >
              ✕
            </button>
            <GateInOnlineWizard
              currentCustomer={currentCustomer}
              currentUser={users.find((u) => u.customerId === currentCustomer.id)}
              bookings={bookings}
              drivers={drivers}
              vehicles={vehicles}
              onCompleteGateIn={handleCreateGateIn}
              onViewList={() => {
                setIsWizardOpen(false);
                setActiveDetailTab('gate_in_online');
              }}
              onOpenQR={(g) => {
                setIsWizardOpen(false);
                setQrGateIn(g);
              }}
            />
          </div>
        </div>
      )}

      {/* Gate-In QR Code Modal */}
      {qrGateIn && (
        <GateInQRCodeModal
          gateIn={qrGateIn}
          onClose={() => setQrGateIn(null)}
        />
      )}

      {/* Gate-In Detail Modal */}
      {detailGateIn && (
        <GateInDetailModal
          gateIn={detailGateIn}
          onClose={() => setDetailGateIn(null)}
          onOpenQR={(g) => {
            setDetailGateIn(null);
            setQrGateIn(g);
          }}
          onUpdateStatus={(id, newStatus) => {
            setGateIns((prev) =>
              prev.map((g) => (g.id === id ? { ...g, status: newStatus } : g))
            );
          }}
        />
      )}
    </div>
  );
};
