import React, { useState } from 'react';
import { CONTAINER_SIZES, SHIPPING_LINES, TRUCKING_CUSTOMERS } from '../../../constants/container';
import { ContainerRecord } from '../../../services/mockDataStore';
import {
  LogIn,
  LogOut,
  Truck,
  CheckCircle2,
  QrCode,
  Scan,
  ShieldAlert,
  Building2,
  Ship,
  FileText,
  Clock,
  Printer,
  Search,
  Filter,
  DollarSign,
  Layers,
  ArrowRight,
  Boxes,
  Plus,
  Trash2,
  CreditCard,
  Sparkles,
  MapPin,
  Camera,
  Check,
  Eye,
  AlertCircle,
  Zap,
  Gauge,
  Barcode,
  Share2,
  Phone,
  UserCheck,
  CheckCheck,
  ChevronRight
} from 'lucide-react';

interface GateInPageProps {
  containers?: ContainerRecord[];
  onAddGateIn?: (newContainer: {
    containerNo: string;
    isoCode: string;
    size: string;
    type: string;
    shippingLine: string;
    licensePlate: string;
    driverName: string;
    driverPhone: string;
  }) => void;
  onNavigateTab: (tabId: string) => void;
}

export interface GateLaneRecord {
  id: string;
  lane: string;
  type: 'GATE_IN' | 'GATE_OUT';
  containerNo: string;
  shippingLine: string;
  size: string;
  licensePlate: string;
  driverName: string;
  driverPhone: string;
  truckingName: string;
  arrivalTime: string;
  status: 'CHECKING' | 'WAITING_FORKLIFT' | 'COMPLETED' | 'HOLD';
  eirNo: string;
  yardBlock: string;
  surveyBay?: string;
  condition?: 'EMPTY' | 'FULL';
}

const INITIAL_GATE_LANES: GateLaneRecord[] = [
  {
    id: 'G-101',
    lane: 'LÀN 01 (CỔNG NHẬP)',
    type: 'GATE_IN',
    containerNo: 'MSCU7729104',
    shippingLine: 'MSK',
    size: '40HC',
    licensePlate: '51C-882.19',
    driverName: 'Nguyễn Văn Thành',
    driverPhone: '0908123456',
    truckingName: 'Công Ty Vận Tải Á Châu',
    arrivalTime: '10 phút trước',
    status: 'WAITING_FORKLIFT',
    eirNo: 'EIR-IN-882109',
    yardBlock: 'BLOCK A-02-03-2',
    surveyBay: 'BỆ 01 (Giám Định Nhanh)',
    condition: 'EMPTY'
  },
  {
    id: 'G-102',
    lane: 'LÀN 02 (CỔNG NHẬP)',
    type: 'GATE_IN',
    containerNo: 'CMAU9918231',
    shippingLine: 'CMA',
    size: '20DC',
    licensePlate: '51D-334.82',
    driverName: 'Lê Hoàng Nam',
    driverPhone: '0912345678',
    truckingName: 'Logistics Tân Cảng SG',
    arrivalTime: '3 phút trước',
    status: 'CHECKING',
    eirNo: 'EIR-IN-882110',
    yardBlock: 'BLOCK B-01-01-1',
    surveyBay: 'BỆ 03 (IICL-6 Tiêu Chuẩn)',
    condition: 'EMPTY'
  },
  {
    id: 'G-103',
    lane: 'LÀN 03 (CỔNG XUẤT CẤP VỎ)',
    type: 'GATE_OUT',
    containerNo: 'TCKU2019482',
    shippingLine: 'MSK',
    size: '40HC',
    licensePlate: '50H-918.23',
    driverName: 'Phạm Quốc Hùng',
    driverPhone: '0987654321',
    truckingName: 'Vận Tải Miền Nam Corp',
    arrivalTime: '15 phút trước',
    status: 'COMPLETED',
    eirNo: 'EIR-OUT-991042',
    yardBlock: 'BLOCK A-01-02-3',
    condition: 'EMPTY'
  }
];

export const GateInPage: React.FC<GateInPageProps> = ({
  containers = [],
  onAddGateIn,
  onNavigateTab
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'gate_in' | 'gate_out' | 'live_queue' | 'eir_list' | 'tariffs'>('gate_in');
  const [isScanningOCR, setIsScanningOCR] = useState(false);

  // Gate-In Form State - Focused exclusively on Container Intake (Hạ Vỏ Rỗng)
  const [formData, setFormData] = useState({
    containerNo: 'MSCU' + Math.floor(1000000 + Math.random() * 9000000),
    isoCode: '45G1',
    size: '40HC',
    type: 'Dry High Cube',
    shippingLine: 'MSK',
    truckingCompany: 'LOG-TC',
    licensePlate: '51C-992.10',
    trailerPlate: '51R-881.02',
    driverName: 'Nguyễn Văn Tiến',
    driverPhone: '0909123456',
    sealNo: 'ML-SEAL-' + Math.floor(100000 + Math.random() * 900000),
    bookingNo: 'BK-2026-' + Math.floor(100000 + Math.random() * 900000),
    condition: 'EMPTY' as 'EMPTY',
    tareWeight: 3850,
    maxPayload: 28650,
    yardBlock: 'BLOCK_A',
    surveyBay: 'BAY_01',
    remarks: 'Container nguyên niêm phong hãng tàu, không móp méo kết cấu ngoài'
  });

  // Gate-Out Form State
  const [gateOutData, setGateOutData] = useState({
    releaseOrderNo: 'RO-MAEU-' + Math.floor(100000 + Math.random() * 900000),
    bookingNo: 'BK-EXP-88912',
    shippingLine: 'MSK',
    size: '40HC',
    selectedContainerNo: 'MSCU7729104',
    truckingCompany: 'Công Ty Vận Tải Quốc Tế Á Châu',
    licensePlate: '51C-445.89',
    trailerPlate: '51R-332.11',
    driverName: 'Trần Văn Mạnh',
    driverPhone: '0938112233',
    newSealNo: 'MSK-EXP-' + Math.floor(100000 + Math.random() * 900000),
    destinationPort: 'CAT LAI PORT (VNCLI)'
  });

  const [gateLanes, setGateLanes] = useState<GateLaneRecord[]>(INITIAL_GATE_LANES);
  const [createdEir, setCreatedEir] = useState<any>(null);
  const [isSuccessModalOpen, setIsSuccessModalOpen] = useState(false);
  const [selectedEirModal, setSelectedEirModal] = useState<any>(null);

  // Quick preset data generator
  const handleSimulateOCR = () => {
    setIsScanningOCR(true);
    setTimeout(() => {
      const prefixes = ['MSCU', 'MAEU', 'CMAU', 'ONEY', 'TGHU', 'COSU'];
      const randomPrefix = prefixes[Math.floor(Math.random() * prefixes.length)];
      const randomNum = Math.floor(1000000 + Math.random() * 900000);
      const randomPlates = ['51C-774.20', '60C-912.83', '50H-118.99', '72C-554.12'];
      const randomDrivers = ['Trần Quốc Bảo', 'Lê Hữu Đạt', 'Vũ Đình Toàn', 'Nguyễn Tấn Dũng'];

      setFormData(prev => ({
        ...prev,
        containerNo: `${randomPrefix}${randomNum}`,
        sealNo: `SEAL-${Math.floor(100000 + Math.random() * 900000)}`,
        licensePlate: randomPlates[Math.floor(Math.random() * randomPlates.length)],
        driverName: randomDrivers[Math.floor(Math.random() * randomDrivers.length)]
      }));
      setIsScanningOCR(false);
    }, 600);
  };

  // Handle Gate-In Submit (Container Intake only)
  const handleGateInSubmit = (e?: React.FormEvent, redirectToSurvey = false) => {
    if (e) e.preventDefault();
    if (!formData.containerNo || !formData.licensePlate) return;

    if (onAddGateIn) {
      onAddGateIn({
        containerNo: formData.containerNo,
        isoCode: formData.isoCode,
        size: formData.size,
        type: formData.type,
        shippingLine: formData.shippingLine,
        licensePlate: formData.licensePlate,
        driverName: formData.driverName,
        driverPhone: formData.driverPhone
      });
    }

    const bayLabelMap: Record<string, string> = {
      BAY_01: 'BỆ 01 (Bệ Giám Định Cont Khô)',
      BAY_02: 'BỆ 02 (Bệ Giám Định Cont Lạnh & PTI)',
      BAY_03: 'BỆ 03 (Bệ Giám Định IICL-6 Tiêu Chuẩn)',
      BAY_04: 'BỆ 04 (Bệ Giám Định Cơ Khí & M&R)'
    };

    const newEir = {
      eirNo: `EIR-IN-${Math.floor(100000 + Math.random() * 900000)}`,
      type: 'GATE_IN (HẠ VỎ RỖNG)',
      containerNo: formData.containerNo,
      isoCode: formData.isoCode,
      size: formData.size,
      shippingLine: formData.shippingLine,
      licensePlate: formData.licensePlate,
      trailerPlate: formData.trailerPlate,
      driverName: formData.driverName,
      driverPhone: formData.driverPhone,
      truckingCompany: formData.truckingCompany,
      sealNo: formData.sealNo,
      bookingNo: formData.bookingNo,
      yardLocation: `${formData.yardBlock}-B02-R01-T2`,
      surveyBay: bayLabelMap[formData.surveyBay] || 'BỆ 01 (Giám Định)',
      remarks: formData.remarks,
      condition: 'Hạ Vỏ Rỗng (Empty Return)',
      createdAt: new Date().toLocaleString('vi-VN'),
      status: 'TIẾP NHẬN THÀNH CÔNG • CHỜ GIÁM ĐỊNH'
    };

    const newLaneRecord: GateLaneRecord = {
      id: `G-${Date.now().toString().slice(-3)}`,
      lane: 'LÀN 01 (CỔNG NHẬP)',
      type: 'GATE_IN',
      containerNo: formData.containerNo,
      shippingLine: formData.shippingLine,
      size: formData.size,
      licensePlate: formData.licensePlate,
      driverName: formData.driverName,
      driverPhone: formData.driverPhone,
      truckingName: formData.truckingCompany,
      arrivalTime: 'Vừa xong',
      status: 'WAITING_FORKLIFT',
      eirNo: newEir.eirNo,
      yardBlock: newEir.yardLocation,
      surveyBay: newEir.surveyBay,
      condition: 'EMPTY'
    };

    setGateLanes([newLaneRecord, ...gateLanes]);
    setCreatedEir(newEir);

    if (redirectToSurvey) {
      onNavigateTab('survey');
    } else {
      setIsSuccessModalOpen(true);
    }
  };

  // Handle Gate-Out Submit
  const handleGateOutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newEir = {
      eirNo: `EIR-OUT-${Math.floor(100000 + Math.random() * 900000)}`,
      type: 'GATE_OUT (CẤP VỎ)',
      containerNo: gateOutData.selectedContainerNo,
      isoCode: '45G1',
      size: gateOutData.size,
      shippingLine: gateOutData.shippingLine,
      licensePlate: gateOutData.licensePlate,
      trailerPlate: gateOutData.trailerPlate,
      driverName: gateOutData.driverName,
      driverPhone: gateOutData.driverPhone,
      truckingCompany: gateOutData.truckingCompany,
      sealNo: gateOutData.newSealNo,
      bookingNo: gateOutData.bookingNo,
      releaseOrderNo: gateOutData.releaseOrderNo,
      destinationPort: gateOutData.destinationPort,
      yardLocation: 'BLOCK_A-B01-R02-T1',
      createdAt: new Date().toLocaleString('vi-VN'),
      status: 'ĐÃ CẤP VỎ XUẤT CỔNG'
    };

    const newLaneRecord: GateLaneRecord = {
      id: `G-${Date.now().toString().slice(-3)}`,
      lane: 'LÀN 03 (CỔNG XUẤT)',
      type: 'GATE_OUT',
      containerNo: gateOutData.selectedContainerNo,
      shippingLine: gateOutData.shippingLine,
      size: gateOutData.size,
      licensePlate: gateOutData.licensePlate,
      driverName: gateOutData.driverName,
      driverPhone: gateOutData.driverPhone,
      truckingName: gateOutData.truckingCompany,
      arrivalTime: 'Vừa xong',
      status: 'COMPLETED',
      eirNo: newEir.eirNo,
      yardBlock: newEir.yardLocation,
      condition: 'EMPTY'
    };

    setGateLanes([newLaneRecord, ...gateLanes]);
    setCreatedEir(newEir);
    setIsSuccessModalOpen(true);
  };

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* 1. TOP HERO BANNER & REAL-TIME KPI STRIP */}
      <div className="bg-gradient-to-br from-slate-900 via-[#0d1633] to-slate-900 border border-slate-800 rounded-2xl sm:rounded-3xl p-4 sm:p-6 shadow-xl relative overflow-hidden">
        {/* Glow backdrop decorative spots */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-10 left-1/3 w-80 h-80 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-start sm:items-center gap-3.5">
            <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-gradient-to-tr from-emerald-500 via-teal-500 to-cyan-500 p-0.5 flex items-center justify-center shadow-lg shadow-emerald-500/20 shrink-0">
              <div className="w-full h-full bg-[#081024] rounded-[14px] flex items-center justify-center text-emerald-400 font-black">
                <LogIn className="w-6 h-6 sm:w-7 sm:h-7" />
              </div>
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-[10px] sm:text-[11px] font-mono font-extrabold text-emerald-400 uppercase tracking-wider bg-emerald-500/10 px-2.5 py-0.5 rounded-full border border-emerald-500/20">
                  DEPOT GATE SYSTEM • BƯỚC 1 TIẾP NHẬN
                </span>
                <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-300 bg-emerald-950/80 px-2 py-0.5 rounded-full border border-emerald-500/30">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                  3 Làn Hoạt Động
                </span>
              </div>
              <h1 className="text-lg sm:text-2xl font-black text-white mt-1 tracking-tight">
                Cổng Tiếp Nhận Hạ Vỏ Rỗng (Gate-In)
              </h1>
              <p className="text-xs text-slate-400 mt-0.5 line-clamp-1">
                Tự động kiểm tra container, định tuyến bệ giám định IICL-6 và cấp phiếu điện tử e-EIR tức thì.
              </p>
            </div>
          </div>

          {/* Quick Action Navigation Buttons */}
          <div className="flex items-center gap-2 flex-wrap sm:flex-nowrap">
            <button
              onClick={() => onNavigateTab('survey')}
              className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl text-xs font-bold bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white shadow-lg shadow-purple-600/25 transition cursor-pointer flex items-center justify-center gap-2 whitespace-nowrap active:scale-95"
            >
              <Boxes className="w-4 h-4" />
              <span>Chuyển Sang Giám Định Vỏ</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => onNavigateTab('operation')}
              className="flex-1 sm:flex-none px-3.5 py-2.5 rounded-xl text-xs font-bold bg-slate-800/80 hover:bg-slate-700 text-slate-200 hover:text-white border border-slate-700/80 transition cursor-pointer flex items-center justify-center gap-1.5 whitespace-nowrap"
            >
              <FileText className="w-4 h-4 text-emerald-400" />
              <span>Khai Thác Gate-In</span>
            </button>
            <button
              onClick={() => onNavigateTab('yard_map')}
              className="hidden sm:flex px-3 py-2.5 rounded-xl text-xs font-bold bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700/80 transition cursor-pointer items-center gap-1.5 whitespace-nowrap"
            >
              <MapPin className="w-4 h-4 text-cyan-400" />
              <span>Sơ Đồ Bãi 2D</span>
            </button>
          </div>
        </div>

        {/* Real-time KPI Metric Mini Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3 mt-4 pt-4 border-t border-slate-800/80">
          <div className="bg-slate-950/60 rounded-xl p-2.5 border border-slate-800/60 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400">
              <Boxes className="w-4 h-4" />
            </div>
            <div>
              <div className="text-[10px] text-slate-400 font-medium">Hạ Vỏ Hôm Nay</div>
              <div className="text-sm sm:text-base font-mono font-black text-white">28 Cont <span className="text-[10px] text-emerald-400 font-sans font-bold">+12%</span></div>
            </div>
          </div>

          <div className="bg-slate-950/60 rounded-xl p-2.5 border border-slate-800/60 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-sky-500/10 text-sky-400">
              <Truck className="w-4 h-4" />
            </div>
            <div>
              <div className="text-[10px] text-slate-400 font-medium">Xe Tại Làn Cổng</div>
              <div className="text-sm sm:text-base font-mono font-black text-white">3 Xe <span className="text-[10px] text-sky-400 font-sans">Đang phục vụ</span></div>
            </div>
          </div>

          <div className="bg-slate-950/60 rounded-xl p-2.5 border border-slate-800/60 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400">
              <Clock className="w-4 h-4" />
            </div>
            <div>
              <div className="text-[10px] text-slate-400 font-medium">Xử Lý Trung Bình</div>
              <div className="text-sm sm:text-base font-mono font-black text-white">3.5 Phút <span className="text-[10px] text-amber-400 font-sans font-bold">Nhanh</span></div>
            </div>
          </div>

          <div className="bg-slate-950/60 rounded-xl p-2.5 border border-slate-800/60 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-purple-500/10 text-purple-400">
              <CheckCircle2 className="w-4 h-4" />
            </div>
            <div>
              <div className="text-[10px] text-slate-400 font-medium">Loại Hình Tiếp Nhận</div>
              <div className="text-xs sm:text-sm font-bold text-emerald-400 truncate">100% Vỏ Rỗng (Empty)</div>
            </div>
          </div>
        </div>
      </div>

      {/* 2. SUB TABS NAVIGATION */}
      <div className="flex items-center gap-1.5 sm:gap-2 overflow-x-auto pb-2 border-b border-slate-800/80 touch-pan-x overscroll-x-contain scrollbar-thin select-none">
        <button
          onClick={() => setActiveSubTab('gate_in')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap shrink-0 ${
            activeSubTab === 'gate_in'
              ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/25 ring-1 ring-emerald-400/40'
              : 'text-slate-400 hover:text-white hover:bg-slate-850 bg-slate-900/60 border border-slate-800/60'
          }`}
        >
          <LogIn className="w-4 h-4" />
          <span>1. Tiếp Nhận Hạ Vỏ Rỗng (Gate-In)</span>
        </button>

        <button
          onClick={() => setActiveSubTab('gate_out')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap shrink-0 ${
            activeSubTab === 'gate_out'
              ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/25 ring-1 ring-emerald-400/40'
              : 'text-slate-400 hover:text-white hover:bg-slate-850 bg-slate-900/60 border border-slate-800/60'
          }`}
        >
          <LogOut className="w-4 h-4" />
          <span>2. Cấp Vỏ & Xuất Cổng (Gate-Out)</span>
        </button>

        <button
          onClick={() => setActiveSubTab('live_queue')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap shrink-0 ${
            activeSubTab === 'live_queue'
              ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/25 ring-1 ring-emerald-400/40'
              : 'text-slate-400 hover:text-white hover:bg-slate-850 bg-slate-900/60 border border-slate-800/60'
          }`}
        >
          <Clock className="w-4 h-4" />
          <span>3. Hàng Đợi & Làn Cổng</span>
          <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-emerald-500/20 text-emerald-300 font-mono">
            {gateLanes.length}
          </span>
        </button>

        <button
          onClick={() => setActiveSubTab('eir_list')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap shrink-0 ${
            activeSubTab === 'eir_list'
              ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/25 ring-1 ring-emerald-400/40'
              : 'text-slate-400 hover:text-white hover:bg-slate-850 bg-slate-900/60 border border-slate-800/60'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>4. Lịch Sử e-EIR</span>
        </button>

        <button
          onClick={() => setActiveSubTab('tariffs')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap shrink-0 ${
            activeSubTab === 'tariffs'
              ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/25 ring-1 ring-emerald-400/40'
              : 'text-slate-400 hover:text-white hover:bg-slate-850 bg-slate-900/60 border border-slate-800/60'
          }`}
        >
          <DollarSign className="w-4 h-4" />
          <span>5. Biểu Phí Dịch Vụ Cổng</span>
        </button>
      </div>

      {/* TAB 1: GATE-IN FORM (TIẾP NHẬN HẠ VỎ RỖNG CHUYÊN SÂU) */}
      {activeSubTab === 'gate_in' && (
        <form onSubmit={(e) => handleGateInSubmit(e, true)} className="space-y-4 sm:space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 sm:gap-6">
            
            {/* LEFT COLUMN: CONTAINER DETAILS & OCR SCANNER (7 COLS) */}
            <div className="lg:col-span-7 space-y-4 sm:space-y-5">
              
              {/* Card 1: Container ISO & Shipping Line info */}
              <div className="bg-slate-900/95 border border-slate-800 rounded-2xl sm:rounded-3xl p-4 sm:p-6 shadow-xl space-y-4 relative overflow-hidden">
                <div className="flex items-center justify-between pb-3.5 border-b border-slate-800">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
                      <Scan className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="text-xs sm:text-sm font-bold text-white uppercase tracking-wider">
                        1. Thông Tin Vỏ Container (Hạ Vỏ)
                      </h3>
                      <span className="text-[10px] text-slate-400">Quy chuẩn ISO 6346 & Tiêu chuẩn Hãng Tàu</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={handleSimulateOCR}
                      disabled={isScanningOCR}
                      className="px-2.5 py-1.5 bg-blue-600/20 hover:bg-blue-600/40 text-blue-300 hover:text-white border border-blue-500/30 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
                      title="Mô phỏng quét camera AI OCR nhận diện số container tự động"
                    >
                      <Camera className={`w-3.5 h-3.5 ${isScanningOCR ? 'animate-spin' : ''}`} />
                      <span>{isScanningOCR ? 'Đang Quét OCR...' : 'Quét Camera OCR'}</span>
                    </button>
                    
                    <button
                      type="button"
                      onClick={() => {
                        setFormData(prev => ({
                          ...prev,
                          condition: 'EMPTY',
                          containerNo: 'MSCU' + Math.floor(1000000 + Math.random() * 9000000),
                          sealNo: 'ML-SEAL-' + Math.floor(100000 + Math.random() * 900000)
                        }));
                      }}
                      className="p-1.5 text-slate-400 hover:text-blue-400 bg-slate-800 hover:bg-slate-700 rounded-xl border border-slate-700 transition cursor-pointer"
                      title="Sinh số ngẫu nhiên mới"
                    >
                      <Sparkles className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div className="space-y-4">
                  {/* Container No Big Input with Live Status Badge */}
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                        <span>Số Container (ISO 6346)*</span>
                        <span className="text-[10px] text-rose-400 font-mono">Bắt buộc</span>
                      </label>
                      <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20 font-bold">
                        ✓ Check Digit Valid
                      </span>
                    </div>
                    <div className="relative">
                      <input
                        type="text"
                        required
                        value={formData.containerNo}
                        onChange={(e) => setFormData({ ...formData, containerNo: e.target.value.toUpperCase() })}
                        placeholder="VD: MSCU7729104"
                        className="w-full px-4 py-3 bg-slate-950 border border-slate-700 focus:border-blue-500 rounded-xl text-base sm:text-lg font-mono font-black text-white focus:outline-none tracking-widest uppercase transition shadow-inner"
                      />
                      <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1.5">
                        <span className="px-2 py-0.5 text-[11px] font-bold font-mono bg-blue-500/20 text-blue-300 rounded">
                          {formData.isoCode}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Size Quick Buttons */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Kích Thước & Loại Container
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-2">
                      {[
                        { code: '40HC', name: '40 High Cube', iso: '45G1' },
                        { code: '20DC', name: '20 Standard', iso: '22G1' },
                        { code: '40DC', name: '40 Standard', iso: '42G1' },
                        { code: '45HC', name: '45 High Cube', iso: '45G1' },
                      ].map((item) => (
                        <button
                          key={item.code}
                          type="button"
                          onClick={() => {
                            setFormData({
                              ...formData,
                              size: item.code,
                              type: item.name,
                              isoCode: item.iso
                            });
                          }}
                          className={`py-2 px-2.5 rounded-xl text-xs font-bold transition text-left cursor-pointer border ${
                            formData.size === item.code
                              ? 'bg-blue-600 text-white border-blue-400 shadow-md shadow-blue-600/30'
                              : 'bg-slate-950/80 text-slate-300 border-slate-800 hover:border-slate-700'
                          }`}
                        >
                          <div className="font-black text-sm">{item.code}</div>
                          <div className="text-[10px] opacity-80 truncate">{item.name}</div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Shipping Line & Seal No */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        Hãng Tàu Quản Lý (Shipping Line)*
                      </label>
                      <select
                        value={formData.shippingLine}
                        onChange={(e) => setFormData({ ...formData, shippingLine: e.target.value })}
                        className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 text-xs text-white rounded-xl font-bold focus:border-blue-500 focus:outline-none min-h-[42px]"
                      >
                        {SHIPPING_LINES.map((line) => (
                          <option key={line.code} value={line.code}>
                            {line.code} - {line.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        Số Niêm Phong Lúc Hạ (Seal No.)
                      </label>
                      <input
                        type="text"
                        value={formData.sealNo}
                        onChange={(e) => setFormData({ ...formData, sealNo: e.target.value })}
                        placeholder="ML-SEAL-88912"
                        className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 text-xs text-white rounded-xl font-mono focus:border-blue-500 focus:outline-none min-h-[42px]"
                      />
                    </div>
                  </div>

                  {/* Fixed Condition: 100% Hạ Vỏ Rỗng Badge */}
                  <div className="p-3.5 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                        <CheckCheck className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="text-xs font-black text-emerald-300 uppercase tracking-wide">
                          Mục Đích: Tiếp Nhận Hạ Vỏ Rỗng (Empty Return)
                        </div>
                        <div className="text-[11px] text-emerald-400/80">
                          Chuyên biệt cho khâu tiếp nhận hạ rỗng, vệ sinh & giám định vỏ IICL
                        </div>
                      </div>
                    </div>
                    <span className="hidden sm:inline px-2.5 py-1 rounded-lg text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                      100% DEPOT
                    </span>
                  </div>

                </div>
              </div>

            </div>

            {/* RIGHT COLUMN: TRUCKING & DRIVER INFO + SUBMISSION (5 COLS) */}
            <div className="lg:col-span-5 space-y-4 sm:space-y-5 flex flex-col justify-between">
              
              <div className="bg-slate-900/95 border border-slate-800 rounded-2xl sm:rounded-3xl p-4 sm:p-6 shadow-xl space-y-4">
                <div className="flex items-center justify-between pb-3.5 border-b border-slate-800">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-sky-500/10 border border-sky-500/30 flex items-center justify-center text-sky-400">
                      <Truck className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="text-xs sm:text-sm font-bold text-white uppercase tracking-wider">
                        2. Xe Vận Tải & Tài Xế
                      </h3>
                      <span className="text-[10px] text-slate-400">Nhà xe vận chuyển giao vỏ rỗng</span>
                    </div>
                  </div>
                  <span className="text-[10px] text-sky-400 font-mono bg-sky-500/10 px-2 py-0.5 rounded border border-sky-500/20 font-bold">
                    GPS Check-In
                  </span>
                </div>

                <div className="space-y-3.5">
                  {/* Trucking partner selection */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Đơn Vị Vận Tải / Nhà Xe*
                    </label>
                    <select
                      value={formData.truckingCompany}
                      onChange={(e) => setFormData({ ...formData, truckingCompany: e.target.value })}
                      className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 text-xs text-white rounded-xl font-bold focus:border-sky-500 focus:outline-none min-h-[42px]"
                    >
                      {TRUCKING_CUSTOMERS.map((cust) => (
                        <option key={cust.code} value={cust.code}>
                          [{cust.code}] {cust.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Plates Grid with Stylized Vietnamese Plate Badges */}
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">
                        Biển Số Đầu Kéo*
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.licensePlate}
                        onChange={(e) => setFormData({ ...formData, licensePlate: e.target.value.toUpperCase() })}
                        placeholder="51C-992.10"
                        className="w-full px-3 py-2 bg-slate-950 border border-slate-700 text-xs font-mono font-black text-amber-300 rounded-xl focus:border-sky-500 focus:outline-none tracking-wider min-h-[40px]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">
                        Biển Rơ-moóc
                      </label>
                      <input
                        type="text"
                        value={formData.trailerPlate}
                        onChange={(e) => setFormData({ ...formData, trailerPlate: e.target.value.toUpperCase() })}
                        placeholder="51R-881.02"
                        className="w-full px-3 py-2 bg-slate-950 border border-slate-700 text-xs font-mono font-bold text-slate-200 rounded-xl focus:border-sky-500 focus:outline-none tracking-wider min-h-[40px]"
                      />
                    </div>
                  </div>

                  {/* Driver Name & Phone */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">
                        Họ Tên Bác Tài
                      </label>
                      <div className="relative">
                        <input
                          type="text"
                          value={formData.driverName}
                          onChange={(e) => setFormData({ ...formData, driverName: e.target.value })}
                          placeholder="Nguyễn Văn Tiến"
                          className="w-full pl-8 pr-3 py-2 bg-slate-950 border border-slate-700 text-xs text-white rounded-xl focus:border-sky-500 focus:outline-none min-h-[40px]"
                        />
                        <UserCheck className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">
                        SĐT Nhận e-EIR SMS
                      </label>
                      <div className="relative">
                        <input
                          type="text"
                          value={formData.driverPhone}
                          onChange={(e) => setFormData({ ...formData, driverPhone: e.target.value })}
                          placeholder="0909123456"
                          className="w-full pl-8 pr-3 py-2 bg-slate-950 border border-slate-700 text-xs font-mono text-white rounded-xl focus:border-sky-500 focus:outline-none min-h-[40px]"
                        />
                        <Phone className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
                      </div>
                    </div>
                  </div>

                  {/* Remarks */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Ghi Chú Tiếp Nhận Tại Cổng
                    </label>
                    <input
                      type="text"
                      value={formData.remarks}
                      onChange={(e) => setFormData({ ...formData, remarks: e.target.value })}
                      placeholder="Container nguyên niêm phong, không móp méo..."
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-700 text-xs text-slate-300 rounded-xl focus:border-sky-500 focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Action Buttons Box */}
              <div className="bg-slate-900/95 border border-slate-800 rounded-2xl sm:rounded-3xl p-4 sm:p-5 shadow-xl space-y-3">
                <button
                  type="submit"
                  className="w-full py-4 bg-gradient-to-r from-purple-600 via-indigo-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 active:scale-[0.99] text-white font-black text-sm rounded-2xl shadow-xl shadow-purple-600/30 transition flex items-center justify-center gap-2 cursor-pointer ring-2 ring-purple-400/20"
                >
                  <Boxes className="w-5 h-5" />
                  <span>XÁC NHẬN TIẾP NHẬN & CHUYỂN GIÁM ĐỊNH</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => handleGateInSubmit(undefined, false)}
                    className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl border border-slate-700 transition flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Printer className="w-3.5 h-3.5 text-sky-400" />
                    <span>In Phiếu e-EIR</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleSimulateOCR}
                    className="py-2.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-xl border border-slate-700 transition flex items-center justify-center gap-1 cursor-pointer"
                    title="Nạp nhanh mẫu xe ngẫu nhiên khác"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    <span>Đổi Mẫu</span>
                  </button>
                </div>
              </div>

            </div>

          </div>
        </form>
      )}

      {/* TAB 2: GATE-OUT (CẤP VỎ / XUẤT CỔNG) */}
      {activeSubTab === 'gate_out' && (
        <form onSubmit={handleGateOutSubmit} className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4 shadow-lg">
              <h3 className="text-xs font-bold text-rose-400 uppercase tracking-wider flex items-center gap-2 pb-3 border-b border-slate-800">
                <LogOut className="w-4 h-4" />
                <span>1. Lệnh Cấp Vỏ (Release Order)</span>
              </h3>

              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Số Lệnh Cấp Vỏ (RO No.)*
                  </label>
                  <input
                    type="text"
                    required
                    value={gateOutData.releaseOrderNo}
                    onChange={(e) => setGateOutData({ ...gateOutData, releaseOrderNo: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 text-xs font-mono font-bold text-white rounded-xl"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Số Booking Xuất Khẩu*
                  </label>
                  <input
                    type="text"
                    required
                    value={gateOutData.bookingNo}
                    onChange={(e) => setGateOutData({ ...gateOutData, bookingNo: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 text-xs font-mono text-white rounded-xl"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Hãng Tàu Cấp Vỏ
                  </label>
                  <select
                    value={gateOutData.shippingLine}
                    onChange={(e) => setGateOutData({ ...gateOutData, shippingLine: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 text-xs text-white rounded-xl font-bold"
                  >
                    <option value="MSK">MAERSK LINE (Đủ điều kiện cấp)</option>
                    <option value="CMA">CMA CGM</option>
                    <option value="ONE">OCEAN NETWORK EXPRESS</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4 shadow-lg">
              <h3 className="text-xs font-bold text-blue-400 uppercase tracking-wider flex items-center gap-2 pb-3 border-b border-slate-800">
                <Boxes className="w-4 h-4" />
                <span>2. Chọn Container Chuẩn AV (Available)</span>
              </h3>

              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Container Đã QC Pass Tại Bãi
                  </label>
                  <select
                    value={gateOutData.selectedContainerNo}
                    onChange={(e) => setGateOutData({ ...gateOutData, selectedContainerNo: e.target.value })}
                    className="w-full px-3 py-2.5 bg-slate-950 border border-slate-700 text-xs font-mono font-bold text-emerald-400 rounded-xl"
                  >
                    <option value="MSCU7729104">MSCU7729104 - 40HC (Grade A - Đạt Chuẩn Thực Phẩm)</option>
                    <option value="MAEU4419208">MAEU4419208 - 40HC (Grade A - Sạch Sẽ)</option>
                    <option value="TCKU2019482">TCKU2019482 - 20DC (Grade B - Khô Ráo)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Số Niêm Phong Mới Cấp (New Seal)
                  </label>
                  <input
                    type="text"
                    value={gateOutData.newSealNo}
                    onChange={(e) => setGateOutData({ ...gateOutData, newSealNo: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 text-xs font-mono text-white rounded-xl"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Cảng Giao Hàng Dự Kiến
                  </label>
                  <input
                    type="text"
                    value={gateOutData.destinationPort}
                    onChange={(e) => setGateOutData({ ...gateOutData, destinationPort: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 text-xs text-white rounded-xl"
                  />
                </div>
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4 shadow-lg flex flex-col justify-between">
              <div>
                <h3 className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-2 pb-3 border-b border-slate-800">
                  <Truck className="w-4 h-4" />
                  <span>3. Phương Tiện Nhận Vỏ</span>
                </h3>

                <div className="space-y-3 mt-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Biển Số Xe Đầu Kéo*
                    </label>
                    <input
                      type="text"
                      required
                      value={gateOutData.licensePlate}
                      onChange={(e) => setGateOutData({ ...gateOutData, licensePlate: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-700 text-xs font-mono font-bold text-white rounded-xl"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Họ Tên & SĐT Tài Xế
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      <input
                        type="text"
                        value={gateOutData.driverName}
                        onChange={(e) => setGateOutData({ ...gateOutData, driverName: e.target.value })}
                        className="px-3 py-2 bg-slate-950 border border-slate-700 text-xs text-white rounded-xl"
                      />
                      <input
                        type="text"
                        value={gateOutData.driverPhone}
                        onChange={(e) => setGateOutData({ ...gateOutData, driverPhone: e.target.value })}
                        className="px-3 py-2 bg-slate-950 border border-slate-700 text-xs font-mono text-white rounded-xl"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="pt-3">
                <button
                  type="submit"
                  className="w-full py-3.5 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs rounded-2xl shadow-xl shadow-rose-600/30 transition flex items-center justify-center gap-2 cursor-pointer"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Cấp Vỏ & Xuất Lệnh Gate-Out</span>
                </button>
              </div>
            </div>
          </div>
        </form>
      )}

      {/* TAB 3: LIVE QUEUE (LÀN CỔNG & HÀNG ĐỢI) */}
      {activeSubTab === 'live_queue' && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4 shadow-xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Clock className="w-4 h-4 text-emerald-400" />
                <span>Giám Sát Làn Cổng & Hàng Đợi Check-In (Live Gate Queue)</span>
              </h3>
              <p className="text-xs text-slate-400">
                Theo dõi xe check-in tiếp nhận vỏ, phân luồng bệ giám định và điều phối xe nâng bãi.
              </p>
            </div>
            <div className="flex items-center gap-2 text-xs font-mono">
              <span className="px-2.5 py-1 bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded-lg">
                3 Làn Đang Mở
              </span>
              <span className="px-2.5 py-1 bg-blue-500/10 text-blue-400 border border-blue-500/30 rounded-lg">
                TB: 3.2 Phút / Xe
              </span>
            </div>
          </div>

          <div className="overflow-x-auto touch-pan-x overscroll-x-contain pb-2 scrollbar-thin">
            <table className="w-full min-w-[720px] text-left text-xs">
              <thead className="bg-slate-950/80 text-slate-400 font-bold border-b border-slate-800">
                <tr>
                  <th className="p-3">LÀN CỔNG</th>
                  <th className="p-3">LOẠI NGHIỆP VỤ</th>
                  <th className="p-3">SỐ CONTAINER</th>
                  <th className="p-3">HÃNG TÀU / SIZE</th>
                  <th className="p-3">BIỂN SỐ / TÀI XẾ</th>
                  <th className="p-3">VỊ TRÍ YARD / BỆ GĐ</th>
                  <th className="p-3">TRẠNG THÁI</th>
                  <th className="p-3 text-right">THAO TÁC</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 font-medium">
                {gateLanes.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-800/40 transition">
                    <td className="p-3 font-bold text-white flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></div>
                      {item.lane}
                    </td>
                    <td className="p-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          item.type === 'GATE_IN'
                            ? 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/30'
                            : 'bg-rose-500/10 text-rose-300 border border-rose-500/30'
                        }`}
                      >
                        {item.type === 'GATE_IN' ? 'TIẾP NHẬN HẠ VỎ' : 'CẤP VỎ (GATE-OUT)'}
                      </span>
                    </td>
                    <td className="p-3 font-mono font-bold text-sky-400">{item.containerNo}</td>
                    <td className="p-3">
                      <span className="font-bold text-white">{item.shippingLine}</span> • {item.size}
                    </td>
                    <td className="p-3">
                      <div className="font-mono text-white">{item.licensePlate}</div>
                      <div className="text-[11px] text-slate-400">{item.driverName}</div>
                    </td>
                    <td className="p-3">
                      <div className="font-mono text-teal-400">{item.yardBlock}</div>
                      {item.surveyBay && (
                        <div className="text-[10px] text-purple-300">{item.surveyBay}</div>
                      )}
                    </td>
                    <td className="p-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          item.status === 'COMPLETED'
                            ? 'bg-emerald-500/20 text-emerald-400'
                            : item.status === 'WAITING_FORKLIFT'
                            ? 'bg-amber-500/20 text-amber-400'
                            : 'bg-blue-500/20 text-blue-400'
                        }`}
                      >
                        {item.status === 'COMPLETED'
                          ? 'Đã Hạ Bãi Xong'
                          : item.status === 'WAITING_FORKLIFT'
                          ? 'Chờ Xe Nâng & Giám Định'
                          : 'Đang Tiếp Nhận'}
                      </span>
                    </td>
                    <td className="p-3 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {item.type === 'GATE_IN' && (
                          <button
                            onClick={() => onNavigateTab('survey')}
                            className="px-2.5 py-1 bg-purple-600 hover:bg-purple-500 text-white rounded-lg text-xs font-bold shadow transition flex items-center gap-1 cursor-pointer"
                            title="Chuyển sang phân hệ giám định container này"
                          >
                            <Boxes className="w-3 h-3" />
                            <span>Giám Định</span>
                            <ArrowRight className="w-3 h-3" />
                          </button>
                        )}
                        <button
                          onClick={() => setSelectedEirModal(item)}
                          className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-bold border border-slate-700 transition cursor-pointer"
                        >
                          Xem e-EIR
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: EIR LIST */}
      {activeSubTab === 'eir_list' && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4 shadow-xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <FileText className="w-4 h-4 text-sky-400" />
                <span>Danh Sách Chứng Từ Tiếp Nhận Điện Tử (Electronic EIR)</span>
              </h3>
              <p className="text-xs text-slate-400">Tra cứu và in lại phiếu EIR phát hành tại cổng tiếp nhận Depot.</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {gateLanes.map((eir) => (
              <div
                key={eir.id}
                className="bg-slate-950 border border-slate-800 p-4 rounded-2xl space-y-3 hover:border-slate-700 transition"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-sky-400">{eir.eirNo}</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 bg-emerald-500/10 text-emerald-400 rounded">
                    Tiếp Nhận Hợp Lệ
                  </span>
                </div>
                <div>
                  <div className="text-sm font-mono font-black text-white">{eir.containerNo}</div>
                  <div className="text-xs text-slate-400">
                    {eir.shippingLine} • {eir.size} • Xe: {eir.licensePlate}
                  </div>
                </div>
                <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between">
                  <span className="text-xs text-slate-400">Vị trí: {eir.yardBlock}</span>
                  <button
                    onClick={() => setSelectedEirModal(eir)}
                    className="text-xs text-blue-400 hover:text-blue-300 font-bold flex items-center gap-1 cursor-pointer"
                  >
                    <Eye className="w-3.5 h-3.5" /> Chi Tiết
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 5: TARIFFS REFERENCE */}
      {activeSubTab === 'tariffs' && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4 shadow-xl">
          <div className="pb-3 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-amber-400" />
                <span>Quy Định & Biểu Phí Tham Khảo (Depot Tariffs Reference)</span>
              </h3>
              <p className="text-xs text-slate-400">
                Lưu ý: Biểu phí được tính và thu tập trung tại bước Giám định & Khai thác dịch vụ sau khi kiểm tra vỏ cont.
              </p>
            </div>
            <button
              onClick={() => onNavigateTab('operation')}
              className="px-3 py-1.5 bg-emerald-600/20 hover:bg-emerald-600 text-emerald-300 hover:text-white border border-emerald-500/30 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
            >
              <span>Đến Khai Thác Gate-In</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2">
              <h4 className="text-xs font-bold text-sky-400 uppercase">1. Biểu Cước Nâng Hạ Tiêu Chuẩn (Lift-on / Lift-off)</h4>
              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-300">Hạ bãi vỏ rỗng 20ft (Lift-off 20DC)</span>
                  <span className="font-mono font-bold text-white">260.000 đ</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-300">Hạ bãi vỏ rỗng 40ft/45ft (Lift-off 40HC)</span>
                  <span className="font-mono font-bold text-white">385.000 đ</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-300">Nâng cấp vỏ rỗng 20ft (Lift-on 20DC)</span>
                  <span className="font-mono font-bold text-white">260.000 đ</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-300">Nâng cấp vỏ rỗng 40ft/45ft (Lift-on 40HC)</span>
                  <span className="font-mono font-bold text-white">385.000 đ</span>
                </div>
              </div>
            </div>

            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2">
              <h4 className="text-xs font-bold text-emerald-400 uppercase">2. Phí Lưu Bãi & Dịch Vụ Phụ (Storage & Surcharges)</h4>
              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-300">Lưu bãi miễn phí (Free-days)</span>
                  <span className="font-mono font-bold text-emerald-400">07 Ngày Đầu</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-300">Lưu bãi cont 20ft (từ ngày thứ 8)</span>
                  <span className="font-mono font-bold text-white">35.000 đ / ngày</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-300">Lưu bãi cont 40ft (từ ngày thứ 8)</span>
                  <span className="font-mono font-bold text-white">65.000 đ / ngày</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-300">Phí cắm điện chạy lạnh PTI</span>
                  <span className="font-mono font-bold text-white">180.000 đ / block 8h</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SUCCESS MODAL / EIR PREVIEW */}
      {isSuccessModalOpen && createdEir && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl sm:rounded-3xl max-w-lg w-full p-4 sm:p-6 space-y-4 sm:space-y-5 shadow-2xl animate-fade-in max-h-[92vh] overflow-y-auto">
            <div className="text-center space-y-2">
              <div className="w-12 h-12 sm:w-14 sm:h-14 bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-6 h-6 sm:w-8 sm:h-8" />
              </div>
              <h3 className="text-base sm:text-lg font-bold text-white">TIẾP NHẬN CONTAINER THÀNH CÔNG!</h3>
              <p className="text-xs text-slate-400">
                Mã chứng từ e-EIR: <span className="font-mono font-bold text-emerald-400">{createdEir.eirNo}</span>
              </p>
            </div>

            <div className="bg-slate-950 p-3.5 sm:p-4 rounded-xl sm:rounded-2xl border border-slate-800 space-y-2 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-800/80">
                <span className="text-slate-400">Số Container:</span>
                <span className="font-mono font-bold text-sky-400">{createdEir.containerNo}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/80">
                <span className="text-slate-400">Hãng Tàu & Kích Thước:</span>
                <span className="font-bold text-white">{createdEir.shippingLine} ({createdEir.size})</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/80">
                <span className="text-slate-400">Phương Tiện / Bác Tài:</span>
                <span className="font-mono text-white">{createdEir.licensePlate} • {createdEir.driverName}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/80">
                <span className="text-slate-400">Mục Đích:</span>
                <span className="font-bold text-emerald-400">{createdEir.condition}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/80">
                <span className="text-slate-400">Bệ Giám Định Chỉ Định:</span>
                <span className="font-bold text-purple-300">{createdEir.surveyBay}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-400">Vị Trí Dự Kiến Bãi:</span>
                <span className="font-mono font-bold text-teal-400">{createdEir.yardLocation}</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-2.5 sm:gap-3">
              <button
                onClick={() => setIsSuccessModalOpen(false)}
                className="w-full sm:flex-1 py-3 sm:py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl border border-slate-700 transition cursor-pointer"
              >
                Đóng
              </button>
              <button
                onClick={() => {
                  setIsSuccessModalOpen(false);
                  onNavigateTab('survey');
                }}
                className="w-full sm:flex-1 py-3 sm:py-2.5 bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold rounded-xl shadow-lg transition flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <span>Chuyển Sang Giám Định</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* DETAIL EIR MODAL */}
      {selectedEirModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl sm:rounded-3xl max-w-md w-full p-4 sm:p-6 space-y-4 shadow-2xl max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <FileText className="w-4 h-4 text-sky-400" />
                <span>Chi Tiết Phiếu Tiếp Nhận e-EIR</span>
              </h3>
              <button
                onClick={() => setSelectedEirModal(null)}
                className="text-slate-400 hover:text-white text-sm p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="space-y-2 text-xs bg-slate-950 p-3.5 sm:p-4 rounded-xl sm:rounded-2xl border border-slate-800">
              <div className="flex justify-between">
                <span className="text-slate-400">Số Phiếu EIR:</span>
                <span className="font-mono font-bold text-sky-400">{selectedEirModal.eirNo}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Số Container:</span>
                <span className="font-mono font-bold text-white">{selectedEirModal.containerNo}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Hãng Tàu:</span>
                <span className="font-bold text-white">{selectedEirModal.shippingLine}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Kích Thước:</span>
                <span className="font-mono text-white">{selectedEirModal.size}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Phương Tiện / Bác Tài:</span>
                <span className="font-mono text-white">
                  {selectedEirModal.licensePlate} ({selectedEirModal.driverName || 'N/A'})
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Thời Gian Check-In:</span>
                <span className="text-slate-300">{selectedEirModal.arrivalTime}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Vị Trí Hạ Bãi:</span>
                <span className="font-mono text-teal-400 font-bold">{selectedEirModal.yardBlock}</span>
              </div>
              {selectedEirModal.surveyBay && (
                <div className="flex justify-between">
                  <span className="text-slate-400">Bệ Giám Định:</span>
                  <span className="text-purple-300 font-bold">{selectedEirModal.surveyBay}</span>
                </div>
              )}
            </div>

            <div className="flex flex-col sm:flex-row gap-2 pt-2">
              <button
                onClick={() => setSelectedEirModal(null)}
                className="w-full sm:flex-1 py-3 sm:py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl border border-slate-700 transition cursor-pointer"
              >
                Đóng
              </button>
              <button
                onClick={() => {
                  setSelectedEirModal(null);
                }}
                className="w-full sm:flex-1 py-3 sm:py-2.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-4 h-4" /> In Phiếu EIR
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
