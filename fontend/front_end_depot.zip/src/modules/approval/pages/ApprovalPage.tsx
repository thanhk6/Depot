import React, { useState, useMemo } from 'react';
import { ContainerRecord } from '../../../services/mockDataStore';
import { formatVND } from '../../../utils/format';
import { 
  CheckSquare, 
  Check, 
  X, 
  AlertCircle, 
  Eye, 
  Image as ImageIcon, 
  Search, 
  Filter, 
  FileText, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Wrench, 
  ArrowRight, 
  ShieldCheck,
  Building2,
  Calendar,
  DollarSign,
  AlertTriangle,
  RotateCcw
} from 'lucide-react';

interface ApprovalPageProps {
  containers: ContainerRecord[];
  onApproveEstimate: (
    containerId: string, 
    authData?: { authCode: string; approvedAmount: number; notes?: string }
  ) => void;
  onRejectEstimate: (
    containerId: string, 
    reason: string, 
    rejectCode?: string
  ) => void;
  onNavigateTab: (tabId: string) => void;
}

export const ApprovalPage: React.FC<ApprovalPageProps> = ({
  containers,
  onApproveEstimate,
  onRejectEstimate,
  onNavigateTab
}) => {
  // Sync with localStorage estimates list for extra details
  const localEstimates = useMemo(() => {
    try {
      const saved = localStorage.getItem('DEPOT_ESTIMATES_LIST');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return [];
  }, []);

  // Containers with estimate or waiting approval or already approved/rejected
  const approvalContainers = useMemo(() => {
    return containers.filter(
      (c) =>
        c.estimateDetails ||
        c.status === 'WAITING_APPROVAL' ||
        c.status === 'APPROVED' ||
        c.status === 'REPAIRING' ||
        c.status === 'WAITING_ESTIMATE' ||
        c.condition === 'DM'
    );
  }, [containers]);

  // Tab & Filters state
  const [activeTab, setActiveTab] = useState<'ALL' | 'PENDING' | 'APPROVED' | 'REJECTED'>('ALL');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedShippingLine, setSelectedShippingLine] = useState('ALL');

  // Modal states
  const [selectedContForAction, setSelectedContForAction] = useState<ContainerRecord | null>(null);
  const [actionType, setActionType] = useState<'APPROVE' | 'REJECT' | 'VIEW' | null>(null);

  // Approval Form State
  const [authCode, setAuthCode] = useState('');
  const [approvedAmount, setApprovedAmount] = useState<number>(0);
  const [approvalNotes, setApprovalNotes] = useState('');

  // Rejection Form State
  const [rejectReasonType, setRejectReasonType] = useState('CEDEX_PRICE_EXCEEDED');
  const [customRejectReason, setCustomRejectReason] = useState(
    'Đơn giá vật tư thép lá và sàn gỗ cao hơn hợp đồng khung năm 2026'
  );

  // Toast notification
  const [toastMessage, setToastMessage] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);

  const showToast = (text: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToastMessage({ type, text });
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Shipping lines list
  const shippingLines = useMemo(() => {
    const lines = new Set<string>();
    approvalContainers.forEach((c) => {
      if (c.shippingLine) lines.add(c.shippingLine);
    });
    return Array.from(lines);
  }, [approvalContainers]);

  // Determine Approval status of container
  const getContainerApprovalStatus = (c: ContainerRecord): 'PENDING' | 'APPROVED' | 'REJECTED' => {
    if (c.estimateDetails?.approvalStatus === 'APPROVED' || c.status === 'APPROVED' || c.status === 'REPAIRING' || c.status === 'READY_FOR_USE') {
      return 'APPROVED';
    }
    if (c.estimateDetails?.approvalStatus === 'REJECTED') {
      return 'REJECTED';
    }
    return 'PENDING';
  };

  // Filtered List
  const filteredList = useMemo(() => {
    return approvalContainers.filter((c) => {
      const status = getContainerApprovalStatus(c);

      // Filter by Tab
      if (activeTab === 'PENDING' && status !== 'PENDING') return false;
      if (activeTab === 'APPROVED' && status !== 'APPROVED') return false;
      if (activeTab === 'REJECTED' && status !== 'REJECTED') return false;

      // Filter by Shipping line
      if (selectedShippingLine !== 'ALL' && c.shippingLine !== selectedShippingLine) {
        return false;
      }

      // Search container or estimate no
      if (searchTerm) {
        const query = searchTerm.toLowerCase();
        const matchCont = c.containerNo.toLowerCase().includes(query);
        const matchEst = (c.estimateDetails?.estimateNo || '').toLowerCase().includes(query);
        const matchLine = c.shippingLine.toLowerCase().includes(query);
        if (!matchCont && !matchEst && !matchLine) return false;
      }

      return true;
    });
  }, [approvalContainers, activeTab, selectedShippingLine, searchTerm]);

  // Statistics count
  const stats = useMemo(() => {
    const total = approvalContainers.length;
    const pending = approvalContainers.filter((c) => getContainerApprovalStatus(c) === 'PENDING').length;
    const approved = approvalContainers.filter((c) => getContainerApprovalStatus(c) === 'APPROVED').length;
    const rejected = approvalContainers.filter((c) => getContainerApprovalStatus(c) === 'REJECTED').length;
    const totalAmount = approvalContainers.reduce((sum, c) => sum + (c.estimateDetails?.totalCost || 0), 0);
    return { total, pending, approved, rejected, totalAmount };
  }, [approvalContainers]);

  // Open Approval Modal
  const handleOpenApproveModal = (c: ContainerRecord) => {
    setSelectedContForAction(c);
    const estCost = c.estimateDetails?.totalCost || 2440000;
    setApprovedAmount(estCost);
    const linePrefix = (c.shippingLine || 'CARRIER').substring(0, 4).toUpperCase();
    setAuthCode(`${linePrefix}-AUTH-${Math.floor(100000 + Math.random() * 900000)}`);
    setApprovalNotes(`Phê duyệt 100% hạng mục sửa chữa EMR theo báo giá ${c.estimateDetails?.estimateNo || ''}`);
    setActionType('APPROVE');
  };

  // Open Rejection Modal
  const handleOpenRejectModal = (c: ContainerRecord) => {
    setSelectedContForAction(c);
    setRejectReasonType('CEDEX_PRICE_EXCEEDED');
    setCustomRejectReason('Đơn giá vật tư thép lá và sàn gỗ cao hơn hợp đồng khung năm 2026. Đề xuất điều chỉnh giảm 15% hoặc chuyển sang phương pháp nắn vá.');
    setActionType('REJECT');
  };

  // Open View Modal
  const handleOpenViewModal = (c: ContainerRecord) => {
    setSelectedContForAction(c);
    setActionType('VIEW');
  };

  // Execute Approval
  const handleConfirmApproval = () => {
    if (!selectedContForAction) return;

    onApproveEstimate(selectedContForAction.id, {
      authCode,
      approvedAmount,
      notes: approvalNotes
    });

    // Also update DEPOT_ESTIMATES_LIST in localStorage if matching container
    try {
      const saved = localStorage.getItem('DEPOT_ESTIMATES_LIST');
      if (saved) {
        const estList = JSON.parse(saved);
        const updatedEstList = estList.map((est: any) => {
          if (est.containerNo === selectedContForAction.containerNo || est.containerId === selectedContForAction.id) {
            return {
              ...est,
              status: 'APPROVED',
              carrierApproval: {
                status: 'APPROVED',
                authCode,
                approvedAmount,
                approvedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
                approvedBy: `Đại diện Hãng tàu ${selectedContForAction.shippingLine}`,
                comments: approvalNotes
              }
            };
          }
          return est;
        });
        localStorage.setItem('DEPOT_ESTIMATES_LIST', JSON.stringify(updatedEstList));
      }
    } catch {
      // ignore
    }

    showToast(`Hãng tàu ${selectedContForAction.shippingLine} đã PHÊ DUYỆT Báo giá cho Container ${selectedContForAction.containerNo}! Mã ủy quyền: ${authCode}`, 'success');
    setActionType(null);
    setSelectedContForAction(null);
  };

  // Execute Rejection
  const handleConfirmRejection = () => {
    if (!selectedContForAction) return;

    onRejectEstimate(selectedContForAction.id, customRejectReason, rejectReasonType);

    // Also update DEPOT_ESTIMATES_LIST in localStorage if matching container
    try {
      const saved = localStorage.getItem('DEPOT_ESTIMATES_LIST');
      if (saved) {
        const estList = JSON.parse(saved);
        const updatedEstList = estList.map((est: any) => {
          if (est.containerNo === selectedContForAction.containerNo || est.containerId === selectedContForAction.id) {
            return {
              ...est,
              status: 'REJECTED',
              carrierApproval: {
                status: 'REJECTED',
                rejectCode: rejectReasonType,
                rejectReason: customRejectReason,
                approvedAmount: 0,
                approvedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
                approvedBy: `Đại diện Hãng tàu ${selectedContForAction.shippingLine}`,
                comments: customRejectReason
              }
            };
          }
          return est;
        });
        localStorage.setItem('DEPOT_ESTIMATES_LIST', JSON.stringify(updatedEstList));
      }
    } catch {
      // ignore
    }

    showToast(`Hãng tàu ${selectedContForAction.shippingLine} ĐÃ TỪ CHỐI Báo giá cho Container ${selectedContForAction.containerNo}!`, 'error');
    setActionType(null);
    setSelectedContForAction(null);
  };

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {toastMessage && (
        <div
          className={`fixed top-5 right-5 z-50 p-4 rounded-2xl shadow-2xl border text-xs font-bold flex items-center gap-2 animate-bounce ${
            toastMessage.type === 'success'
              ? 'bg-emerald-950 text-emerald-300 border-emerald-500'
              : toastMessage.type === 'error'
              ? 'bg-rose-950 text-rose-300 border-rose-500'
              : 'bg-blue-950 text-blue-300 border-blue-500'
          }`}
        >
          {toastMessage.type === 'success' ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
          ) : (
            <AlertCircle className="w-5 h-5 text-rose-400" />
          )}
          <span>{toastMessage.text}</span>
        </div>
      )}

      {/* Header Banner */}
      <div className="p-6 bg-slate-900 border border-slate-800 rounded-3xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-purple-600/20 border border-purple-500/30 text-purple-400 rounded-2xl">
            <CheckSquare className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 bg-purple-950 text-purple-400 border border-purple-800 text-[11px] font-bold rounded-md font-mono">
                7. DUYỆT BÁO GIÁ HÃNG TÀU
              </span>
              <h2 className="text-xl font-bold text-white">Cổng Phê Duyệt &amp; Tiếp Nhận Quyết Định Hãng Tàu</h2>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Dành cho Đại diện Hãng tàu (MSC, Maersk, CMA CGM, COSCO, ONE...): Phê duyệt chi phí EMR, cấp Authorization Code hoặc từ chối kèm lý do.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => onNavigateTab('estimate')}
            className="px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl border border-slate-700 transition flex items-center gap-1.5 cursor-pointer"
          >
            <FileText className="w-4 h-4 text-amber-400" />
            <span>Màn Hình 6. Báo Giá EMR</span>
          </button>

          <button
            onClick={() => onNavigateTab('repair')}
            className="px-3.5 py-2.5 bg-rose-600/20 hover:bg-rose-600/40 text-rose-300 text-xs font-bold rounded-xl border border-rose-500/30 transition flex items-center gap-1.5 cursor-pointer"
          >
            <Wrench className="w-4 h-4" />
            <span>Lệnh Sửa Chữa (Work Order)</span>
          </button>
        </div>
      </div>

      {/* KPI Stats Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800">
          <div className="text-[10px] text-slate-500 uppercase font-semibold">Tổng Hồ Sơ Báo Giá</div>
          <div className="text-xl font-mono font-bold text-white mt-1">{stats.total}</div>
        </div>

        <div 
          onClick={() => setActiveTab('PENDING')}
          className={`p-4 bg-slate-900 rounded-2xl border transition cursor-pointer ${
            activeTab === 'PENDING' ? 'border-amber-500 ring-1 ring-amber-500' : 'border-amber-900/40 hover:border-amber-700'
          }`}
        >
          <div className="text-[10px] text-amber-400 uppercase font-semibold flex items-center justify-between">
            <span>Chờ Hãng Tàu Duyệt</span>
            <Clock className="w-3.5 h-3.5" />
          </div>
          <div className="text-xl font-mono font-bold text-amber-300 mt-1">{stats.pending}</div>
        </div>

        <div 
          onClick={() => setActiveTab('APPROVED')}
          className={`p-4 bg-slate-900 rounded-2xl border transition cursor-pointer ${
            activeTab === 'APPROVED' ? 'border-emerald-500 ring-1 ring-emerald-500' : 'border-emerald-900/40 hover:border-emerald-700'
          }`}
        >
          <div className="text-[10px] text-emerald-400 uppercase font-semibold flex items-center justify-between">
            <span>Hãng Tàu ĐÃ DUYỆT</span>
            <CheckCircle2 className="w-3.5 h-3.5" />
          </div>
          <div className="text-xl font-mono font-bold text-emerald-300 mt-1">{stats.approved}</div>
        </div>

        <div 
          onClick={() => setActiveTab('REJECTED')}
          className={`p-4 bg-slate-900 rounded-2xl border transition cursor-pointer ${
            activeTab === 'REJECTED' ? 'border-purple-500 ring-1 ring-purple-500' : 'border-purple-900/40 hover:border-purple-700'
          }`}
        >
          <div className="text-[10px] text-purple-400 uppercase font-semibold flex items-center justify-between">
            <span>TỪ CHỐI / KHÔNG DUYỆT</span>
            <XCircle className="w-3.5 h-3.5" />
          </div>
          <div className="text-xl font-mono font-bold text-purple-300 mt-1">{stats.rejected}</div>
        </div>

        <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800">
          <div className="text-[10px] text-slate-500 uppercase font-semibold">Tổng Giá Trị Đề Xuất</div>
          <div className="text-sm font-mono font-bold text-emerald-400 mt-1 truncate" title={formatVND(stats.totalAmount)}>
            {formatVND(stats.totalAmount)}
          </div>
        </div>
      </div>

      {/* Filter Tabs & Search Bar */}
      <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl space-y-4">
        {/* Status Tabs */}
        <div className="flex items-center justify-between flex-wrap gap-3 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => setActiveTab('ALL')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                activeTab === 'ALL'
                  ? 'bg-purple-600 text-white shadow-lg'
                  : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              Tất Cả Hồ Sơ ({stats.total})
            </button>

            <button
              onClick={() => setActiveTab('PENDING')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'PENDING'
                  ? 'bg-amber-600 text-white shadow-lg'
                  : 'bg-slate-950 text-amber-400 hover:text-white border border-amber-900/40'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              <span>Chờ Phê Duyệt ({stats.pending})</span>
            </button>

            <button
              onClick={() => setActiveTab('APPROVED')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'APPROVED'
                  ? 'bg-emerald-600 text-white shadow-lg'
                  : 'bg-slate-950 text-emerald-400 hover:text-white border border-emerald-900/40'
              }`}
            >
              <Check className="w-3.5 h-3.5" />
              <span>Hãng Tàu Đã Duyệt ({stats.approved})</span>
            </button>

            <button
              onClick={() => setActiveTab('REJECTED')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'REJECTED'
                  ? 'bg-purple-600 text-white shadow-lg'
                  : 'bg-slate-950 text-purple-400 hover:text-white border border-purple-900/40'
              }`}
            >
              <X className="w-3.5 h-3.5" />
              <span>Từ Chối / Không Duyệt ({stats.rejected})</span>
            </button>
          </div>

          <span className="text-xs text-slate-400">
            Hiển thị <strong className="text-white">{filteredList.length}</strong> kết quả
          </span>
        </div>

        {/* Search Controls */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="sm:col-span-2 relative">
            <input
              type="text"
              placeholder="Tìm theo số container (MSCU...), mã báo giá (EST-...), hãng tàu..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs font-mono text-white focus:outline-none focus:border-purple-500"
            />
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
          </div>

          <div>
            <select
              value={selectedShippingLine}
              onChange={(e) => setSelectedShippingLine(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs font-bold text-white focus:outline-none"
            >
              <option value="ALL">-- Tất cả Hãng Tàu --</option>
              {shippingLines.map((line) => (
                <option key={line} value={line}>
                  {line}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Main Table: Danh Sách Báo Giá Hãng Tàu */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-950 border-b border-slate-800 text-[11px] text-slate-400 font-mono">
                <th className="p-4">Số Container</th>
                <th className="p-4">Hãng Tàu</th>
                <th className="p-4">Mã Báo Giá / Ngày Gửi</th>
                <th className="p-4 text-right">Tổng Tiền Báo Giá</th>
                <th className="p-4">Quyết Định Hãng Tàu</th>
                <th className="p-4">Chi Tiết Quyết Định / Lý Do</th>
                <th className="p-4 text-right">Thao Tác Phê Duyệt</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredList.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-12 text-center text-slate-500">
                    <FileText className="w-10 h-10 mx-auto mb-2 text-slate-600" />
                    <p className="text-sm font-semibold text-slate-400">Không tìm thấy hồ sơ báo giá nào phù hợp với bộ lọc.</p>
                    <p className="text-xs text-slate-500 mt-1">Hãy chuyển đổi tab bộ lọc hoặc xóa từ khóa tìm kiếm.</p>
                  </td>
                </tr>
              ) : (
                filteredList.map((c) => {
                  const status = getContainerApprovalStatus(c);
                  const estCost = c.estimateDetails?.totalCost || 2440000;
                  const estNo = c.estimateDetails?.estimateNo || `EST-${c.shippingLine}-${c.id.replace('CONT-', '')}`;
                  
                  // Match with local estimate if any
                  const matchedLocal = localEstimates.find(
                    (le: any) => le.containerNo === c.containerNo || le.id === c.id
                  );

                  const authCodeDisplay = matchedLocal?.carrierApproval?.authCode || (status === 'APPROVED' ? `AUTH-${c.shippingLine}-88910` : null);
                  const rejectReasonDisplay = c.estimateDetails?.rejectReason || matchedLocal?.carrierApproval?.rejectReason || (status === 'REJECTED' ? 'Đơn giá vật tư vượt hợp đồng khung' : null);

                  return (
                    <tr key={c.id} className="hover:bg-slate-800/40 transition">
                      {/* Container No */}
                      <td className="p-4">
                        <div className="font-mono font-bold text-white text-sm">{c.containerNo}</div>
                        <div className="text-[11px] text-slate-400">
                          {c.size} &bull; {c.isoCode} &bull; <span className="text-rose-400 font-bold">DM</span>
                        </div>
                      </td>

                      {/* Shipping Line */}
                      <td className="p-4">
                        <span className="font-mono font-bold text-blue-400 bg-blue-950/60 px-2.5 py-1 rounded-lg border border-blue-800 text-xs">
                          {c.shippingLine}
                        </span>
                      </td>

                      {/* Estimate No & Date */}
                      <td className="p-4">
                        <div className="font-mono font-bold text-purple-300">{estNo}</div>
                        <div className="text-[11px] text-slate-400 flex items-center gap-1 mt-0.5">
                          <Calendar className="w-3 h-3 text-slate-500" />
                          <span>{c.estimateDetails?.createdAt || c.gateInDate}</span>
                        </div>
                      </td>

                      {/* Total Proposed Cost */}
                      <td className="p-4 text-right">
                        <div className="font-mono font-black text-emerald-400 text-sm">
                          {formatVND(estCost)}
                        </div>
                        <div className="text-[10px] text-slate-500 font-mono">
                          {c.estimateDetails?.labourHours || 3.5}h công + Vật tư
                        </div>
                      </td>

                      {/* Approval Status Badge */}
                      <td className="p-4">
                        {status === 'APPROVED' ? (
                          <span className="px-2.5 py-1 bg-emerald-950 text-emerald-400 border border-emerald-800 rounded-lg text-xs font-bold font-mono inline-flex items-center gap-1.5">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>ĐÃ DUYỆT (Approved)</span>
                          </span>
                        ) : status === 'REJECTED' ? (
                          <span className="px-2.5 py-1 bg-purple-950 text-purple-300 border border-purple-800 rounded-lg text-xs font-bold font-mono inline-flex items-center gap-1.5">
                            <XCircle className="w-3.5 h-3.5 text-purple-400" />
                            <span>TỪ CHỐI (Rejected)</span>
                          </span>
                        ) : (
                          <span className="px-2.5 py-1 bg-amber-950 text-amber-300 border border-amber-800 rounded-lg text-xs font-bold font-mono inline-flex items-center gap-1.5 animate-pulse">
                            <Clock className="w-3.5 h-3.5" />
                            <span>Chờ Phê Duyệt</span>
                          </span>
                        )}
                      </td>

                      {/* Decision Details */}
                      <td className="p-4 max-w-xs">
                        {status === 'APPROVED' ? (
                          <div className="space-y-1">
                            <div className="text-xs font-mono font-bold text-emerald-300">
                              Mã duyệt: {authCodeDisplay}
                            </div>
                            <div className="text-[11px] text-slate-400">
                              Duyệt 100% &bull; Đã cấp phép thi công
                            </div>
                            <button
                              onClick={() => onNavigateTab('repair')}
                              className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-400 hover:text-emerald-300 hover:underline cursor-pointer"
                            >
                              <Wrench className="w-3 h-3" />
                              <span>Chuyển sang sửa chữa &rarr;</span>
                            </button>
                          </div>
                        ) : status === 'REJECTED' ? (
                          <div>
                            <div className="text-xs font-bold text-rose-400 flex items-center gap-1">
                              <AlertTriangle className="w-3 h-3" />
                              <span>Lý do từ chối:</span>
                            </div>
                            <div className="text-[11px] text-rose-200 line-clamp-2 mt-0.5" title={rejectReasonDisplay || ''}>
                              {rejectReasonDisplay}
                            </div>
                          </div>
                        ) : (
                          <div className="text-xs text-slate-400 italic">
                            Đang chờ đại diện Hãng tàu xem xét và phản hồi
                          </div>
                        )}
                      </td>

                      {/* Action Buttons */}
                      <td className="p-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {status === 'PENDING' ? (
                            <>
                              <button
                                onClick={() => handleOpenApproveModal(c)}
                                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold text-xs shadow-md transition cursor-pointer flex items-center gap-1"
                                title="Phê duyệt báo giá"
                              >
                                <Check className="w-3.5 h-3.5" />
                                <span>Duyệt (Approve)</span>
                              </button>

                              <button
                                onClick={() => handleOpenRejectModal(c)}
                                className="px-2.5 py-1.5 bg-purple-950/60 hover:bg-purple-900 text-purple-300 border border-purple-800 rounded-xl font-bold text-xs transition cursor-pointer flex items-center gap-1"
                                title="Từ chối / Yêu cầu sửa đổi"
                              >
                                <X className="w-3.5 h-3.5" />
                                <span>Không Duyệt</span>
                              </button>
                            </>
                          ) : status === 'APPROVED' ? (
                            <button
                              onClick={() => onNavigateTab('repair')}
                              className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold text-xs shadow-md shadow-emerald-950 transition cursor-pointer flex items-center gap-1.5 shrink-0 whitespace-nowrap"
                              title="Chuyển sang phân hệ Sửa Chữa thi công Work Order"
                            >
                              <Wrench className="w-3.5 h-3.5" />
                              <span>Chuyển Qua Sửa Chữa</span>
                            </button>
                          ) : (
                            <button
                              onClick={() => handleOpenApproveModal(c)}
                              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl font-bold text-xs transition cursor-pointer flex items-center gap-1"
                              title="Xét duyệt lại"
                            >
                              <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
                              <span>Duyệt Lại</span>
                            </button>
                          )}

                          {/* View details */}
                          <button
                            onClick={() => handleOpenViewModal(c)}
                            className="p-1.5 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl transition cursor-pointer"
                            title="Xem chi tiết biên bản & ảnh IICL"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL 1: CARRIER APPROVAL CONFIRMATION */}
      {actionType === 'APPROVE' && selectedContForAction && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden">
            <div className="p-5 border-b border-slate-800 bg-emerald-950/40 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-emerald-600 text-white rounded-xl">
                  <CheckCircle2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">
                    Hãng Tàu Phê Duyệt Báo Giá (Carrier Approval)
                  </h3>
                  <p className="text-xs text-emerald-300">
                    Container: <strong className="font-mono text-white">{selectedContForAction.containerNo}</strong> ({selectedContForAction.shippingLine})
                  </p>
                </div>
              </div>
              <button
                onClick={() => setActionType(null)}
                className="p-2 text-slate-400 hover:text-white rounded-xl cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs">
              <div className="p-3.5 bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-500 uppercase font-semibold block">Mã Báo Giá EMR</span>
                  <span className="font-mono font-bold text-purple-300 text-sm">
                    {selectedContForAction.estimateDetails?.estimateNo || 'EST-20260816-00001'}
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-500 uppercase font-semibold block">Chi Phí Đề Xuất</span>
                  <span className="font-mono font-black text-emerald-400 text-base">
                    {formatVND(selectedContForAction.estimateDetails?.totalCost || 2440000)}
                  </span>
                </div>
              </div>

              {/* Input Authorization Code */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                  Mã Phê Duyệt Hãng Tàu (Carrier Authorization Code)*:
                </label>
                <input
                  type="text"
                  value={authCode}
                  onChange={(e) => setAuthCode(e.target.value)}
                  placeholder="MSCU-AUTH-882190..."
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl font-mono text-sm font-bold text-amber-300 focus:outline-none focus:border-emerald-500"
                />
              </div>

              {/* Input Approved Amount */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                  Số Tiền Hãng Tàu Duyệt (VND)*:
                </label>
                <input
                  type="number"
                  value={approvedAmount}
                  onChange={(e) => setApprovedAmount(Number(e.target.value))}
                  className="w-full px-3.5 py-2 bg-slate-950 border border-slate-700 rounded-xl font-mono text-sm font-bold text-emerald-400 focus:outline-none focus:border-emerald-500"
                />
              </div>

              {/* Input Notes */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                  Ghi Chú Phê Duyệt / Hướng Dẫn Kỹ Thuật Cho Depot:
                </label>
                <textarea
                  rows={2}
                  value={approvalNotes}
                  onChange={(e) => setApprovalNotes(e.target.value)}
                  className="w-full px-3.5 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="p-3 bg-emerald-950/30 border border-emerald-800/40 rounded-xl text-emerald-300 text-[11px] leading-relaxed">
                &bull; Sau khi xác nhận phê duyệt, hệ thống sẽ tự động chuyển hồ sơ sang trạng thái <strong>APPROVED</strong> và kích hoạt phát hành <strong>Lệnh Sửa Chữa Work Order</strong> cho tổ kỹ thuật Depot.
              </div>
            </div>

            <div className="p-4 border-t border-slate-800 bg-slate-950 flex items-center justify-end gap-3">
              <button
                onClick={() => setActionType(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-bold transition cursor-pointer"
              >
                Hủy Bỏ
              </button>

              <button
                onClick={handleConfirmApproval}
                disabled={!authCode}
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold shadow-lg shadow-emerald-600/30 transition flex items-center gap-2 cursor-pointer disabled:opacity-50"
              >
                <Check className="w-4 h-4" />
                <span>Xác Nhận Phê Duyệt (Approve)</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: CARRIER REJECTION / REVISION REQUIRED */}
      {actionType === 'REJECT' && selectedContForAction && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden">
            <div className="p-5 border-b border-slate-800 bg-purple-950/40 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-purple-600 text-white rounded-xl">
                  <XCircle className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">
                    Hãng Tàu Từ Chối Báo Giá (Carrier Rejection)
                  </h3>
                  <p className="text-xs text-purple-300">
                    Container: <strong className="font-mono text-white">{selectedContForAction.containerNo}</strong> ({selectedContForAction.shippingLine})
                  </p>
                </div>
              </div>
              <button
                onClick={() => setActionType(null)}
                className="p-2 text-slate-400 hover:text-white rounded-xl cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs">
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                  Chọn Danh Mục Lý Do Từ Chối Tiêu Chuẩn (CEDEX Reason Code)*:
                </label>
                <select
                  value={rejectReasonType}
                  onChange={(e) => {
                    setRejectReasonType(e.target.value);
                    if (e.target.value === 'CEDEX_PRICE_EXCEEDED') {
                      setCustomRejectReason('Đơn giá vật tư thép lá/sàn gỗ cao hơn hợp đồng khung năm 2026. Đề xuất điều chỉnh giảm.');
                    } else if (e.target.value === 'WEAR_AND_TEAR') {
                      setCustomRejectReason('Hư hỏng thuộc diện hao mòn tự nhiên (Wear & Tear) theo tiêu chuẩn IICL-6. Hãng tàu không thanh toán.');
                    } else if (e.target.value === 'CHANGE_REPAIR_METHOD') {
                      setCustomRejectReason('Đề nghị đổi phương pháp: Nắn thẳng gia nhiệt (SN) hoặc Vá đắp (P) thay vì Thay mới nguyên tấm (R).');
                    } else if (e.target.value === 'LACK_INSPECTION_PHOTOS') {
                      setCustomRejectReason('Hình ảnh giám định không đủ rõ nét hoặc thiếu ảnh chụp thước kẹp đo độ võng/móp méo.');
                    } else if (e.target.value === 'CONTAINER_DISPOSAL') {
                      setCustomRejectReason('Container đã có kế hoạch trả rỗng bán phế liệu, ngưng cấp lệnh sửa chữa.');
                    }
                  }}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl font-bold text-white focus:outline-none focus:border-purple-500"
                >
                  <option value="CEDEX_PRICE_EXCEEDED">1. Đơn giá vật tư/nhân công vượt hợp đồng khung (Over Tariff)</option>
                  <option value="WEAR_AND_TEAR">2. Tổn thất do hao mòn tự nhiên (Wear &amp; Tear - Non billable)</option>
                  <option value="CHANGE_REPAIR_METHOD">3. Yêu cầu đổi phương pháp sửa chữa (Nắn/Vá thay vì Thay mới)</option>
                  <option value="LACK_INSPECTION_PHOTOS">4. Thiếu hình ảnh giám định đối chứng IICL hoặc ảnh mờ</option>
                  <option value="CONTAINER_DISPOSAL">5. Container ngưng khai thác / chuyển bán thanh lý</option>
                  <option value="OTHER">6. Lý do khác (Nhập chi tiết bên dưới)</option>
                </select>
              </div>

              {/* Detailed Reason Text */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                  Chi Tiết Lý Do Từ Chối &amp; Hướng Dẫn Depot Lập Lại Báo Giá*:
                </label>
                <textarea
                  rows={3}
                  value={customRejectReason}
                  onChange={(e) => setCustomRejectReason(e.target.value)}
                  placeholder="Ghi rõ chi tiết hạng mục bị từ chối và hướng xử lý..."
                  className="w-full px-3.5 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-purple-500"
                />
              </div>

              <div className="p-3 bg-purple-950/30 border border-purple-800/40 rounded-xl text-purple-300 text-[11px] leading-relaxed">
                &bull; Khi từ chối, báo giá sẽ chuyển sang trạng thái <strong>REJECTED</strong>. Nhân viên báo giá Depot sẽ nhận được lý do để tạo bản điều chỉnh (Revise Estimate) và trình duyệt lại.
              </div>
            </div>

            <div className="p-4 border-t border-slate-800 bg-slate-950 flex items-center justify-end gap-3">
              <button
                onClick={() => setActionType(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-bold transition cursor-pointer"
              >
                Hủy Bỏ
              </button>

              <button
                onClick={handleConfirmRejection}
                disabled={!customRejectReason}
                className="px-5 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-xl font-bold shadow-lg shadow-purple-600/30 transition flex items-center gap-2 cursor-pointer disabled:opacity-50"
              >
                <X className="w-4 h-4" />
                <span>Xác Nhận Từ Chối (Reject)</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 3: VIEW SURVEY & DAMAGE DETAILS */}
      {actionType === 'VIEW' && selectedContForAction && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            <div className="p-5 border-b border-slate-800 bg-slate-950 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-blue-600/20 border border-blue-500/30 text-blue-400 rounded-xl">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">
                    Hồ Sơ Giám Định Đối Chứng &bull; Container {selectedContForAction.containerNo}
                  </h3>
                  <p className="text-xs text-slate-400">
                    Hãng Tàu: <strong className="text-blue-400">{selectedContForAction.shippingLine}</strong> &bull; Loại: {selectedContForAction.size} ({selectedContForAction.isoCode})
                  </p>
                </div>
              </div>
              <button
                onClick={() => setActionType(null)}
                className="p-2 text-slate-400 hover:text-white rounded-xl cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-5 overflow-y-auto text-xs">
              {/* Cost Summary */}
              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-500 uppercase font-semibold block">Mã Báo Giá</span>
                  <span className="font-mono font-bold text-purple-300 text-sm">
                    {selectedContForAction.estimateDetails?.estimateNo || 'EST-MSCU-901'}
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-500 uppercase font-semibold block">Tổng Chi Phí Đề Xuất</span>
                  <span className="font-mono font-black text-emerald-400 text-lg">
                    {formatVND(selectedContForAction.estimateDetails?.totalCost || 2440000)}
                  </span>
                </div>
              </div>

              {/* Damage List */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold text-slate-300 uppercase flex items-center gap-1.5">
                  <Wrench className="w-4 h-4 text-amber-400" />
                  <span>Danh Mục Hư Hỏng Khảo Sát Hiện Trường e-EIR</span>
                </h4>

                {selectedContForAction.surveyDetails?.damages && selectedContForAction.surveyDetails.damages.length > 0 ? (
                  <div className="space-y-2">
                    {selectedContForAction.surveyDetails.damages.map((dmg, idx) => (
                      <div key={idx} className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="font-mono font-bold text-rose-400 text-xs">
                            [{dmg.code}] {dmg.location}
                          </span>
                          <span className="px-2 py-0.5 bg-rose-950 text-rose-300 border border-rose-800 text-[10px] font-bold rounded">
                            Mức độ: {dmg.severity}
                          </span>
                        </div>
                        <p className="text-slate-300 text-xs">{dmg.description}</p>
                        {dmg.image && (
                          <div className="mt-2 rounded-lg overflow-hidden border border-slate-800 max-w-sm">
                            <img src={dmg.image} alt={dmg.location} className="w-full h-36 object-cover" />
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-6 bg-slate-950 rounded-xl border border-slate-800 text-center text-slate-500">
                    <p>Không có danh mục hư hỏng chi tiết hoặc chưa cập nhật hình ảnh.</p>
                  </div>
                )}
              </div>
            </div>

            <div className="p-4 border-t border-slate-800 bg-slate-950 flex items-center justify-between">
              <span className="text-xs text-slate-400">
                Trạng thái hiện tại: <strong className="text-white">{selectedContForAction.status}</strong>
              </span>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    setActionType(null);
                    handleOpenApproveModal(selectedContForAction);
                  }}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold transition flex items-center gap-1.5 cursor-pointer text-xs"
                >
                  <Check className="w-4 h-4" />
                  <span>Duyệt Báo Giá</span>
                </button>

                <button
                  onClick={() => {
                    setActionType(null);
                    handleOpenRejectModal(selectedContForAction);
                  }}
                  className="px-4 py-2 bg-purple-950/80 hover:bg-purple-900 text-purple-300 border border-purple-800 rounded-xl font-bold transition flex items-center gap-1.5 cursor-pointer text-xs"
                >
                  <X className="w-4 h-4" />
                  <span>Từ Chối</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
