import React, { useState, useEffect } from 'react';
import {
  MOCK_STAFF_REALTIME_DATA,
  StaffRealtimeItem
} from '../mockStaffRealtimeData';
import { StaffDetailModal } from './StaffDetailModal';
import {
  Users,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Activity,
  Search,
  Filter,
  TrendingUp,
  Zap,
  Phone,
  ArrowUpRight,
  Eye,
  RefreshCw,
  FileSpreadsheet,
  Printer,
  Boxes,
  MapPin,
  ShieldCheck,
  ChevronRight,
  BarChart2
} from 'lucide-react';

export const StaffRealtimeReportTab: React.FC = () => {
  const [staffList, setStaffList] = useState<StaffRealtimeItem[]>(MOCK_STAFF_REALTIME_DATA);
  const [selectedShift, setSelectedShift] = useState<string>('ALL');
  const [selectedDept, setSelectedDept] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStaff, setSelectedStaff] = useState<StaffRealtimeItem | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<string>(new Date().toLocaleTimeString('vi-VN'));
  const [showToast, setShowToast] = useState(false);

  // Live ticker update simulation
  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setLastUpdated(new Date().toLocaleTimeString('vi-VN'));
      setIsRefreshing(false);
    }, 500);
  };

  const handleExport = () => {
    setShowToast(true);
    setTimeout(() => setShowToast(false), 3000);
  };

  const filteredStaff = staffList.filter((s) => {
    const matchSearch =
      s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.departmentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (s.currentTask && s.currentTask.containerNo.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchShift = selectedShift === 'ALL' || s.shift === selectedShift;
    const matchDept = selectedDept === 'ALL' || s.department === selectedDept;
    const matchStatus = selectedStatus === 'ALL' || s.status === selectedStatus;
    return matchSearch && matchShift && matchDept && matchStatus;
  });

  // Calculate live summary stats
  const totalStaff = staffList.length;
  const activeStaff = staffList.filter((s) => s.status === 'BUSY').length;
  const availableStaff = staffList.filter((s) => s.status === 'AVAILABLE').length;
  const totalTasksCompleted = staffList.reduce((sum, s) => sum + s.metrics.completedToday, 0);
  const totalTasksAssigned = staffList.reduce((sum, s) => sum + s.metrics.assignedToday, 0);
  const avgEfficiency = Math.round(
    staffList.reduce((sum, s) => sum + s.metrics.efficiencyPercent, 0) / staffList.length
  );
  const avgFPY = (
    staffList.reduce((sum, s) => sum + s.metrics.firstPassYieldPercent, 0) / staffList.length
  ).toFixed(1);

  const handleViewDetail = (staff: StaffRealtimeItem) => {
    setSelectedStaff(staff);
    setIsModalOpen(true);
  };

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {showToast && (
        <div className="fixed top-6 right-6 z-50 bg-emerald-600 text-white px-4 py-3 rounded-2xl shadow-2xl flex items-center gap-2 border border-emerald-400/30 animate-in fade-in slide-in-from-top-4">
          <CheckCircle2 className="w-5 h-5 text-white" />
          <span className="text-xs font-bold">
            Đã xuất báo cáo năng suất nhân sự thời gian thực ra tệp Excel (.xlsx)!
          </span>
        </div>
      )}

      {/* Top Banner Control & Live Badge */}
      <div className="p-5 sm:p-6 bg-slate-900 border border-slate-800 rounded-3xl flex flex-col lg:flex-row lg:items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center gap-4">
          <div className="p-3.5 bg-sky-500/10 border border-sky-500/20 text-sky-400 rounded-2xl shrink-0">
            <Activity className="w-8 h-8 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <h1 className="text-xl font-black text-white tracking-tight">
                BÁO CÁO CÔNG VIỆC TỪNG NHÂN SỰ THEO THỜI GIAN THỰC (REAL-TIME)
              </h1>
              <span className="px-2.5 py-0.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-full font-mono text-[11px] font-bold flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                LIVE STREAMING • {lastUpdated}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Theo dõi trực tiếp từng nhân viên đang thao tác container nào, vị trí bãi/xưởng, tiến độ thi công và hiệu suất đạt chỉ tiêu ca
            </p>
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handleRefresh}
            disabled={isRefreshing}
            className="px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-xl flex items-center gap-1.5 border border-slate-700 transition cursor-pointer"
          >
            <RefreshCw className={`w-4 h-4 text-sky-400 ${isRefreshing ? 'animate-spin' : ''}`} />
            <span>Làm Mới</span>
          </button>
          <button
            onClick={handleExport}
            className="px-3.5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 shadow-lg shadow-emerald-600/20 transition cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Xuất Excel</span>
          </button>
          <button
            onClick={() => window.print()}
            className="px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl flex items-center gap-1.5 border border-slate-700 transition cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>In Báo Cáo</span>
          </button>
        </div>
      </div>

      {/* 4 Real-Time Operational KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl">
          <div className="text-slate-400 text-xs font-bold uppercase tracking-wider flex items-center gap-1.5">
            <Users className="w-4 h-4 text-sky-400" />
            <span>Nhân Sự Đang Trực</span>
          </div>
          <div className="text-2xl font-mono font-black text-white mt-1.5 flex items-center gap-2">
            <span>{activeStaff}</span>
            <span className="text-xs text-emerald-400 font-normal font-sans">/ {totalStaff} đang bận ({availableStaff} sẵn sàng)</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Toàn bộ các tổ đội tại bãi/xưởng</div>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl">
          <div className="text-slate-400 text-xs font-bold uppercase tracking-wider flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>Đã Xử Lý Hôm Nay</span>
          </div>
          <div className="text-2xl font-mono font-black text-emerald-400 mt-1.5">
            {totalTasksCompleted} <span className="text-xs text-slate-400 font-normal">/ {totalTasksAssigned} việc</span>
          </div>
          <div className="text-[11px] text-emerald-500/80 mt-1">
            Đạt {Math.round((totalTasksCompleted / totalTasksAssigned) * 100)}% khối lượng giao trong ca
          </div>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl">
          <div className="text-slate-400 text-xs font-bold uppercase tracking-wider flex items-center gap-1.5">
            <Zap className="w-4 h-4 text-amber-400" />
            <span>Hiệu Suất Định Mức Ca</span>
          </div>
          <div className="text-2xl font-mono font-black text-amber-300 mt-1.5">
            {avgEfficiency}%
          </div>
          <div className="text-[11px] text-amber-400/80 mt-1">⚡ Đạt chuẩn định mức ca vận hành</div>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl">
          <div className="text-slate-400 text-xs font-bold uppercase tracking-wider flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-purple-400" />
            <span>Chất Lượng KCS (FPY)</span>
          </div>
          <div className="text-2xl font-mono font-black text-purple-300 mt-1.5">
            {avgFPY}%
          </div>
          <div className="text-[11px] text-purple-400/80 mt-1">Tỷ lệ đạt KCS nghiệm thu lần đầu</div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="flex flex-col md:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Tìm theo tên nhân viên, mã NV (NV-G01), container đang làm (MSKU...)..."
            className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-500 focus:border-sky-500 focus:outline-none"
          />
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto flex-wrap">
          <select
            value={selectedShift}
            onChange={(e) => setSelectedShift(e.target.value)}
            className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-white focus:border-sky-500 focus:outline-none cursor-pointer"
          >
            <option value="ALL">-- Tất Cả Ca Trực --</option>
            <option value="SHIFT_1">Ca 1 (06:00 - 14:00)</option>
            <option value="SHIFT_2">Ca 2 (14:00 - 22:00)</option>
            <option value="SHIFT_3">Ca 3 (22:00 - 06:00)</option>
          </select>

          <select
            value={selectedDept}
            onChange={(e) => setSelectedDept(e.target.value)}
            className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-white focus:border-sky-500 focus:outline-none cursor-pointer"
          >
            <option value="ALL">-- Tất Cả Phòng Ban / Tổ Đội --</option>
            <option value="GATE">Tổ Cổng Gate-In/Out</option>
            <option value="SURVEY">Tổ Giám Định (Survey)</option>
            <option value="REPAIR_WELDING">Tổ Hàn Gò EMR</option>
            <option value="REPAIR_FLOOR">Tổ Mộc & Ván Sàn</option>
            <option value="CLEANING">Tổ Vệ Sinh Vỏ</option>
            <option value="QC">Tổ KCS Nghiệm Thu</option>
            <option value="FORKLIFT">Tổ Lái Xe Nâng Bãi</option>
            <option value="WAREHOUSE">Kho Vật Tư EMR</option>
          </select>

          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-white focus:border-sky-500 focus:outline-none cursor-pointer"
          >
            <option value="ALL">-- Tất Cả Trạng Thái --</option>
            <option value="BUSY">⚡ Đang Làm Việc</option>
            <option value="AVAILABLE">🟢 Đang Sẵn Sàng</option>
            <option value="ON_BREAK">☕ Tạm Nghỉ</option>
          </select>
        </div>
      </div>

      {/* Main Staff Realtime Cards / Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="text-xs font-bold text-slate-300 flex items-center gap-2">
            <Users className="w-4 h-4 text-sky-400" />
            <span>DANH SÁCH NHÂN SỰ VẬN HÀNH & TIẾN ĐỘ THỜI GIAN THỰC ({filteredStaff.length} người)</span>
          </div>
          <span className="text-[11px] text-slate-400">Click vào dòng bất kỳ để xem lịch sử chi tiết</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950/60 text-[11px] uppercase tracking-wider text-slate-400 border-b border-slate-800">
              <tr>
                <th className="py-3.5 px-4">Nhân Viên</th>
                <th className="py-3.5 px-3">Tổ Đội / Chức Danh</th>
                <th className="py-3.5 px-3">Trạng Thái Live</th>
                <th className="py-3.5 px-4">Container & Công Việc Đang Xử Lý</th>
                <th className="py-3.5 px-3 text-right">Đã Xong / Giao</th>
                <th className="py-3.5 px-3 text-right">Thời Gian TB</th>
                <th className="py-3.5 px-3 text-right">Hiệu Suất</th>
                <th className="py-3.5 px-3 text-center">KCS Đạt</th>
                <th className="py-3.5 px-3 text-right">Chi Tiết</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredStaff.map((staff) => {
                const isBusy = staff.status === 'BUSY';
                const isAvailable = staff.status === 'AVAILABLE';

                return (
                  <tr
                    key={staff.id}
                    onClick={() => handleViewDetail(staff)}
                    className="hover:bg-slate-800/50 transition cursor-pointer group"
                  >
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-sky-400 text-xs shrink-0 group-hover:border-sky-500 transition">
                          {staff.code}
                        </div>
                        <div>
                          <div className="font-black text-white group-hover:text-sky-300 transition">
                            {staff.name}
                          </div>
                          <div className="text-[11px] text-slate-400 font-mono flex items-center gap-1">
                            <Phone className="w-3 h-3 text-amber-400" /> {staff.phone}
                          </div>
                        </div>
                      </div>
                    </td>

                    <td className="py-3.5 px-3">
                      <div className="font-bold text-slate-200">{staff.departmentName}</div>
                      <div className="text-[10px] text-slate-400">{staff.roleTitle}</div>
                    </td>

                    <td className="py-3.5 px-3 whitespace-nowrap">
                      {isBusy ? (
                        <span className="px-2.5 py-1 rounded-full text-[10px] font-black bg-amber-500/20 text-amber-300 border border-amber-500/30 inline-flex items-center gap-1.5 animate-pulse">
                          <span className="w-2 h-2 rounded-full bg-amber-400" /> ĐANG LÀM
                        </span>
                      ) : isAvailable ? (
                        <span className="px-2.5 py-1 rounded-full text-[10px] font-black bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 inline-flex items-center gap-1.5">
                          <span className="w-2 h-2 rounded-full bg-emerald-400" /> SẴN SÀNG
                        </span>
                      ) : (
                        <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-slate-800 text-slate-400 border border-slate-700">
                          TẠM NGHỈ
                        </span>
                      )}
                    </td>

                    <td className="py-3.5 px-4 min-w-[280px]">
                      {staff.currentTask ? (
                        <div className="space-y-1.5">
                          <div className="flex items-center justify-between gap-2">
                            <span className="font-bold text-white truncate max-w-[220px]" title={staff.currentTask.taskName}>
                              {staff.currentTask.taskName}
                            </span>
                            <span className="px-2 py-0.5 bg-amber-500 text-slate-950 font-mono font-black rounded text-[11px] shrink-0">
                              {staff.currentTask.containerNo}
                            </span>
                          </div>
                          <div className="flex items-center justify-between text-[11px] text-slate-400">
                            <span className="flex items-center gap-1">
                              <MapPin className="w-3 h-3 text-rose-400" /> {staff.currentTask.location}
                            </span>
                            <span className="font-mono text-amber-300 font-bold">
                              {staff.currentTask.progressPercent}% ({staff.currentTask.elapsedMinutes}/{staff.currentTask.estimatedDurationMinutes}p)
                            </span>
                          </div>
                          <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                            <div
                              className="bg-amber-400 h-full rounded-full transition-all"
                              style={{ width: `${staff.currentTask.progressPercent}%` }}
                            />
                          </div>
                        </div>
                      ) : (
                        <div className="text-slate-500 italic text-[11px] flex items-center gap-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                          <span>Đã xong việc trước, đang chờ nhận container mới</span>
                        </div>
                      )}
                    </td>

                    <td className="py-3.5 px-3 text-right font-mono font-bold whitespace-nowrap">
                      <span className="text-white text-sm">{staff.metrics.completedToday}</span>
                      <span className="text-slate-500 text-xs"> / {staff.metrics.assignedToday}</span>
                    </td>

                    <td className="py-3.5 px-3 text-right font-mono text-slate-300 whitespace-nowrap">
                      {staff.metrics.avgMinutesPerContainer} phút/cont
                    </td>

                    <td className="py-3.5 px-3 text-right font-mono whitespace-nowrap">
                      <span className="text-amber-300 font-black text-sm">
                        {staff.metrics.efficiencyPercent}%
                      </span>
                    </td>

                    <td className="py-3.5 px-3 text-center whitespace-nowrap">
                      <span className="px-2 py-0.5 rounded-lg text-[11px] font-mono font-bold bg-emerald-950/80 text-emerald-300 border border-emerald-800">
                        {staff.metrics.firstPassYieldPercent}%
                      </span>
                    </td>

                    <td className="py-3.5 px-3 text-right whitespace-nowrap">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleViewDetail(staff);
                        }}
                        className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-sky-400 text-[11px] font-bold rounded-lg border border-slate-700 transition cursor-pointer flex items-center gap-1 ml-auto"
                      >
                        <Eye className="w-3 h-3" />
                        <span>Xem</span>
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Staff Detail Modal */}
      <StaffDetailModal
        staff={selectedStaff}
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setSelectedStaff(null);
        }}
      />
    </div>
  );
};
