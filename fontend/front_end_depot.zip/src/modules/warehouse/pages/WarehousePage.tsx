import React, { useState } from 'react';
import { warehouseService } from '../services/warehouseService';
import {
  Material,
  StockBalance,
  StockTransaction,
  WorkOrderMaterial,
  MaterialReceipt,
  MaterialIssue,
  MaterialReturn,
  StockAdjustment,
  Stocktake,
  MaterialDamage,
  MaterialGroup,
  Supplier,
  WarehouseKPIs
} from '../types';

import { WarehouseHeader } from '../components/WarehouseHeader';
import { StockBalanceTab } from '../components/StockBalanceTab';
import { MaterialReceiptTab } from '../components/MaterialReceiptTab';
import { MaterialIssueTab } from '../components/MaterialIssueTab';
import { StockTransactionsTab } from '../components/StockTransactionsTab';
import { MaterialCatalogTab } from '../components/MaterialCatalogTab';

// Modals
import { CreateMaterialModal } from '../components/modals/CreateMaterialModal';
import { CreateReceiptModal } from '../components/modals/CreateReceiptModal';
import { CreateIssueModal } from '../components/modals/CreateIssueModal';
import { MaterialStockCardModal } from '../components/modals/MaterialStockCardModal';

export const WarehousePage: React.FC = () => {
  // Default to stock balance (Nhập - Xuất - Tồn)
  const [activeSubTab, setActiveSubTab] = useState<string>('stock_balance');

  // State loaded from warehouseService
  const [materials, setMaterials] = useState<Material[]>(warehouseService.getMaterials());
  const [stockBalances, setStockBalances] = useState<StockBalance[]>(warehouseService.getStockBalances());
  const [transactions, setTransactions] = useState<StockTransaction[]>(warehouseService.getStockTransactions());
  const [workOrderMaterials, setWorkOrderMaterials] = useState<WorkOrderMaterial[]>(warehouseService.getWorkOrderMaterials());
  const [receipts, setReceipts] = useState<MaterialReceipt[]>(warehouseService.getReceipts());
  const [issues, setIssues] = useState<MaterialIssue[]>(warehouseService.getIssues());
  const [materialGroups, setMaterialGroups] = useState<MaterialGroup[]>(warehouseService.getMaterialGroups());
  const [suppliers, setSuppliers] = useState<Supplier[]>(warehouseService.getSuppliers());

  // Modal States
  const [isCreateMaterialOpen, setIsCreateMaterialOpen] = useState(false);
  const [editMaterial, setEditMaterial] = useState<Material | null>(null);

  const [isCreateReceiptOpen, setIsCreateReceiptOpen] = useState(false);
  const [isCreateIssueOpen, setIsCreateIssueOpen] = useState(false);

  // Detail Modal States
  const [stockCardMaterialId, setStockCardMaterialId] = useState<number | null>(null);
  const [isStockCardOpen, setIsStockCardOpen] = useState(false);

  // Sync state helper
  const reloadData = () => {
    setMaterials(warehouseService.getMaterials());
    setStockBalances(warehouseService.getStockBalances());
    setTransactions(warehouseService.getStockTransactions());
    setWorkOrderMaterials(warehouseService.getWorkOrderMaterials());
    setReceipts(warehouseService.getReceipts());
    setIssues(warehouseService.getIssues());
    setMaterialGroups(warehouseService.getMaterialGroups());
    setSuppliers(warehouseService.getSuppliers());
  };

  // HANDLERS
  // 1. Save Material
  const handleSaveMaterial = (matData: Partial<Material>) => {
    warehouseService.saveMaterial(matData);
    reloadData();
  };

  // 2. Receipt (Nhập kho -> Tự động cộng tồn kho)
  const handleConfirmReceipt = (
    supplierId: number,
    receiptDate: string,
    note: string,
    items: { materialId: number; quantity: number; unitCost: number; note?: string }[]
  ) => {
    warehouseService.createReceipt(supplierId, receiptDate, note, items);
    reloadData();
  };

  // 3. Issue (Xuất kho -> Tự động trừ tồn kho)
  const handleConfirmIssue = (
    workOrderId: string,
    workOrderNo: string,
    containerId: string,
    containerNo: string,
    shippingLine: string,
    recipientName: string,
    note: string,
    items: { materialId: number; quantity: number; note?: string }[]
  ) => {
    const res = warehouseService.createIssue(
      workOrderId,
      workOrderNo,
      containerId,
      containerNo,
      shippingLine,
      recipientName,
      note,
      items
    );
    if (res.success) {
      reloadData();
    }
    return res;
  };

  // Stock Card Open
  const handleOpenStockCard = (materialId: number) => {
    setStockCardMaterialId(materialId);
    setIsStockCardOpen(true);
  };

  // Edit Material Open
  const handleOpenEditMaterial = (mat: Material) => {
    setEditMaterial(mat);
    setIsCreateMaterialOpen(true);
  };

  const currentStockCardMat = materials.find((m) => m.id === stockCardMaterialId) || materials[0];
  const currentStockCardBalance = stockBalances.find((b) => b.materialId === stockCardMaterialId) || stockBalances[0];

  return (
    <div className="space-y-6 pb-12">
      {/* Header & Sub-tab navigation */}
      <WarehouseHeader
        activeSubTab={activeSubTab}
        onSelectSubTab={setActiveSubTab}
        onOpenCreateReceipt={() => setIsCreateReceiptOpen(true)}
        onOpenCreateIssue={() => setIsCreateIssueOpen(true)}
        onOpenCreateMaterial={() => {
          setEditMaterial(null);
          setIsCreateMaterialOpen(true);
        }}
      />

      {/* Sub Tabs Switching */}
      {activeSubTab === 'stock_balance' && (
        <StockBalanceTab
          stockBalances={stockBalances}
          materialGroups={materialGroups}
          onOpenStockCard={handleOpenStockCard}
          onOpenIssue={() => setIsCreateIssueOpen(true)}
          onOpenReceipt={() => setIsCreateReceiptOpen(true)}
          onOpenCreateMaterial={() => {
            setEditMaterial(null);
            setIsCreateMaterialOpen(true);
          }}
        />
      )}

      {activeSubTab === 'receipts' && (
        <MaterialReceiptTab
          receipts={receipts}
          onOpenCreateReceipt={() => setIsCreateReceiptOpen(true)}
        />
      )}

      {activeSubTab === 'issues' && (
        <MaterialIssueTab
          issues={issues}
          onOpenCreateIssue={() => setIsCreateIssueOpen(true)}
        />
      )}

      {activeSubTab === 'transactions' && (
        <StockTransactionsTab
          transactions={transactions}
          onOpenReceipt={() => setIsCreateReceiptOpen(true)}
          onOpenIssue={() => setIsCreateIssueOpen(true)}
        />
      )}

      {activeSubTab === 'catalog' && (
        <MaterialCatalogTab
          materials={materials}
          materialGroups={materialGroups}
          onOpenCreateMaterial={() => {
            setEditMaterial(null);
            setIsCreateMaterialOpen(true);
          }}
          onEditMaterial={handleOpenEditMaterial}
        />
      )}

      {/* MODALS */}
      <CreateMaterialModal
        isOpen={isCreateMaterialOpen}
        onClose={() => {
          setIsCreateMaterialOpen(false);
          setEditMaterial(null);
        }}
        onSave={handleSaveMaterial}
        editMaterial={editMaterial}
      />

      <CreateReceiptModal
        isOpen={isCreateReceiptOpen}
        onClose={() => setIsCreateReceiptOpen(false)}
        materials={materials}
        suppliers={suppliers}
        onConfirmReceipt={handleConfirmReceipt}
      />

      <CreateIssueModal
        isOpen={isCreateIssueOpen}
        onClose={() => setIsCreateIssueOpen(false)}
        materials={materials}
        stockBalances={stockBalances}
        workOrderMaterials={workOrderMaterials}
        onConfirmIssue={handleConfirmIssue}
      />

      {/* Stock Card Modal */}
      {currentStockCardMat && currentStockCardBalance && (
        <MaterialStockCardModal
          isOpen={isStockCardOpen}
          onClose={() => setIsStockCardOpen(false)}
          material={currentStockCardMat}
          stockBalance={currentStockCardBalance}
          transactions={transactions.filter((t) => t.materialId === currentStockCardMat.id)}
        />
      )}
    </div>
  );
};
