import React, { useState } from 'react';
import { SurveyItemRecord, SurveyStatus } from '../types';
import {
  Clock,
  Search,
  Filter,
  CheckCircle2,
  AlertTriangle,
  Wrench,
  Sparkles,
  ClipboardCheck,
  Eye,
  FileText,
  User,
  Calendar,
  ChevronLeft,
  ChevronRight,
  Download,
  AlertCircle,
  Plus,
  Send,
  Receipt
} from 'lucide-react';

interface SurveyQueueTableProps {
  title: string;
  subtitle: string;
  surveys: SurveyItemRecord[];
  statusFilterTab?: 'WAITING' | 'IN_PROGRESS' | 'COMPLETED' | 'ALL';
  onSelectSurvey: (survey: SurveyItemRecord) => void;
  onOpenEEIR: (survey: SurveyItemRecord) => void;
  onTransferToOperation?: (survey: SurveyItemRecord) => void;
  onSearchNonGateIn: () => void;
  onCreateNewSurvey?: () => void;
}

export const SurveyQueueTable: React.FC<SurveyQueueTableProps> = ({
  title,
  subtitle,
  surveys,
  statusFilterTab = 'ALL',
  onSelectSurvey,
  onOpenEEIR,
  onTransferToOperation,
  onSearchNonGateIn,
  onCreateNewSurvey
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [shippingLineFilter, setShippingLineFilter] = useState('ALL');
  const [conditionFilter, setConditionFilter] = useState('ALL');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 8;

  // Filter logic
  const filtered = surveys.filter((s) => {
    // Status tab filter
    if (statusFilterTab === 'WAITING' && s.status !== 'NEW' && s.status !== 'ASSIGNED') return false;
    if (statusFilterTab === 'IN_PROGRESS' && s.status !== 'IN_PROGRESS') return false;
    if (statusFilterTab === 'COMPLETED' && s.status !== 'COMPLETED' && s.status !== 'CONFIRMED' && s.status !== 'EEIR_ISSUED') return false;

    // Search query
    const matchSearch =
      s.containerNo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.surveyNo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.surveyor.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.owner.toLowerCase().includes(searchTerm.toLowerCase());

    // Carrier filter
    const matchLine = shippingLineFilter === 'ALL' || s.shippingLine === shippingLineFilter;

    // Condition filter
    const matchCondition = conditionFilter === 'ALL' || s.condition === conditionFilter;

    return matchSearch && matchLine && matchCondition;
  });

  const totalPages = Math.ceil(filtered.length / itemsPerPage) || 1;
  const paginated = filtered.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="p-6 bg-slate-900 border border-slate-800 rounded-3xl flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-amber-500/20 border border-amber-500/30 text-amber-400 rounded-2xl">
            <ClipboardCheck className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white tracking-wide">{title}</h2>
            <p className="text-xs text-slate-400">{subtitle}</p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {onCreateNewSurvey && (
            <button
              onClick={onCreateNewSurvey}
              className="px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow-lg shadow-amber-500/20 transition flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>+ Thêm Mới Giám Định</span>
            </button>
          )}

          <button
            onClick={onSearchNonGateIn}
            className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs rounded-xl border border-slate-700 transition flex items-center gap-2 cursor-pointer"
          >
            <Search className="w-4 h-4 text-amber-400" />
            <span>Tra Cứu / Pre-Survey</span>
          </button>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="flex flex-1 flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-[240px] max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Tìm kiếm số Container (MSCU...), Số Survey, Surveyor..."
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full pl-9 pr-3 py-2 bg-slate-900 border border-slate-800 text-xs text-white rounded-xl focus:outline-none focus:border-amber-500"
            />
          </div>

          <select
            value={shippingLineFilter}
            onChange={(e) => {
              setShippingLineFilter(e.target.value);
              setCurrentPage(1);
            }}
            className="px-3 py-2 bg-slate-900 border border-slate-800 text-xs text-slate-300 rounded-xl focus:outline-none"
          >
            <option value="ALL">Tất cả hãng tàu</option>
            <option value="MAERSK">MAERSK Line</option>
            <option value="MSC">MSC Shipping</option>
            <option value="ONE">ONE</option>
            <option value="CMA-CGM">CMA CGM</option>
            <option value="COSCO">COSCO</option>
            <option value="EVERGREEN">EVERGREEN</option>
          </select>

          <select
            value={conditionFilter}
            onChange={(e) => {
              setConditionFilter(e.target.value);
              setCurrentPage(1);
            }}
            className="px-3 py-2 bg-slate-900 border border-slate-800 text-xs text-slate-300 rounded-xl focus:outline-none"
          >
            <option value="ALL">Tất cả tình trạng (AV / CL / DM)</option>
            <option value="AV">AV - Đạt chuẩn (Available)</option>
            <option value="CL">CL - Cần vệ sinh (Cleaning)</option>
            <option value="DM">DM - Hư hỏng (Damaged)</option>
          </select>
        </div>

        <div className="text-xs text-slate-400 font-mono">
          Hiển thị: <strong className="text-white">{filtered.length}</strong> / {surveys.length} container
        </div>
      </div>

      {/* DataGrid Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-950/90 text-slate-400 font-semibold border-b border-slate-800">
                <th className="py-3.5 px-4 w-12 text-center">STT</th>
                <th className="py-3.5 px-4">Số Container</th>
                <th className="py-3.5 px-4">Hãng Tàu / Chủ Vỏ</th>
                <th className="py-3.5 px-4">Kích Cỡ / Loại</th>
                <th className="py-3.5 px-4">Giờ Gate-In</th>
                <th className="py-3.5 px-4 text-center">Tình Trạng</th>
                <th className="py-3.5 px-4">Giám Định Viên</th>
                <th className="py-3.5 px-4 text-center">Trạng Thái Survey</th>
                <th className="py-3.5 px-4 text-right">Thao Tác</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 bg-slate-900/50">
              {paginated.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-500">
                    <AlertCircle className="w-8 h-8 mx-auto mb-2 text-slate-600" />
                    Không tìm thấy container nào phù hợp bộ lọc
                  </td>
                </tr>
              ) : (
                paginated.map((survey, index) => {
                  const itemIndex = (currentPage - 1) * itemsPerPage + index + 1;
                  return (
                    <tr key={survey.id} className="hover:bg-slate-800/40 transition">
                      <td className="py-3.5 px-4 text-center font-mono font-bold text-slate-500">
                        {itemIndex}
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="space-y-0.5">
                          <span className="font-mono font-bold text-amber-400 text-sm block">
                            {survey.containerNo}
                          </span>
                          <span className="text-[10px] font-mono text-slate-400 block">
                            Mã: {survey.surveyNo}
                          </span>
                          {survey.isPreSurveyBeforeGateIn && (
                            <span className="inline-block px-1.5 py-0.2 bg-amber-950 text-amber-300 border border-amber-800 text-[9px] rounded font-bold">
                              Chưa Gate-In (Pre-Survey)
                            </span>
                          )}
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        <span className="font-bold text-white block">{survey.shippingLine}</span>
                        <span className="text-[10px] text-slate-400 max-w-[140px] truncate block">
                          {survey.owner}
                        </span>
                      </td>

                      <td className="py-3.5 px-4">
                        <span className="font-bold text-slate-200 block">{survey.size} {survey.type}</span>
                        <span className="text-[10px] font-mono text-slate-400">ISO: {survey.isoCode}</span>
                      </td>

                      <td className="py-3.5 px-4 font-mono text-slate-300">
                        {survey.gateInTime}
                      </td>

                      <td className="py-3.5 px-4 text-center">
                        <span
                          className={`inline-flex items-center gap-1 text-[10px] font-black px-2 py-0.5 rounded border ${
                            survey.condition === 'AV'
                              ? 'bg-emerald-950 text-emerald-300 border-emerald-800'
                              : survey.condition === 'CL'
                              ? 'bg-amber-950 text-amber-300 border-amber-800'
                              : 'bg-rose-950 text-rose-300 border-rose-800'
                          }`}
                        >
                          {survey.condition === 'AV' && <Sparkles className="w-3 h-3 text-emerald-400" />}
                          {survey.condition === 'CL' && <AlertTriangle className="w-3 h-3 text-amber-400" />}
                          {survey.condition === 'DM' && <Wrench className="w-3 h-3 text-rose-400" />}
                          {survey.condition}
                          {survey.damages && survey.damages.length > 0 && ` (${survey.damages.length})`}
                        </span>
                      </td>

                      <td className="py-3.5 px-4">
                        <span className="text-slate-200 font-medium block">{survey.surveyor}</span>
                        <span className="text-[10px] text-slate-400 font-mono">Chuẩn: {survey.standard}</span>
                      </td>

                      <td className="py-3.5 px-4 text-center">
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                            survey.status === 'EEIR_ISSUED'
                              ? 'bg-emerald-950 text-emerald-300 border-emerald-800'
                              : survey.status === 'COMPLETED'
                              ? 'bg-blue-950 text-blue-300 border-blue-800'
                              : survey.status === 'IN_PROGRESS'
                              ? 'bg-indigo-950 text-indigo-300 border-indigo-800'
                              : 'bg-amber-950 text-amber-300 border-amber-800'
                          }`}
                        >
                          {survey.status}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          {/* Main Giám Định Action */}
                          <button
                            onClick={() => onSelectSurvey(survey)}
                            className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg shadow transition flex items-center gap-1 cursor-pointer"
                            title="Mở màn hình giám định chi tiết"
                          >
                            <ClipboardCheck className="w-3.5 h-3.5" />
                            <span>Giám Định</span>
                          </button>

                          {/* e-EIR View if available or completed */}
                          {(survey.status === 'COMPLETED' || survey.status === 'EEIR_ISSUED' || survey.status === 'CONFIRMED') && (
                            <button
                              onClick={() => onOpenEEIR(survey)}
                              className="p-1.5 bg-slate-800 hover:bg-slate-700 text-emerald-400 rounded-lg transition cursor-pointer"
                              title="Xem biên bản e-EIR điện tử"
                            >
                              <FileText className="w-3.5 h-3.5" />
                            </button>
                          )}

                          {/* Direct Transfer to Operation */}
                          {(survey.status === 'COMPLETED' || survey.status === 'EEIR_ISSUED') && onTransferToOperation && (
                            <button
                              onClick={() => onTransferToOperation(survey)}
                              className="px-2.5 py-1.5 bg-sky-600/20 hover:bg-sky-600/30 text-sky-300 hover:text-white border border-sky-500/40 rounded-lg transition flex items-center gap-1 text-[11px] font-bold cursor-pointer"
                              title="Phát hành e-EIR & chuyển sang phân hệ Khai Thác Gate-In để lập Phiếu Dịch Vụ"
                            >
                              <Send className="w-3 h-3 text-sky-400" />
                              <span className="hidden sm:inline">Chuyển Khai Thác</span>
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Footer */}
        <div className="p-4 bg-slate-950/80 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span>
            Trang <strong className="text-white">{currentPage}</strong> / {totalPages}
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="p-1.5 bg-slate-900 border border-slate-800 rounded-lg disabled:opacity-40 hover:bg-slate-800 transition cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="p-1.5 bg-slate-900 border border-slate-800 rounded-lg disabled:opacity-40 hover:bg-slate-800 transition cursor-pointer"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
