import React from 'react';
import { ContainerRecord } from '../../../services/mockDataStore';
import {
  LogIn,
  ClipboardCheck,
  CheckCircle2,
  AlertTriangle,
  Wrench,
  FileCode,
  Camera,
  FileCheck2,
  Calculator,
  CreditCard,
  Truck,
  Grid3X3,
  ArrowDown,
  ArrowRight
} from 'lucide-react';

interface GateInSurveyWorkflowDiagramProps {
  containers: ContainerRecord[];
  onNavigateTab: (tabId: string) => void;
}

export const GateInSurveyWorkflowDiagram: React.FC<GateInSurveyWorkflowDiagramProps> = ({
  containers,
  onNavigateTab
}) => {
  // Counts at each step of the pipeline
  const gateInCount = containers.filter((c) => c.status === 'GATE_IN').length;
  const surveyCount = containers.filter((c) => c.status === 'SURVEYING').length;
  
  const avCount = containers.filter((c) => c.condition === 'AV').length;
  const clCount = containers.filter((c) => c.condition === 'CL').length;
  const dmCount = containers.filter((c) => c.condition === 'DM').length;

  const paymentCount = containers.filter((c) => c.status === 'WAITING_PAYMENT').length;
  const forkliftCount = containers.filter((c) => c.status === 'WAITING_FORKLIFT').length;
  const inYardCount = containers.filter((c) => c.status === 'IN_YARD' || c.status === 'READY_FOR_USE').length;

  return (
    <div className="p-6 bg-slate-900 border border-slate-800 rounded-3xl space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 bg-blue-500/10 border border-blue-500/20 text-blue-400 text-[11px] font-bold rounded-full font-mono mb-1">
            CORE OPERATIONAL FLOWCHART
          </div>
          <h3 className="text-lg font-bold text-white flex items-center gap-2">
            <span>Sơ Đồ Quy Trình Tiếp Nhận &amp; Giám Định Container (Gate-In + Survey)</span>
          </h3>
          <p className="text-xs text-slate-400">
            Trực quan hóa luồng dữ liệu 10 bước chuẩn ISO/IICL từ khi xe qua Cổng đến khi Hạ Bãi thành công.
          </p>
        </div>

        <button
          onClick={() => onNavigateTab('gate')}
          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-lg transition flex items-center gap-2 cursor-pointer shrink-0"
        >
          <LogIn className="w-4 h-4" />
          <span>Tạo Tiếp Nhận Gate-In Mới</span>
        </button>
      </div>

      {/* Visual Flowchart Nodes */}
      <div className="space-y-4">
        {/* Node 1: GATE-IN + SURVEY */}
        <div className="flex flex-col items-center">
          <div className="w-full max-w-xl p-4 bg-slate-950 border-2 border-blue-500/50 rounded-2xl flex items-center justify-between shadow-xl shadow-blue-950/20">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-blue-600/20 text-blue-400 rounded-xl border border-blue-500/30">
                <LogIn className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[10px] font-mono font-bold text-blue-400 uppercase tracking-widest">BƯỚC 1</span>
                <h4 className="text-sm font-bold text-white">GATE-IN + SURVEY (Tiếp nhận Container)</h4>
                <p className="text-[11px] text-slate-400">Đọc OCR biển số xe, số Cont, loại ISO &amp; kiểm tra phiếu lệnh</p>
              </div>
            </div>
            <div className="text-right">
              <span className="text-xs font-mono font-bold text-blue-400 bg-blue-950/80 px-2.5 py-1 rounded-lg border border-blue-800">
                {gateInCount} Cont ở Cổng
              </span>
            </div>
          </div>

          <div className="my-1.5 flex flex-col items-center text-blue-400">
            <ArrowDown className="w-5 h-5 animate-pulse" />
          </div>

          {/* Node 2: Kiểm Tra / Giám Định */}
          <div className="w-full max-w-xl p-4 bg-slate-950 border-2 border-amber-500/50 rounded-2xl flex items-center justify-between shadow-xl shadow-amber-950/20">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-amber-600/20 text-amber-400 rounded-xl border border-amber-500/30">
                <ClipboardCheck className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[10px] font-mono font-bold text-amber-400 uppercase tracking-widest">BƯỚC 2</span>
                <h4 className="text-sm font-bold text-white">Kiểm Tra / Giám Định Vỏ IICL</h4>
                <p className="text-[11px] text-slate-400">Giám định viên kiểm tra 6 mặt vỏ, sàn, đà, khóa cửa &amp; nóc</p>
              </div>
            </div>
            <div className="text-right">
              <span className="text-xs font-mono font-bold text-amber-400 bg-amber-950/80 px-2.5 py-1 rounded-lg border border-amber-800">
                {surveyCount} Đang Giám Định
              </span>
            </div>
          </div>
        </div>

        {/* Node 3: Split into 3 Conditions (AV, CL, DM) */}
        <div className="my-2 flex justify-center">
          <div className="w-full max-w-3xl grid grid-cols-1 md:grid-cols-3 gap-3">
            {/* AV */}
            <div
              onClick={() => onNavigateTab('container')}
              className="p-3.5 bg-emerald-950/30 border border-emerald-500/40 rounded-2xl cursor-pointer hover:bg-emerald-950/50 transition space-y-1"
            >
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1.5 text-xs font-bold text-emerald-400">
                  <CheckCircle2 className="w-4 h-4" /> AV (Available)
                </span>
                <span className="text-xs font-mono font-bold text-emerald-300">{avCount} Cont</span>
              </div>
              <p className="text-[10px] text-slate-400">Đạt chuẩn, sạch đẹp, cấp trả chủ hàng ngay</p>
            </div>

            {/* CL */}
            <div
              onClick={() => onNavigateTab('container')}
              className="p-3.5 bg-amber-950/30 border border-amber-500/40 rounded-2xl cursor-pointer hover:bg-amber-950/50 transition space-y-1"
            >
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1.5 text-xs font-bold text-amber-400">
                  <AlertTriangle className="w-4 h-4" /> CL (Cleaning)
                </span>
                <span className="text-xs font-mono font-bold text-amber-300">{clCount} Cont</span>
              </div>
              <p className="text-[10px] text-slate-400">Bẩn/Dính hóa chất, cần xịt rửa rửa nước áp lực</p>
            </div>

            {/* DM */}
            <div
              onClick={() => onNavigateTab('container')}
              className="p-3.5 bg-rose-950/30 border border-rose-500/40 rounded-2xl cursor-pointer hover:bg-rose-950/50 transition space-y-1"
            >
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1.5 text-xs font-bold text-rose-400">
                  <Wrench className="w-4 h-4" /> DM (Damaged)
                </span>
                <span className="text-xs font-mono font-bold text-rose-300">{dmCount} Cont</span>
              </div>
              <p className="text-[10px] text-slate-400">Hư hỏng cấu trúc, chuyển báo giá EMR &amp; sửa chữa</p>
            </div>
          </div>
        </div>

        <div className="my-1.5 flex flex-col items-center text-slate-500">
          <ArrowDown className="w-5 h-5" />
        </div>

        {/* Node 4 & 5 & 6: Ghi nhận Repair Code -> Chụp Ảnh -> e-EIR */}
        <div className="flex justify-center">
          <div className="w-full max-w-3xl grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="p-3 bg-slate-950 border border-slate-800 rounded-2xl space-y-1">
              <div className="flex items-center gap-2 text-purple-400 text-xs font-bold">
                <FileCode className="w-4 h-4" />
                <span>Ghi Nhận Repair Code</span>
              </div>
              <p className="text-[10px] text-slate-400">Nhập mã CEDEX (CUT, DENT, HOLE, BRK) &amp; vị trí chi tiết</p>
            </div>

            <div className="p-3 bg-slate-950 border border-slate-800 rounded-2xl space-y-1">
              <div className="flex items-center gap-2 text-sky-400 text-xs font-bold">
                <Camera className="w-4 h-4" />
                <span>Chụp Ảnh Giám Định</span>
              </div>
              <p className="text-[10px] text-slate-400">Đính kèm ảnh hiện trạng tổn thất 4 góc &amp; bên trong vỏ</p>
            </div>

            <div className="p-3 bg-slate-950 border border-slate-800 rounded-2xl space-y-1">
              <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold">
                <FileCheck2 className="w-4 h-4" />
                <span>Phát Hành e-EIR</span>
              </div>
              <p className="text-[10px] text-slate-400">Tạo phiếu giao nhận điện tử kèm Mã QR tra cứu</p>
            </div>
          </div>
        </div>

        <div className="my-1.5 flex flex-col items-center text-slate-500">
          <ArrowDown className="w-5 h-5" />
        </div>

        {/* Node 7 & 8: Tính Phí -> Payment */}
        <div className="flex justify-center">
          <div className="w-full max-w-2xl grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="p-3.5 bg-slate-950 border border-slate-800 rounded-2xl space-y-1">
              <div className="flex items-center gap-2 text-cyan-400 text-xs font-bold">
                <Calculator className="w-4 h-4" />
                <span>Tính Phí Tự Động (Tariff)</span>
              </div>
              <p className="text-[10px] text-slate-400">Áp biểu cước Nâng Hạ (Lift On/Off), Vệ Sinh &amp; Lưu Bãi</p>
            </div>

            <div
              onClick={() => onNavigateTab('payment')}
              className="p-3.5 bg-emerald-950/20 border border-emerald-500/30 rounded-2xl cursor-pointer hover:bg-emerald-950/40 transition space-y-1"
            >
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-2 text-emerald-400 text-xs font-bold">
                  <CreditCard className="w-4 h-4" /> Payment (Thanh Toán VietQR)
                </span>
                <span className="text-xs font-mono font-bold text-emerald-300">{paymentCount} Chờ</span>
              </div>
              <p className="text-[10px] text-slate-400">Quét mã VietQR động &amp; tự động gạch nợ qua Webhook</p>
            </div>
          </div>
        </div>

        <div className="my-1.5 flex flex-col items-center text-slate-500">
          <ArrowDown className="w-5 h-5" />
        </div>

        {/* Node 9 & 10: Forklift Dispatch -> Yard */}
        <div className="flex justify-center">
          <div className="w-full max-w-2xl grid grid-cols-1 md:grid-cols-2 gap-3">
            <div
              onClick={() => onNavigateTab('forklift')}
              className="p-3.5 bg-sky-950/20 border border-sky-500/30 rounded-2xl cursor-pointer hover:bg-sky-950/40 transition space-y-1"
            >
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-2 text-sky-400 text-xs font-bold">
                  <Truck className="w-4 h-4" /> Forklift Dispatch (Lệnh Gắp)
                </span>
                <span className="text-xs font-mono font-bold text-sky-300">{forkliftCount} Lệnh</span>
              </div>
              <p className="text-[10px] text-slate-400">Phát lệnh không dây tới màn hình cabin tài xế xe nâng</p>
            </div>

            <div
              onClick={() => onNavigateTab('yard_map')}
              className="p-3.5 bg-indigo-950/20 border border-indigo-500/30 rounded-2xl cursor-pointer hover:bg-indigo-950/40 transition space-y-1"
            >
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-2 text-indigo-400 text-xs font-bold">
                  <Grid3X3 className="w-4 h-4" /> Yard (Xếp Dỡ Bãi 2D)
                </span>
                <span className="text-xs font-mono font-bold text-indigo-300">{inYardCount} Đã Hạ</span>
              </div>
              <p className="text-[10px] text-slate-400">Cập nhật tọa độ vị trí Block - Bay - Row - Tier thời gian thực</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
