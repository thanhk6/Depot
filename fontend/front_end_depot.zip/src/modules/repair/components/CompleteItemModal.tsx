import React, { useState } from 'react';
import { X, CheckCircle2, Package, Clock, FileText, Plus, Trash2, AlertCircle, Camera } from 'lucide-react';
import { WorkOrderRepairItem, MaterialUsage } from '../types/repair';
import { COMMON_DEPOT_MATERIALS } from '../data/initialWorkOrders';

interface CompleteItemModalProps {
  item: WorkOrderRepairItem;
  containerNo: string;
  workOrderNo: string;
  leadTechnician: string;
  onOpenCapturePhotos: () => void;
  onConfirmComplete: (data: {
    executionNotes: string;
    actualHours: number;
    materialsUsed: MaterialUsage[];
    technician: string;
  }) => void;
  onClose: () => void;
}

export const CompleteItemModal: React.FC<CompleteItemModalProps> = ({
  item,
  containerNo,
  workOrderNo,
  leadTechnician,
  onOpenCapturePhotos,
  onConfirmComplete,
  onClose
}) => {
  const afterPhotos = item.photos.filter((p) => p.type === 'AFTER');
  const hasAfterPhoto = afterPhotos.length > 0;

  const [technician, setTechnician] = useState(item.technician || leadTechnician || 'Hoàng Văn Sơn (Tổ EMR)');
  const [actualHours, setActualHours] = useState<number>(item.actualHours || 1.5);
  const [executionNotes, setExecutionNotes] = useState(
    item.executionNotes ||
      'Đã hoàn thành thi công chuẩn tiêu chuẩn sửa chữa IICL-6. Mối hàn mài phẳng, làm sạch xỉ, sơn 1 lớp lót chống rỉ và 1 lớp phủ bóng ngoại thất.'
  );

  const [materials, setMaterials] = useState<MaterialUsage[]>(
    item.materialsUsed.length > 0
      ? item.materialsUsed
      : [
          {
            id: 'MAT-1',
            materialCode: 'MAT-ST-01',
            materialName: 'Thép tấm tôn vách rãnh IICL 2.0mm',
            quantity: 1,
            unit: 'Tấm',
            notes: 'Xuất kho chính EMR'
          }
        ]
  );

  // New Material row state
  const [selectedMaterialCode, setSelectedMaterialCode] = useState(COMMON_DEPOT_MATERIALS[0].code);
  const [materialQty, setMaterialQty] = useState(1);

  const handleAddMaterial = () => {
    const foundMat = COMMON_DEPOT_MATERIALS.find((m) => m.code === selectedMaterialCode);
    if (!foundMat) return;

    const newMat: MaterialUsage = {
      id: `MAT-${Date.now()}`,
      materialCode: foundMat.code,
      materialName: foundMat.name,
      quantity: Number(materialQty) || 1,
      unit: foundMat.unit,
      notes: 'Thợ EMR đăng ký sử dụng'
    };

    setMaterials([...materials, newMat]);
  };

  const handleRemoveMaterial = (id: string) => {
    setMaterials(materials.filter((m) => m.id !== id));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!hasAfterPhoto) {
      alert('Bắt buộc phải chụp hoặc đính kèm ít nhất 01 ảnh sau khi sửa (AFTER photo) mới được phép hoàn thành hạng mục!');
      return;
    }

    onConfirmComplete({
      executionNotes,
      actualHours: Number(actualHours) || 1.5,
      materialsUsed: materials,
      technician
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto animate-fade-in">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-5 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded-xl">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white">Ghi Nhận Kết Quả & Hoàn Thành Hạng Mục</h3>
                <span className="px-2 py-0.5 bg-slate-800 text-slate-300 text-xs font-mono rounded">
                  #{item.itemNo}
                </span>
              </div>
              <p className="text-xs text-slate-400 font-mono mt-0.5">
                Cont: <strong className="text-white">{containerNo}</strong> &bull; WO: <strong className="text-amber-400">{workOrderNo}</strong>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-6 flex-1 bg-slate-900/60">
          {/* Photo validation notice */}
          {!hasAfterPhoto ? (
            <div className="p-4 bg-rose-950/60 border border-rose-600/80 rounded-2xl flex items-start justify-between gap-3">
              <div className="flex items-start gap-2.5">
                <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <h4 className="text-xs font-bold text-rose-200">Chưa Có Ảnh Sau Sửa (Bắt Buộc)</h4>
                  <p className="text-[11px] text-rose-300/90 leading-relaxed">
                    Theo quy định IICL và Hãng Tàu, thợ phải chụp ảnh đối chứng sau sửa trước khi hoàn thành hạng mục này.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenCapturePhotos();
                }}
                className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold rounded-xl transition flex items-center gap-1.5 shrink-0 cursor-pointer shadow"
              >
                <Camera className="w-3.5 h-3.5" />
                <span>Chụp Ảnh Ngay</span>
              </button>
            </div>
          ) : (
            <div className="p-3.5 bg-emerald-950/40 border border-emerald-800 rounded-2xl flex items-center justify-between gap-2 text-xs">
              <div className="flex items-center gap-2 text-emerald-400 font-bold">
                <CheckCircle2 className="w-4 h-4" />
                <span>Đã có {afterPhotos.length} ảnh sau sửa đính kèm đầy đủ</span>
              </div>
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenCapturePhotos();
                }}
                className="text-[11px] text-emerald-300 hover:underline cursor-pointer"
              >
                Xem / Thêm ảnh &rarr;
              </button>
            </div>
          )}

          {/* Item details */}
          <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-2">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Hạng Mục Sửa Chữa</span>
            <div className="text-xs font-bold text-white font-mono flex items-center gap-2">
              <span className="text-amber-400">[{item.repairCode}]</span>
              <span>{item.repairNameVi}</span>
            </div>
            <p className="text-[11px] text-slate-400">
              Vị trí: <strong className="text-slate-300">{item.locationVi} ({item.locationCode})</strong> &bull; Hư hỏng: <strong className="text-amber-300">[{item.damageCode}] {item.damageNameVi}</strong>
            </p>
          </div>

          {/* Execution details */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-blue-400" />
                <span>Thời Gian Thi Công Thực Tế (Giờ)</span>
              </label>
              <input
                type="number"
                step="0.5"
                min="0.5"
                max="24"
                value={actualHours}
                onChange={(e) => setActualHours(parseFloat(e.target.value) || 0)}
                className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 text-sm font-bold font-mono text-white rounded-xl focus:outline-none"
                required
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-blue-400" />
                <span>Thợ Trưởng Kíp Thực Hiện</span>
              </label>
              <input
                type="text"
                value={technician}
                onChange={(e) => setTechnician(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 text-sm font-bold text-white rounded-xl focus:outline-none"
                required
              />
            </div>
          </div>

          {/* Technical execution notes */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300">
              Kết Quả Thực Hiện & Ghi Chú Kỹ Thuật (Execution Notes)*
            </label>
            <textarea
              rows={3}
              value={executionNotes}
              onChange={(e) => setExecutionNotes(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 text-xs text-white rounded-xl focus:outline-none leading-relaxed"
              placeholder="Nhập quy trình thi công, phương pháp hàn vá, số lớp sơn..."
              required
            />
          </div>

          {/* Materials Usage List */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <Package className="w-4 h-4 text-amber-400" />
                <span>Vật Tư EMR Đã Xuất Dùng Cho Hạng Mục ({materials.length})</span>
              </label>
            </div>

            {/* Existing materials table */}
            <div className="p-3 bg-slate-950 border border-slate-800 rounded-2xl space-y-2">
              {materials.length === 0 ? (
                <p className="text-[11px] text-slate-500 italic text-center py-2">
                  Chưa ghi nhận vật tư tiêu hao nào cho hạng mục này
                </p>
              ) : (
                materials.map((mat) => (
                  <div
                    key={mat.id}
                    className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl flex items-center justify-between gap-3 text-xs"
                  >
                    <div>
                      <div className="font-bold text-white flex items-center gap-2">
                        <span className="font-mono text-amber-400">{mat.materialCode}</span>
                        <span>{mat.materialName}</span>
                      </div>
                      <span className="text-[10px] text-slate-400">{mat.notes}</span>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      <span className="font-mono font-bold text-emerald-400 px-2 py-0.5 bg-slate-950 rounded border border-slate-800">
                        {mat.quantity} {mat.unit}
                      </span>
                      <button
                        type="button"
                        onClick={() => handleRemoveMaterial(mat.id)}
                        className="p-1 text-slate-500 hover:text-rose-400 transition cursor-pointer"
                        title="Xóa vật tư"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))
              )}

              {/* Add material sub-form */}
              <div className="pt-2 border-t border-slate-800/80 grid grid-cols-1 sm:grid-cols-12 gap-2 text-xs">
                <div className="sm:col-span-8">
                  <select
                    value={selectedMaterialCode}
                    onChange={(e) => setSelectedMaterialCode(e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-slate-900 border border-slate-700 text-white rounded-lg text-xs"
                  >
                    {COMMON_DEPOT_MATERIALS.map((m) => (
                      <option key={m.code} value={m.code}>
                        [{m.code}] {m.name} ({m.unit})
                      </option>
                    ))}
                  </select>
                </div>
                <div className="sm:col-span-2">
                  <input
                    type="number"
                    min="1"
                    step="1"
                    value={materialQty}
                    onChange={(e) => setMaterialQty(parseFloat(e.target.value) || 1)}
                    className="w-full px-2 py-1.5 bg-slate-900 border border-slate-700 text-white rounded-lg text-center text-xs font-mono font-bold"
                  />
                </div>
                <div className="sm:col-span-2">
                  <button
                    type="button"
                    onClick={handleAddMaterial}
                    className="w-full py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-bold text-xs flex items-center justify-center gap-1 transition cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Thêm</span>
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Footer Submit Button */}
          <div className="pt-2 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold rounded-xl transition cursor-pointer"
            >
              Hủy
            </button>
            <button
              type="submit"
              disabled={!hasAfterPhoto}
              className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 disabled:cursor-not-allowed text-white text-xs font-bold rounded-xl shadow-lg shadow-emerald-950 transition flex items-center gap-2 cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>XÁC NHẬN HOÀN THÀNH HẠNG MỤC</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
