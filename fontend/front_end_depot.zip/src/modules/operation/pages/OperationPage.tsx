import React, { useState } from 'react';
import { ContainerRecord } from '../../../services/mockDataStore';
import { ServiceOrder } from '../types';
import { INITIAL_SERVICE_ORDERS, autoCalculateServiceTicket } from '../mockData';
import { ServiceOrderListTable } from '../components/ServiceOrderListTable';
import { GateInQueueTable } from '../components/GateInQueueTable';
import { ServiceOrderFormModal } from '../components/ServiceOrderFormModal';
import { ServiceOrderDetailModal } from '../components/ServiceOrderDetailModal';
import { LiftOnLiftOffAndStorageMaster } from '../../masterdata/components/LiftOnLiftOffAndStorageMaster';
import { formatVND } from '../../../utils/format';
import {
  Receipt,
  Plus,
  QrCode,
  DollarSign,
  CheckCircle2,
  AlertCircle,
  Truck,
  ArrowRight,
  Clock,
  Sparkles,
  Layers,
  FileCheck
} from 'lucide-react';

interface OperationPageProps {
  containers?: ContainerRecord[];
  onAddServiceOrder?: (order: ServiceOrder) => void;
  onConfirmPayment?: (containerId: string) => void;
  onNavigateTab?: (tabId: string) => void;
}

export const OperationPage: React.FC<OperationPageProps> = ({
  containers = [],
  onAddServiceOrder,
  onConfirmPayment,
  onNavigateTab
}) => {
  const [orders, setOrders] = useState<ServiceOrder[]>(INITIAL_SERVICE_ORDERS);
  const [activeSubTab, setActiveSubTab] = useState<'orders' | 'queue' | 'tariff'>('orders');

  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [selectedPrefillContainer, setSelectedPrefillContainer] = useState<any>(null);

  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<ServiceOrder | null>(null);

  // Stats calculation
  const totalOrders = orders.length;
  const totalAmountCalculated = orders.reduce((sum, o) => sum + o.grandTotal, 0);
  const cleaningOrdersCount = orders.filter((o) => o.items.some((i) => i.serviceCode.includes('CLN'))).length;

  // Containers waiting for service order (surveyed containers)
  const queueContainers = containers.filter(
    (c) => c.status === 'SURVEYING' || c.status === 'GATE_IN' || c.status === 'WAITING_PAYMENT'
  );

  const handleOpenCreateForContainer = (container: ContainerRecord) => {
    setSelectedPrefillContainer(container);
    setIsCreateModalOpen(true);
  };

  const handleCreateNewBlank = () => {
    setSelectedPrefillContainer(null);
    setIsCreateModalOpen(true);
  };

  const handleSaveOrder = (newOrder: ServiceOrder) => {
    setOrders([newOrder, ...orders]);
    if (onAddServiceOrder) {
      onAddServiceOrder(newOrder);
    }
  };

  const handleMarkPaid = (orderId: string) => {
    const now = new Date().toISOString().replace('T', ' ').substring(0, 16);
    setOrders((prev) =>
      prev.map((o) => {
        if (o.id === orderId) {
          const updated: ServiceOrder = {
            ...o,
            paymentStatus: 'PAID',
            status: 'PAID',
            paidAt: now,
            paymentMethod: 'VIETQR',
            transactionId: 'FT' + Math.floor(10000000 + Math.random() * 90000000)
          };
          if (selectedOrder?.id === orderId) {
            setSelectedOrder(updated);
          }
          if (onConfirmPayment && (o.containerId || o.containerNo)) {
            onConfirmPayment(o.containerId || o.containerNo);
          }
          return updated;
        }
        return o;
      })
    );
  };

  const handleViewExistingTicket = (orderNo: string) => {
    const found = orders.find((o) => o.orderNo === orderNo);
    if (found) {
      setSelectedOrder(found);
      setIsDetailModalOpen(true);
    }
  };

  const handleViewDetail = (order: ServiceOrder) => {
    setSelectedOrder(order);
    setIsDetailModalOpen(true);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="p-6 bg-slate-900 border border-slate-800 rounded-3xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="p-3 bg-gradient-to-br from-cyan-600 to-blue-600 text-white rounded-2xl shadow-lg shadow-cyan-600/30">
            <Receipt className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 bg-cyan-950 text-cyan-400 border border-cyan-800 text-[11px] font-bold rounded-md">
                3. QUY TRÌNH NGHIỆP VỤ
              </span>
              <h2 className="text-xl font-black text-white tracking-tight">
                3. KHAI THÁC GATE-IN (GATE-IN OPERATION)
              </h2>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Tiếp nhận dữ liệu từ Giám Định & Vệ Sinh &bull; Lập Phiếu Dịch Vụ theo Biểu Phí Tariff (Nâng hạ, Lưu bãi, Vệ sinh...) &bull; Tạo Mã QR &bull; Chuyển Thanh Toán
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => onNavigateTab && onNavigateTab('payment')}
            className="px-4 py-2.5 bg-purple-600/20 hover:bg-purple-600/30 text-purple-300 font-bold text-xs rounded-xl border border-purple-500/40 transition flex items-center gap-2 cursor-pointer"
          >
            <QrCode className="w-4 h-4 text-purple-400" />
            <span>Màn Hình Thanh Toán VietQR</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={handleCreateNewBlank}
            className="px-4 py-2.5 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-cyan-600/30 transition flex items-center gap-2 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>+ Lập Phiếu Dịch Vụ Mới</span>
          </button>
        </div>
      </div>

      {/* KPI Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400 font-semibold">
            <span>Tổng Phiếu Dịch Vụ</span>
            <Receipt className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-black text-white font-mono">{totalOrders}</div>
          <div className="text-[11px] text-slate-400">Đã phát hành tại cổng Gate-In</div>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400 font-semibold">
            <span>Hàng Đợi Tiếp Nhận Giám Định</span>
            <FileCheck className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-black text-amber-400 font-mono">
            {queueContainers.length}
          </div>
          <div className="text-[11px] text-amber-400/80">Container có kết quả e-EIR</div>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400 font-semibold">
            <span>Phiếu Phát Sinh Vệ Sinh CL</span>
            <Sparkles className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl font-black text-purple-400 font-mono">
            {cleaningOrdersCount} <span className="text-xs text-slate-400 font-normal">phiếu</span>
          </div>
          <div className="text-[11px] text-purple-400/80">Áp dụng xịt rửa áp lực cao</div>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400 font-semibold">
            <span>Tổng Tiền Dịch Vụ Theo Biểu Phí</span>
            <DollarSign className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-black text-emerald-400 font-mono">
            {formatVND(totalAmountCalculated)}
          </div>
          <div className="text-[11px] text-slate-400">Tự động tính theo Tariff hãng tàu</div>
        </div>
      </div>

      {/* Sub Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
        <button
          onClick={() => setActiveSubTab('orders')}
          className={`px-4 py-2 text-xs font-bold rounded-xl transition flex items-center gap-2 cursor-pointer ${
            activeSubTab === 'orders'
              ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-600/30'
              : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
          }`}
        >
          <Receipt className="w-4 h-4" />
          <span>Danh Sách Phiếu Dịch Vụ ({orders.length})</span>
        </button>

        <button
          onClick={() => setActiveSubTab('queue')}
          className={`px-4 py-2 text-xs font-bold rounded-xl transition flex items-center gap-2 cursor-pointer ${
            activeSubTab === 'queue'
              ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30'
              : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
          }`}
        >
          <FileCheck className="w-4 h-4" />
          <span>Hàng Đợi Tiếp Nhận Từ Giám Định ({queueContainers.length})</span>
          {queueContainers.length > 0 && (
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping"></span>
          )}
        </button>

        <button
          onClick={() => setActiveSubTab('tariff')}
          className={`px-4 py-2 text-xs font-bold rounded-xl transition flex items-center gap-2 cursor-pointer ${
            activeSubTab === 'tariff'
              ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/30'
              : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
          }`}
        >
          <DollarSign className="w-4 h-4" />
          <span>Biểu Phí Tariff Niêm Yết & Máy Tính Cước</span>
        </button>
      </div>

      {/* Sub Tab Contents */}
      {activeSubTab === 'orders' && (
        <ServiceOrderListTable
          orders={orders}
          onViewDetail={handleViewDetail}
          onMarkPaid={handleMarkPaid}
          onNavigateToPayment={(cId) => onNavigateTab && onNavigateTab('payment')}
        />
      )}

      {activeSubTab === 'queue' && (
        <GateInQueueTable
          containers={queueContainers}
          existingOrders={orders.map((o) => ({
            containerNo: o.containerNo,
            orderNo: o.orderNo,
            paymentStatus: o.paymentStatus
          }))}
          onOpenCreateTicket={handleOpenCreateForContainer}
          onViewExistingTicket={handleViewExistingTicket}
        />
      )}

      {activeSubTab === 'tariff' && <LiftOnLiftOffAndStorageMaster />}

      {/* Modals */}
      <ServiceOrderFormModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        onSave={handleSaveOrder}
        onSaveAndNavigateToPayment={(order) => {
          handleSaveOrder(order);
          if (onNavigateTab) {
            onNavigateTab('payment');
          }
        }}
        prefillContainer={selectedPrefillContainer}
      />

      <ServiceOrderDetailModal
        isOpen={isDetailModalOpen}
        onClose={() => setIsDetailModalOpen(false)}
        order={selectedOrder}
        onMarkPaid={handleMarkPaid}
        onNavigateToPayment={(cId) => onNavigateTab && onNavigateTab('payment')}
      />
    </div>
  );
};
