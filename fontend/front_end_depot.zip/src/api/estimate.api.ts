import apiClient from './axios';
import { API_ENDPOINTS } from './endpoints';
import { ApiResponse } from '../types/common';
import { EstimateSheet } from '../types/container';

export const estimateApi = {
  createEstimate: async (jobId: string, estimateVm: any) => {
    const res = await apiClient.post<ApiResponse<EstimateSheet>>(API_ENDPOINTS.DEPOT_JOBS.ESTIMATE(jobId), estimateVm);
    return res.data;
  },
  approveEstimate: async (jobId: string, approverName = "Hãng Tàu Phê Duyệt") => {
    const res = await apiClient.post<ApiResponse<EstimateSheet>>(API_ENDPOINTS.DEPOT_JOBS.APPROVE_ESTIMATE(jobId, approverName));
    return res.data;
  },
};

