import React, { useState, useMemo } from 'react';
import {
  ShippingLineDebt,
  DebtPeriod,
  Payment,
  PaymentAllocation,
  ShippingLineDebtSummary,
  DebtAgingBucket
} from '../types';
import {
  INITIAL_SHIPPING_LINE_DEBTS,
  INITIAL_DEBT_PERIODS,
  INITIAL_PAYMENTS,
  INITIAL_AGING_DATA,
  SHIPPING_LINES_LIST
} from '../mockData';
import { DebtDashboardKPI } from '../components/DebtDashboardKPI';
import { ShippingLineSummaryTab } from '../components/ShippingLineSummaryTab';
import { ContainerDebtLedgerTab } from '../components/ContainerDebtLedgerTab';
import { PeriodManagementTab } from '../components/PeriodManagementTab';
import { PaymentAllocationHistoryTab } from '../components/PaymentAllocationHistoryTab';
import { DebtAgingReportTab } from '../components/DebtAgingReportTab';
import { PaymentAllocationModal } from '../components/PaymentAllocationModal';
import { ContainerDebtDetailModal } from '../components/ContainerDebtDetailModal';
import { IssueInvoiceModal } from '../components/IssueInvoiceModal';
import { SyncDebtModal } from '../components/SyncDebtModal';
import { ClosePeriodModal } from '../components/ClosePeriodModal';
import { ReversePaymentModal } from '../components/ReversePaymentModal';

import {
  Building2,
  Container,
  CalendarCheck,
  CreditCard,
  BarChart3,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

export const BillingPage: React.FC = () => {
  // Navigation Tabs
  const [activeTab, setActiveTab] = useState<
    'SUMMARY' | 'CONTAINER_LEDGER' | 'PERIODS' | 'PAYMENTS' | 'AGING'
  >('CONTAINER_LEDGER');

  // Master States
  const [debts, setDebts] = useState<ShippingLineDebt[]>(INITIAL_SHIPPING_LINE_DEBTS);
  const [periods, setPeriods] = useState<DebtPeriod[]>(INITIAL_DEBT_PERIODS);
  const [payments, setPayments] = useState<Payment[]>(INITIAL_PAYMENTS);
  const [agingData, setAgingData] = useState<DebtAgingBucket[]>(INITIAL_AGING_DATA);

  // Filters for Container Ledger
  const [selectedCarrier, setSelectedCarrier] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');
  const [searchContainerNo, setSearchContainerNo] = useState<string>('');
  const [searchQuotationNo, setSearchQuotationNo] = useState<string>('');
  const [searchInvoiceNo, setSearchInvoiceNo] = useState<string>('');
  const [fromDate, setFromDate] = useState<string>('2026-08-01');
  const [toDate, setToDate] = useState<string>('2026-08-31');

  // Modals
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState<boolean>(false);
  const [paymentModalDefaultCarrier, setPaymentModalDefaultCarrier] = useState<string>('MAERSK');
  const [paymentModalDefaultDebtId, setPaymentModalDefaultDebtId] = useState<string | undefined>(undefined);

  const [detailModalDebt, setDetailModalDebt] = useState<ShippingLineDebt | null>(null);
  const [issueInvoiceDebt, setIssueInvoiceDebt] = useState<ShippingLineDebt | null>(null);
  const [isSyncModalOpen, setIsSyncModalOpen] = useState<boolean>(false);
  const [closingPeriod, setClosingPeriod] = useState<DebtPeriod | null>(null);
  const [reversingPayment, setReversingPayment] = useState<Payment | null>(null);

  // Toast Notification
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // KPI Calculations
  const totalReceivables = useMemo(() => {
    return debts
      .filter((d) => d.status !== 'CANCELLED')
      .reduce((sum, d) => sum + d.remainingAmount, 0);
  }, [debts]);

  const overdueAmount = useMemo(() => {
    const today = '2026-08-18';
    return debts
      .filter((d) => d.status !== 'CANCELLED' && d.remainingAmount > 0 && d.dueDate < today)
      .reduce((sum, d) => sum + d.remainingAmount, 0);
  }, [debts]);

  const currentPeriodDebit = useMemo(() => {
    return periods
      .filter((p) => p.status === 'OPEN')
      .reduce((sum, p) => sum + p.periodDebit, 0);
  }, [periods]);

  const currentPeriodCredit = useMemo(() => {
    return periods
      .filter((p) => p.status === 'OPEN')
      .reduce((sum, p) => sum + p.periodCredit, 0);
  }, [periods]);

  const currentClosingBalance = useMemo(() => {
    return periods
      .filter((p) => p.status === 'OPEN')
      .reduce((sum, p) => sum + p.closingBalance, 0);
  }, [periods]);

  // Summaries by Shipping Line
  const shippingLineSummaries: ShippingLineDebtSummary[] = useMemo(() => {
    return SHIPPING_LINES_LIST.map((carrier) => {
      const carrierDebts = debts.filter((d) => d.shippingLineId === carrier.id && d.status !== 'CANCELLED');
      const openPeriod = periods.find((p) => p.shippingLineId === carrier.id && p.status === 'OPEN');
      const latestPeriod = periods
        .filter((p) => p.shippingLineId === carrier.id)
        .sort((a, b) => (a.toDate > b.toDate ? -1 : 1))[0];

      const unpaidCount = carrierDebts.filter((d) => d.status === 'UNPAID').length;
      const partialCount = carrierDebts.filter((d) => d.status === 'PARTIAL').length;
      const paidCount = carrierDebts.filter((d) => d.status === 'PAID').length;

      const overdue = carrierDebts
        .filter((d) => d.remainingAmount > 0 && d.dueDate < '2026-08-18')
        .reduce((sum, d) => sum + d.remainingAmount, 0);

      const openingBalance = openPeriod ? openPeriod.openingBalance : latestPeriod?.openingBalance || 0;
      const periodDebit = openPeriod ? openPeriod.periodDebit : latestPeriod?.periodDebit || 0;
      const periodCredit = openPeriod ? openPeriod.periodCredit : latestPeriod?.periodCredit || 0;
      const closingBalance = openPeriod ? openPeriod.closingBalance : latestPeriod?.closingBalance || 0;

      return {
        shippingLineId: carrier.id,
        shippingLineName: carrier.name,
        logoText: carrier.logo,
        containerCount: carrierDebts.length,
        unpaidCount,
        partialCount,
        paidCount,
        openingBalance,
        periodDebit,
        periodCredit,
        closingBalance,
        overdueAmount: overdue,
        currency: 'VND'
      };
    });
  }, [debts, periods]);

  // Filtered Debts for Container Ledger
  const filteredDebts = useMemo(() => {
    return debts.filter((d) => {
      if (selectedCarrier !== 'ALL' && d.shippingLineId !== selectedCarrier) return false;
      if (selectedStatus !== 'ALL' && d.status !== selectedStatus) return false;
      if (searchContainerNo.trim() !== '') {
        if (!d.containerNo.toLowerCase().includes(searchContainerNo.toLowerCase().trim())) {
          return false;
        }
      }
      if (searchQuotationNo.trim() !== '') {
        if (!d.quotationNo.toLowerCase().includes(searchQuotationNo.toLowerCase().trim())) {
          return false;
        }
      }
      if (searchInvoiceNo.trim() !== '') {
        if (!d.invoiceNo || !d.invoiceNo.toLowerCase().includes(searchInvoiceNo.toLowerCase().trim())) {
          return false;
        }
      }
      return true;
    });
  }, [debts, selectedCarrier, selectedStatus, searchContainerNo, searchQuotationNo, searchInvoiceNo]);

  // Handler 1: Submit Payment & Allocation
  const handleSubmitPayment = (
    carrierId: string,
    paymentAmount: number,
    paymentMethod: 'BANK_TRANSFER' | 'SWIFT' | 'CASH' | 'VIETQR' | 'CREDIT_CARD',
    bankName: string,
    referenceNo: string,
    paymentDate: string,
    notes: string,
    allocationList: { debtId: string; containerNo: string; quotationNo: string; amount: number }[]
  ) => {
    const paymentId = `PAY-${new Date().getFullYear()}-${String(payments.length + 1).padStart(3, '0')}`;
    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);

    const newAllocations: PaymentAllocation[] = allocationList.map((alc, idx) => ({
      id: `ALC-${Date.now()}-${idx}`,
      paymentId,
      shippingLineDebtId: alc.debtId,
      containerNo: alc.containerNo,
      quotationNo: alc.quotationNo,
      allocatedAmount: alc.amount,
      currency: 'VND',
      createdAt: now
    }));

    const newPayment: Payment = {
      id: paymentId,
      shippingLineId: carrierId,
      shippingLineName: SHIPPING_LINES_LIST.find((c) => c.id === carrierId)?.name || carrierId,
      paymentDate,
      paymentAmount,
      currency: 'VND',
      paymentMethod,
      bankName,
      referenceNo,
      status: 'CONFIRMED',
      notes,
      recordedBy: 'Nguyễn Thị Thu (Kế toán AR)',
      createdAt: now,
      allocations: newAllocations
    };

    // Update debts
    const updatedDebts = debts.map((d) => {
      const matchAlloc = allocationList.find((alc) => alc.debtId === d.id);
      if (matchAlloc) {
        const newPaid = d.paidAmount + matchAlloc.amount;
        const newRemaining = Math.max(0, d.totalAmount - newPaid);
        const newStatus: ShippingLineDebt['status'] =
          newRemaining === 0 ? 'PAID' : newRemaining < d.totalAmount ? 'PARTIAL' : 'UNPAID';
        return {
          ...d,
          paidAmount: newPaid,
          remainingAmount: newRemaining,
          status: newStatus,
          updatedAt: now
        };
      }
      return d;
    });

    // Update periods
    const updatedPeriods = periods.map((p) => {
      if (p.shippingLineId === carrierId && p.status === 'OPEN') {
        const newCredit = p.periodCredit + paymentAmount;
        const newClosing = p.openingBalance + p.periodDebit - newCredit;
        return {
          ...p,
          periodCredit: newCredit,
          closingBalance: newClosing,
          updatedAt: now
        };
      }
      return p;
    });

    setPayments([newPayment, ...payments]);
    setDebts(updatedDebts);
    setPeriods(updatedPeriods);

    showToast(
      `Đã ghi nhận thanh toán ${paymentAmount.toLocaleString('vi-VN')} đ và phân bổ thành công cho ${allocationList.length} container!`
    );
  };

  // Handler 2: Sync Debts from Completed Repairs
  const handleSyncDebts = (newDebts: ShippingLineDebt[]) => {
    const updatedDebts = [...newDebts, ...debts];
    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);

    // Update period debits for each carrier affected
    let updatedPeriods = [...periods];
    newDebts.forEach((nd) => {
      updatedPeriods = updatedPeriods.map((p) => {
        if (p.shippingLineId === nd.shippingLineId && p.status === 'OPEN') {
          const newDebit = p.periodDebit + nd.totalAmount;
          const newClosing = p.openingBalance + newDebit - p.periodCredit;
          return {
            ...p,
            periodDebit: newDebit,
            closingBalance: newClosing,
            updatedAt: now
          };
        }
        return p;
      });
    });

    setDebts(updatedDebts);
    setPeriods(updatedPeriods);
    showToast(`Đã đồng bộ thành công ${newDebts.length} khoản công nợ container mới vào sổ kế toán!`);
  };

  // Handler 3: Issue Invoice
  const handleSubmitIssueInvoice = (debtId: string, invoiceNo: string) => {
    const updatedDebts = debts.map((d) => {
      if (d.id === debtId) {
        return {
          ...d,
          invoiceNo,
          updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 19)
        };
      }
      return d;
    });
    setDebts(updatedDebts);
    showToast(`Đã xuất và gắn Hóa đơn VAT ${invoiceNo} thành công (Công nợ giữ nguyên theo quy định).`);
  };

  // Handler 4: Close Period
  const handleConfirmClosePeriod = (periodId: string, closingNotes: string) => {
    const targetPeriod = periods.find((p) => p.id === periodId);
    if (!targetPeriod) return;

    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);

    // Close the current period
    const closedPeriod: DebtPeriod = {
      ...targetPeriod,
      status: 'CLOSED',
      closedAt: now,
      closedBy: 'Nguyễn Thị Thu (Kế toán trưởng)',
      updatedAt: now
    };

    // Automatically create next period with OpeningBalance = previous ClosingBalance
    const nextPeriod: DebtPeriod = {
      id: `PERIOD-${targetPeriod.shippingLineId}-${Date.now()}`,
      shippingLineId: targetPeriod.shippingLineId,
      shippingLineName: targetPeriod.shippingLineName,
      periodCode: '2026-09-01_2026-09-15',
      fromDate: '2026-09-01',
      toDate: '2026-09-15',
      openingBalance: targetPeriod.closingBalance, // TỰ ĐỘNG CHUYỂN SỐ DƯ
      periodDebit: 0,
      periodCredit: 0,
      closingBalance: targetPeriod.closingBalance,
      status: 'OPEN',
      createdAt: now,
      updatedAt: now,
      currency: 'VND'
    };

    const updatedPeriods = periods.map((p) => (p.id === periodId ? closedPeriod : p));
    setPeriods([nextPeriod, ...updatedPeriods]);

    showToast(
      `Đã khóa sổ kỳ ${targetPeriod.periodCode}! Số dư cuối kỳ ${targetPeriod.closingBalance.toLocaleString('vi-VN')} đ đã chuyển sang kỳ mới.`
    );
  };

  // Handler 5: Reverse Payment
  const handleConfirmReversePayment = (paymentId: string, reason: string) => {
    const targetPayment = payments.find((p) => p.id === paymentId);
    if (!targetPayment || targetPayment.status === 'REVERSED') return;

    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);

    // Update payment record
    const updatedPayments = payments.map((p) => {
      if (p.id === paymentId) {
        return {
          ...p,
          status: 'REVERSED' as const,
          reversedBy: 'Nguyễn Thị Thu (Kế toán trưởng)',
          reversedAt: now,
          reversalReason: reason
        };
      }
      return p;
    });

    // Revert debts allocated in this payment
    const updatedDebts = debts.map((d) => {
      const matchAlloc = targetPayment.allocations?.find((alc) => alc.shippingLineDebtId === d.id);
      if (matchAlloc) {
        const revertedPaid = Math.max(0, d.paidAmount - matchAlloc.allocatedAmount);
        const revertedRemaining = d.totalAmount - revertedPaid;
        const newStatus: ShippingLineDebt['status'] =
          revertedRemaining === d.totalAmount ? 'UNPAID' : revertedRemaining > 0 ? 'PARTIAL' : 'PAID';
        return {
          ...d,
          paidAmount: revertedPaid,
          remainingAmount: revertedRemaining,
          status: newStatus,
          updatedAt: now
        };
      }
      return d;
    });

    // Update period credit
    const updatedPeriods = periods.map((p) => {
      if (p.shippingLineId === targetPayment.shippingLineId && p.status === 'OPEN') {
        const newCredit = Math.max(0, p.periodCredit - targetPayment.paymentAmount);
        const newClosing = p.openingBalance + p.periodDebit - newCredit;
        return {
          ...p,
          periodCredit: newCredit,
          closingBalance: newClosing,
          updatedAt: now
        };
      }
      return p;
    });

    setPayments(updatedPayments);
    setDebts(updatedDebts);
    setPeriods(updatedPeriods);

    showToast(`Đã hủy phiếu ${paymentId} và hoàn trả công nợ cho các container tương ứng!`);
  };

  const handleResetFilters = () => {
    setSelectedCarrier('ALL');
    setSelectedStatus('ALL');
    setSearchContainerNo('');
    setSearchQuotationNo('');
    setSearchInvoiceNo('');
    setFromDate('2026-08-01');
    setToDate('2026-08-31');
    showToast('Đã đặt lại toàn bộ bộ lọc về mặc định.');
  };

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-sky-600 text-white px-4 py-3 rounded-2xl shadow-2xl flex items-center gap-3 border border-sky-400/30 animate-bounce">
          <CheckCircle2 className="w-5 h-5 text-sky-200" />
          <div className="text-xs font-bold">{toastMessage}</div>
        </div>
      )}

      {/* 1. TOP DASHBOARD KPI METRICS */}
      <DebtDashboardKPI
        totalReceivables={totalReceivables}
        overdueAmount={overdueAmount}
        periodDebit={currentPeriodDebit}
        periodCredit={currentPeriodCredit}
        closingBalance={currentClosingBalance}
        currency="VND"
        onOpenPaymentModal={() => {
          setPaymentModalDefaultCarrier('MAERSK');
          setPaymentModalDefaultDebtId(undefined);
          setIsPaymentModalOpen(true);
        }}
        onOpenSyncModal={() => setIsSyncModalOpen(true)}
        onOpenClosePeriodModal={() => {
          const firstOpen = periods.find((p) => p.status === 'OPEN');
          if (firstOpen) setClosingPeriod(firstOpen);
          else showToast('Tất cả các kỳ công nợ đều đã được chốt.');
        }}
        onExportExcel={() => showToast('Đang tạo và tải về file Excel báo cáo công nợ hãng tàu...')}
        onExportPDF={() => showToast('Đang xuất báo cáo công nợ định dạng PDF...')}
      />

      {/* 2. SUB-NAVIGATION TABS */}
      <div className="bg-slate-900/95 border border-slate-800 rounded-2xl p-1.5 shadow-md">
        <div className="flex items-center gap-1.5 overflow-x-auto touch-pan-x overscroll-x-contain pb-1 sm:pb-0 scrollbar-none select-none">
          <button
            onClick={() => setActiveTab('CONTAINER_LEDGER')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap shrink-0 ${
              activeTab === 'CONTAINER_LEDGER'
                ? 'bg-sky-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Container className="w-3.5 h-3.5" />
            <span>Chi tiết Công Nợ Container</span>
            <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-sky-950 text-sky-300 border border-sky-800">
              {debts.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('SUMMARY')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap shrink-0 ${
              activeTab === 'SUMMARY'
                ? 'bg-sky-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Building2 className="w-3.5 h-3.5" />
            <span>Tổng Hợp Theo Hãng Tàu</span>
            <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-slate-800 text-slate-300">
              {SHIPPING_LINES_LIST.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('PERIODS')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap shrink-0 ${
              activeTab === 'PERIODS'
                ? 'bg-sky-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <CalendarCheck className="w-3.5 h-3.5" />
            <span>Kỳ Công Nợ & Khóa Sổ</span>
          </button>

          <button
            onClick={() => setActiveTab('PAYMENTS')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap shrink-0 ${
              activeTab === 'PAYMENTS'
                ? 'bg-sky-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <CreditCard className="w-3.5 h-3.5" />
            <span>Thanh Toán & Phân Bổ</span>
            <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800">
              {payments.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('AGING')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap shrink-0 ${
              activeTab === 'AGING'
                ? 'bg-sky-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            <span>Báo Cáo Tuổi Nợ (Aging)</span>
          </button>
        </div>
      </div>

      {/* 3. TAB CONTENT */}
      {/* Tab 1: Chi tiết công nợ Container (Container Debt Ledger) */}
      {activeTab === 'CONTAINER_LEDGER' && (
        <ContainerDebtLedgerTab
          debts={filteredDebts}
          selectedCarrier={selectedCarrier}
          onChangeCarrier={setSelectedCarrier}
          selectedStatus={selectedStatus}
          onChangeStatus={setSelectedStatus}
          searchContainerNo={searchContainerNo}
          onChangeSearchContainerNo={setSearchContainerNo}
          searchQuotationNo={searchQuotationNo}
          onChangeSearchQuotationNo={setSearchQuotationNo}
          searchInvoiceNo={searchInvoiceNo}
          onChangeSearchInvoiceNo={setSearchInvoiceNo}
          fromDate={fromDate}
          onChangeFromDate={setFromDate}
          toDate={toDate}
          onChangeToDate={setToDate}
          onResetFilters={handleResetFilters}
          onViewDebtDetail={(d) => setDetailModalDebt(d)}
          onPayForDebt={(d) => {
            setPaymentModalDefaultCarrier(d.shippingLineId);
            setPaymentModalDefaultDebtId(d.id);
            setIsPaymentModalOpen(true);
          }}
          onIssueInvoice={(d) => setIssueInvoiceDebt(d)}
          currency="VND"
        />
      )}

      {/* Tab 2: Tổng hợp theo hãng tàu */}
      {activeTab === 'SUMMARY' && (
        <ShippingLineSummaryTab
          summaries={shippingLineSummaries}
          onSelectCarrier={(carrierId) => {
            setSelectedCarrier(carrierId);
            setActiveTab('CONTAINER_LEDGER');
          }}
          onPayForCarrier={(carrierId) => {
            setPaymentModalDefaultCarrier(carrierId);
            setPaymentModalDefaultDebtId(undefined);
            setIsPaymentModalOpen(true);
          }}
          onClosePeriodForCarrier={(carrierId) => {
            const openP = periods.find((p) => p.shippingLineId === carrierId && p.status === 'OPEN');
            if (openP) setClosingPeriod(openP);
            else showToast(`Hãng tàu ${carrierId} không có kỳ công nợ mở nào.`);
          }}
          currency="VND"
        />
      )}

      {/* Tab 3: Quản lý kỳ công nợ */}
      {activeTab === 'PERIODS' && (
        <PeriodManagementTab
          periods={periods}
          onClosePeriod={(p) => setClosingPeriod(p)}
          currency="VND"
        />
      )}

      {/* Tab 4: Lịch sử thanh toán & phân bổ */}
      {activeTab === 'PAYMENTS' && (
        <PaymentAllocationHistoryTab
          payments={payments}
          onReversePayment={(p) => setReversingPayment(p)}
          currency="VND"
        />
      )}

      {/* Tab 5: Báo cáo tuổi nợ */}
      {activeTab === 'AGING' && (
        <DebtAgingReportTab
          agingData={agingData}
          currency="VND"
          onExportExcel={() => showToast('Đang tải file Excel Báo cáo Tuổi nợ AR...')}
        />
      )}

      {/* 4. MODALS */}
      {/* Modal 1: Thanh toán & Phân bổ */}
      <PaymentAllocationModal
        isOpen={isPaymentModalOpen}
        onClose={() => setIsPaymentModalOpen(false)}
        debts={debts}
        defaultCarrierId={paymentModalDefaultCarrier}
        defaultDebtId={paymentModalDefaultDebtId}
        onSubmitPayment={handleSubmitPayment}
        currency="VND"
      />

      {/* Modal 2: Chi tiết khoản nợ container */}
      <ContainerDebtDetailModal
        debt={detailModalDebt}
        onClose={() => setDetailModalDebt(null)}
        payments={payments}
        onOpenPayForDebt={(d) => {
          setPaymentModalDefaultCarrier(d.shippingLineId);
          setPaymentModalDefaultDebtId(d.id);
          setIsPaymentModalOpen(true);
        }}
        onOpenIssueInvoice={(d) => setIssueInvoiceDebt(d)}
        currency="VND"
      />

      {/* Modal 3: Xuất / Gắn Hóa đơn */}
      <IssueInvoiceModal
        isOpen={!!issueInvoiceDebt}
        onClose={() => setIssueInvoiceDebt(null)}
        debt={issueInvoiceDebt}
        onSubmitIssueInvoice={handleSubmitIssueInvoice}
        currency="VND"
      />

      {/* Modal 4: Đồng bộ từ Báo giá & Sửa chữa hoàn thành */}
      <SyncDebtModal
        isOpen={isSyncModalOpen}
        onClose={() => setIsSyncModalOpen(false)}
        existingDebts={debts}
        onSyncDebts={handleSyncDebts}
        currency="VND"
      />

      {/* Modal 5: Chốt kỳ công nợ */}
      <ClosePeriodModal
        isOpen={!!closingPeriod}
        onClose={() => setClosingPeriod(null)}
        period={closingPeriod}
        onConfirmClosePeriod={handleConfirmClosePeriod}
        currency="VND"
      />

      {/* Modal 6: Hủy thanh toán / Hoàn tác */}
      <ReversePaymentModal
        isOpen={!!reversingPayment}
        onClose={() => setReversingPayment(null)}
        payment={reversingPayment}
        onConfirmReverse={handleConfirmReversePayment}
        currency="VND"
      />
    </div>
  );
};
