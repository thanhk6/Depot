import React, { useState } from 'react';
import {
  SurveyItemRecord,
  DamageLocationMasterItem,
  DamageCodeMasterItem,
  RepairCodeMasterItem,
  GradeMasterItem,
  InspectionStandardMasterItem,
  CleaningTariffMasterItem
} from '../types';
import {
  INITIAL_SURVEY_RECORDS,
  INITIAL_DAMAGE_LOCATIONS,
  INITIAL_DAMAGE_CODES,
  INITIAL_REPAIR_CODES,
  INITIAL_GRADE_MASTERS,
  INITIAL_INSPECTION_STANDARDS,
  INITIAL_CHECKLIST_TEMPLATE,
  INITIAL_CLEANING_TARIFFS
} from '../mockData';
import { SurveyQueueTable } from '../components/SurveyQueueTable';
import { SurveyDetailForm } from '../components/SurveyDetailForm';
import { DamageLocationMaster } from '../components/DamageLocationMaster';
import { DamageCodeMaster } from '../components/DamageCodeMaster';
import { RepairCodeMaster } from '../components/RepairCodeMaster';
import { GradeMaster } from '../components/GradeMaster';
import { InspectionStandardMaster } from '../components/InspectionStandardMaster';
import { SurveyPhotoGallery } from '../components/SurveyPhotoGallery';
import { SurveyHistoryTable } from '../components/SurveyHistoryTable';
import { ContainerSearchModal } from '../components/ContainerSearchModal';
import { EEIRModal } from '../components/EEIRModal';
import { CreateSurveyModal } from '../components/CreateSurveyModal';
import { CleaningMaster } from '../../masterdata/components/CleaningMaster';

import {
  ClipboardCheck,
  Clock,
  CheckCircle2,
  History,
  FileCode,
  MapPin,
  Hammer,
  Sparkles,
  ShieldCheck,
  Image as ImageIcon,
  FileText,
  Search,
  PlusCircle,
  Layers,
  ChevronRight,
  Plus,
  Droplets
} from 'lucide-react';

interface SurveyModulePageProps {
  initialSubTab?: string;
  onNavigateTab?: (tabId: string) => void;
  onSyncContainer?: (
    containerId: string,
    condition: 'AV' | 'CL' | 'DM',
    damages: any[],
    containerData?: any
  ) => void;
}

export const SurveyModulePage: React.FC<SurveyModulePageProps> = ({
  initialSubTab = 'queue',
  onNavigateTab,
  onSyncContainer
}) => {
  // Global survey module state
  const [surveys, setSurveys] = useState<SurveyItemRecord[]>(INITIAL_SURVEY_RECORDS);
  const [locations, setLocations] = useState<DamageLocationMasterItem[]>(INITIAL_DAMAGE_LOCATIONS);
  const [damageCodes, setDamageCodes] = useState<DamageCodeMasterItem[]>(INITIAL_DAMAGE_CODES);
  const [repairCodes, setRepairCodes] = useState<RepairCodeMasterItem[]>(INITIAL_REPAIR_CODES);
  const [grades, setGrades] = useState<GradeMasterItem[]>(INITIAL_GRADE_MASTERS);
  const [standards, setStandards] = useState<InspectionStandardMasterItem[]>(INITIAL_INSPECTION_STANDARDS);
  const [cleaningTariffs, setCleaningTariffs] = useState<CleaningTariffMasterItem[]>(INITIAL_CLEANING_TARIFFS);

  // Active view
  const [activeTab, setActiveTab] = useState<string>(initialSubTab === 'dashboard' ? 'queue' : initialSubTab);
  const [selectedSurvey, setSelectedSurvey] = useState<SurveyItemRecord | null>(null);

  React.useEffect(() => {
    if (initialSubTab) {
      setActiveTab(initialSubTab === 'dashboard' ? 'queue' : initialSubTab);
    }
  }, [initialSubTab]);

  // Modals
  const [isSearchModalOpen, setIsSearchModalOpen] = useState(false);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [createPrefillContNo, setCreatePrefillContNo] = useState('');
  const [eeirSurvey, setEeirSurvey] = useState<SurveyItemRecord | null>(null);

  // Current logged in surveyor
  const currentUser = 'Lê Hoàng Nam (SV-04)';

  // Menu items specification from requirements
  const menuItems = [
    { id: 'queue', label: 'Chờ Giám định', icon: Clock, badge: surveys.filter((s) => s.status === 'NEW' || s.status === 'ASSIGNED').length },
    { id: 'in_progress', label: 'Đang Giám định', icon: ClipboardCheck, badge: surveys.filter((s) => s.status === 'IN_PROGRESS').length },
    { id: 'completed', label: 'Hoàn tất Giám định', icon: CheckCircle2, badge: surveys.filter((s) => s.status === 'COMPLETED' || s.status === 'EEIR_ISSUED').length },
    { id: 'history', label: 'Lịch sử Giám định', icon: History, badge: null },
    { id: 'cleaning_tariffs', label: 'Biểu Phí Vệ Sinh (Cleaning)', icon: Droplets, badge: cleaningTariffs.length },
    { id: 'damage_locations', label: 'Danh mục Damage Location', icon: MapPin, badge: locations.length },
    { id: 'damage_codes', label: 'Danh mục Damage Code', icon: FileCode, badge: damageCodes.length },
    { id: 'repair_codes', label: 'Danh mục Repair Code', icon: Hammer, badge: repairCodes.length },
    { id: 'grades', label: 'Danh mục Grade', icon: Sparkles, badge: grades.length },
    { id: 'standards', label: 'Danh mục Tiêu chuẩn', icon: ShieldCheck, badge: standards.length },
    { id: 'photos', label: 'Quản lý Hình ảnh', icon: ImageIcon, badge: null },
    { id: 'eeir_list', label: 'Chứng từ e-EIR', icon: FileText, badge: null }
  ];

  // Save / Update Survey handler
  const handleSaveSurvey = (updated: SurveyItemRecord) => {
    setSurveys((prev) => {
      const exists = prev.some((s) => s.id === updated.id);
      if (exists) {
        return prev.map((s) => (s.id === updated.id ? updated : s));
      }
      return [updated, ...prev];
    });
    setSelectedSurvey(updated);

    if (onSyncContainer) {
      onSyncContainer(
        updated.containerNo,
        updated.condition as 'AV' | 'CL' | 'DM',
        updated.damages || [],
        {
          size: updated.size,
          type: updated.type,
          shippingLine: updated.shippingLine,
          surveyNo: updated.surveyNo,
          eeirNo: updated.eeirNo,
          grade: updated.qualityGrade
        }
      );
    }
  };

  // Full create new survey handler
  const handleCreateNewSurvey = (newRecord: SurveyItemRecord, openImmediately: boolean = true) => {
    setSurveys((prev) => [newRecord, ...prev]);
    if (openImmediately) {
      setSelectedSurvey(newRecord);
    }
  };

  // Start new survey for non-gate-in or searched container
  const handleStartSurvey = (containerNo: string, isPreSurvey: boolean, shippingLine: string, size: string) => {
    const existing = surveys.find((s) => s.containerNo === containerNo);
    if (existing) {
      setSelectedSurvey(existing);
      return;
    }

    const newRecord: SurveyItemRecord = {
      id: 'SURV-' + Math.random().toString(36).substring(2, 7).toUpperCase(),
      surveyNo: `SRV-2026-${Math.floor(1000 + Math.random() * 9000)}`,
      containerNo,
      isoCode: size.startsWith('20') ? '22G1' : '45G1',
      size,
      type: size.includes('R') ? 'Reefer High Cube' : 'Dry High Cube',
      owner: shippingLine + ' Marine Transport',
      shippingLine,
      isReefer: size.includes('R'),
      isPreSurveyBeforeGateIn: isPreSurvey,
      gateInTime: isPreSurvey ? 'Chưa Gate-In (Đang ngoài cổng)' : new Date().toISOString().replace('T', ' ').substring(0, 16),
      surveyDate: new Date().toISOString().replace('T', ' ').substring(0, 16),
      surveyor: currentUser,
      status: 'IN_PROGRESS',
      standard: shippingLine === 'COSCO' ? 'MCIC' : 'IICL-6',
      condition: 'AV',
      qualityGrade: 'GRADE_A',
      damages: [],
      checklist: INITIAL_CHECKLIST_TEMPLATE.map((c) => ({ ...c })),
      photos: [],
      remarks: isPreSurvey ? 'Phiếu Pre-Survey lập trước khi vào cổng bãi.' : 'Tiếp nhận giám định tại làn kiểm tra.'
    };

    setSurveys((prev) => [newRecord, ...prev]);
    setSelectedSurvey(newRecord);
  };

  const triggerOpenCreateModal = (contNo: string = '') => {
    setCreatePrefillContNo(contNo);
    setIsCreateModalOpen(true);
  };

  // Transfer to Operation (Khai thác Gate-In & Lập phiếu dịch vụ Tariff)
  const handleTransferToOperation = (record: SurveyItemRecord) => {
    const updatedRecord: SurveyItemRecord = {
      ...record,
      status: 'EEIR_ISSUED',
      eeirNo: record.eeirNo || `EIR-2026-${Math.floor(100000 + Math.random() * 900000)}`,
      eeirIssuedAt: record.eeirIssuedAt || new Date().toISOString().replace('T', ' ').substring(0, 16)
    };

    handleSaveSurvey(updatedRecord);

    if (onNavigateTab) {
      onNavigateTab('operation');
    }
  };

  return (
    <div className="space-y-6">
      {/* Sub-Navigation Bar for Survey Module */}
      <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3">
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-2 shadow-xl flex items-center gap-1 overflow-x-auto select-none flex-1">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id && !selectedSurvey;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  setSelectedSurvey(null);
                }}
                className={`px-3.5 py-2.5 rounded-2xl text-xs font-bold whitespace-nowrap transition flex items-center gap-2 cursor-pointer ${
                  isActive
                    ? 'bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/20'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-slate-950' : 'text-slate-400'}`} />
                <span>{item.label}</span>
                {item.badge !== null && item.badge > 0 && (
                  <span
                    className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono font-bold ${
                      isActive ? 'bg-slate-950 text-amber-400' : 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Global Action Button */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => triggerOpenCreateModal()}
            className="px-4 py-3 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-black text-xs rounded-2xl shadow-lg shadow-amber-500/25 transition flex items-center gap-2 cursor-pointer whitespace-nowrap"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>+ Tạo Mới Giám Định Đầy Đủ</span>
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      {selectedSurvey ? (
        <SurveyDetailForm
          survey={selectedSurvey}
          locations={locations}
          damageCodes={damageCodes}
          repairCodes={repairCodes}
          currentUser={currentUser}
          onBack={() => setSelectedSurvey(null)}
          onSaveSurvey={handleSaveSurvey}
          onOpenEEIR={(s) => setEeirSurvey(s)}
          onTransferToOperation={handleTransferToOperation}
        />
      ) : (
        <>
          {activeTab === 'queue' && (
            <SurveyQueueTable
              title="Danh Sách Container Chờ Giám Định (Survey Queue)"
              subtitle="Tất cả container vừa Gate-in hoặc được phân công cần Surveyor tiếp nhận kiểm tra hiện trường."
              surveys={surveys}
              statusFilterTab="WAITING"
              onSelectSurvey={(s) => setSelectedSurvey(s)}
              onOpenEEIR={(s) => setEeirSurvey(s)}
              onTransferToOperation={handleTransferToOperation}
              onSearchNonGateIn={() => setIsSearchModalOpen(true)}
              onCreateNewSurvey={() => triggerOpenCreateModal()}
            />
          )}

          {activeTab === 'in_progress' && (
            <SurveyQueueTable
              title="Container Đang Giám Định Tại Bãi (In Progress)"
              subtitle="Các vỏ container đang được Surveyor kiểm tra, ghim sơ đồ 2D hoặc chụp ảnh tổn thất."
              surveys={surveys}
              statusFilterTab="IN_PROGRESS"
              onSelectSurvey={(s) => setSelectedSurvey(s)}
              onOpenEEIR={(s) => setEeirSurvey(s)}
              onTransferToOperation={handleTransferToOperation}
              onSearchNonGateIn={() => setIsSearchModalOpen(true)}
              onCreateNewSurvey={() => triggerOpenCreateModal()}
            />
          )}

          {activeTab === 'completed' && (
            <SurveyQueueTable
              title="Container Đã Hoàn Tất Giám Định (Completed Surveys)"
              subtitle="Danh sách vỏ đã nghiệm thu chuẩn IICL, phân loại AV/CL/DM và sẵn sàng phát hành e-EIR."
              surveys={surveys}
              statusFilterTab="COMPLETED"
              onSelectSurvey={(s) => setSelectedSurvey(s)}
              onOpenEEIR={(s) => setEeirSurvey(s)}
              onTransferToOperation={handleTransferToOperation}
              onSearchNonGateIn={() => setIsSearchModalOpen(true)}
              onCreateNewSurvey={() => triggerOpenCreateModal()}
            />
          )}

          {activeTab === 'history' && (
            <SurveyHistoryTable
              surveys={surveys}
              onSelectSurvey={(s) => setSelectedSurvey(s)}
              onOpenEEIR={(s) => setEeirSurvey(s)}
              onTransferToOperation={handleTransferToOperation}
            />
          )}

          {activeTab === 'cleaning_tariffs' && (
            <CleaningMaster
              cleaningTariffs={cleaningTariffs}
              onUpdateCleaningTariffs={(tariffs) => setCleaningTariffs(tariffs)}
            />
          )}

          {activeTab === 'damage_locations' && (
            <DamageLocationMaster
              locations={locations}
              onUpdateLocations={(locs) => setLocations(locs)}
            />
          )}

          {activeTab === 'damage_codes' && (
            <DamageCodeMaster
              damageCodes={damageCodes}
              onUpdateDamageCodes={(codes) => setDamageCodes(codes)}
            />
          )}

          {activeTab === 'repair_codes' && (
            <RepairCodeMaster
              repairCodes={repairCodes}
              onUpdateRepairCodes={(reps) => setRepairCodes(reps)}
            />
          )}

          {activeTab === 'grades' && (
            <GradeMaster
              grades={grades}
              onUpdateGrades={(grds) => setGrades(grds)}
            />
          )}

          {activeTab === 'standards' && (
            <InspectionStandardMaster
              standards={standards}
              onUpdateStandards={(stds) => setStandards(stds)}
            />
          )}

          {activeTab === 'photos' && (
            <SurveyPhotoGallery surveys={surveys} />
          )}

          {activeTab === 'eeir_list' && (
            <SurveyQueueTable
              title="Quản Lý Chứng Từ &amp; Biên Bản Giao Nhận Điện Tử (e-EIR Hub)"
              subtitle="Tra cứu và in ấn các chứng từ e-EIR điện tử đã cấp cho tài xế và hãng tàu."
              surveys={surveys.filter((s) => s.status === 'COMPLETED' || s.status === 'EEIR_ISSUED')}
              statusFilterTab="COMPLETED"
              onSelectSurvey={(s) => setSelectedSurvey(s)}
              onOpenEEIR={(s) => setEeirSurvey(s)}
              onTransferToOperation={handleTransferToOperation}
              onSearchNonGateIn={() => setIsSearchModalOpen(true)}
              onCreateNewSurvey={() => triggerOpenCreateModal()}
            />
          )}
        </>
      )}

      {/* Full Create Survey Modal */}
      <CreateSurveyModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        onSaveSurvey={handleCreateNewSurvey}
        currentUser={currentUser}
        locations={locations}
        damageCodes={damageCodes}
        repairCodes={repairCodes}
        initialContainerNo={createPrefillContNo}
      />

      {/* Search & Non-Gate-In Modal */}
      <ContainerSearchModal
        isOpen={isSearchModalOpen}
        onClose={() => setIsSearchModalOpen(false)}
        existingSurveys={surveys}
        onStartSurvey={handleStartSurvey}
        onOpenFullCreateModal={(contNo) => triggerOpenCreateModal(contNo)}
      />

      {/* e-EIR Preview Modal */}
      {eeirSurvey && (
        <EEIRModal
          isOpen={!!eeirSurvey}
          onClose={() => setEeirSurvey(null)}
          survey={eeirSurvey}
          onTransferToOperation={handleTransferToOperation}
          onProceedToOperation={(s) => {
            handleTransferToOperation(s);
          }}
        />
      )}
    </div>
  );
};
