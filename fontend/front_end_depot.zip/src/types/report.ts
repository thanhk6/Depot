export interface KPIStats {
  totalContainersInYard: number;
  totalGateInToday: number;
  totalGateOutToday: number;
  pendingSurveyCount: number;
  pendingEstimateCount: number;
  underRepairCount: number;
  pendingQCCount: number;
  occupancyRatePercentage: number;
  revenueTodayVnd: number;
}

export interface ReportFilter {
  fromDate: string;
  toDate: string;
  shippingLine?: string;
  isoSize?: string;
  status?: string;
}
