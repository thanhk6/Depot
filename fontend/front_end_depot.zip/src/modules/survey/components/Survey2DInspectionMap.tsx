import React, { useState } from 'react';
import { InspectionZoneKey, DamageRecord, InspectionChecklistItem } from '../types';
import {
  Layers,
  ZoomIn,
  CheckCircle2,
  AlertTriangle,
  PlusCircle,
  Wrench,
  Sparkles,
  Info,
  Maximize2
} from 'lucide-react';

interface Survey2DInspectionMapProps {
  isReefer: boolean;
  damages: DamageRecord[];
  checklist: InspectionChecklistItem[];
  onSelectZone: (zoneKey: InspectionZoneKey, zoneName: string) => void;
  onAddDamageAtZone: (locationCode: string, locationName: string) => void;
}

interface ContainerZoneDef {
  key: InspectionZoneKey;
  code: string;
  name: string;
  vietnameseName: string;
  svgPathType: string;
  description: string;
  x: number;
  y: number;
  width: number;
  height: number;
}

export const Survey2DInspectionMap: React.FC<Survey2DInspectionMapProps> = ({
  isReefer,
  damages,
  checklist,
  onSelectZone,
  onAddDamageAtZone
}) => {
  const [activeZone, setActiveZone] = useState<InspectionZoneKey>('RIGHT_WALL');
  const [viewMode, setViewMode] = useState<'3D_ISO' | 'UNFOLDED_2D'>('UNFOLDED_2D');

  // Map zone key to damage count
  const getZoneDamages = (zoneKey: InspectionZoneKey) => {
    return damages.filter((d) => {
      if (zoneKey === 'ROOF') return d.locationCode.includes('ROOF');
      if (zoneKey === 'FRONT_WALL') return d.locationCode.includes('FRONT');
      if (zoneKey === 'LEFT_WALL') return d.locationCode.includes('LEFT');
      if (zoneKey === 'RIGHT_WALL') return d.locationCode.includes('RIGHT');
      if (zoneKey === 'DOOR') return d.locationCode.includes('DOOR');
      if (zoneKey === 'FLOOR') return d.locationCode.includes('FLOOR');
      if (zoneKey === 'FRAME') return d.locationCode.includes('FRAME') || d.locationCode.includes('RAIL');
      if (zoneKey === 'CORNER_CASTING') return d.locationCode.includes('CORNER');
      if (zoneKey === 'UNDERSTRUCTURE') return d.locationCode.includes('CROSS') || d.locationCode.includes('UNDER');
      if (zoneKey === 'REEFER_UNIT') return d.locationCode.includes('REEFER');
      return false;
    });
  };

  const getZoneStatus = (zoneKey: InspectionZoneKey) => {
    const item = checklist.find((c) => c.zoneKey === zoneKey);
    const zDamages = getZoneDamages(zoneKey);
    if (zDamages.length > 0) return 'DAMAGED';
    if (item?.status === 'FAIL') return 'FAIL';
    if (item?.status === 'NA') return 'NA';
    return 'PASS';
  };

  const zones: ContainerZoneDef[] = [
    { key: 'ROOF', code: 'ROOF', name: 'Roof Panel', vietnameseName: 'Nóc Mái Tôn', svgPathType: 'rect', description: 'Tôn nóc lượn sóng, gân gia cường nóc', x: 190, y: 30, width: 340, height: 95 },
    { key: 'LEFT_WALL', code: 'LEFT_W', name: 'Left Wall', vietnameseName: 'Vách Hông Trái', svgPathType: 'rect', description: 'Vách tôn dọc bên trái (nhìn từ cửa)', x: 190, y: 135, width: 340, height: 95 },
    { key: 'FLOOR', code: 'FLOOR_WD', name: 'Floor & Interior', vietnameseName: 'Sàn Gỗ & Bên Trong', svgPathType: 'rect', description: 'Ván sàn ép 28mm, kiểm tra dầu mỡ, ẩm ướt', x: 190, y: 240, width: 340, height: 95 },
    { key: 'RIGHT_WALL', code: 'RIGHT_W', name: 'Right Wall', vietnameseName: 'Vách Hông Phải', svgPathType: 'rect', description: 'Vách tôn dọc bên phải (nhìn từ cửa)', x: 190, y: 345, width: 340, height: 95 },
    { key: 'FRONT_WALL', code: 'FRONT_W', name: 'Front Wall', vietnameseName: 'Vách Trước', svgPathType: 'rect', description: 'Vách tôn phẳng đối diện cửa sau', x: 50, y: 135, width: 120, height: 200 },
    { key: 'DOOR', code: 'DOOR_L', name: 'Door & Rods', vietnameseName: 'Cửa & Khóa Sau', svgPathType: 'rect', description: 'Cánh cửa thép, gioăng kín nước, tay rod khóa', x: 550, y: 135, width: 120, height: 200 },
    { key: 'CORNER_CASTING', code: 'CORNER_P', name: 'Corner Castings', vietnameseName: 'Gù Góc & Trụ Góc', svgPathType: 'rect', description: '8 gù cẩu chịu lực ISO tiêu chuẩn', x: 50, y: 30, width: 120, height: 95 },
    { key: 'UNDERSTRUCTURE', code: 'CROSS_M', name: 'Understructure', vietnameseName: 'Gầm & Đà Ngang', svgPathType: 'rect', description: 'Đà ngang gầm chữ C, túi nĩa nâng hạ', x: 550, y: 30, width: 120, height: 95 },
    { key: 'FRAME', code: 'BOTTOM_R', name: 'Frame / Rails', vietnameseName: 'Khung Đỡ & Xà Dọc', svgPathType: 'rect', description: 'Xà nóc dọc, xà đáy dọc, dầm liên kết', x: 50, y: 345, width: 120, height: 95 }
  ];

  if (isReefer) {
    zones.push({
      key: 'REEFER_UNIT',
      code: 'REEFER_M',
      name: 'Reefer Unit',
      vietnameseName: 'Cụm Máy Lạnh PTI',
      svgPathType: 'rect',
      description: 'Máy nén lạnh, bảng điều khiển nhiệt độ PTI',
      x: 550,
      y: 345,
      width: 120,
      height: 95
    });
  }

  const selectedZoneDef = zones.find((z) => z.key === activeZone) || zones[0];
  const selectedZoneDamages = getZoneDamages(activeZone);

  return (
    <div className="p-5 bg-slate-900 border border-slate-800 rounded-3xl space-y-4 shadow-xl">
      {/* Schematic Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-600/20 border border-blue-500/30 text-blue-400 rounded-xl">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <span>Sơ Đồ Giám Định 2D Vỏ Container (Interactive 2D Inspection Map)</span>
              <span className="px-2 py-0.5 bg-blue-500/20 text-blue-300 font-mono text-[10px] rounded-full">
                Interactive SVG Map
              </span>
            </h3>
            <p className="text-[11px] text-slate-400">
              Click trực tiếp vào từng mảng thân container trên sơ đồ để ghim vị trí tổn thất và ghi nhận Damage Code IICL.
            </p>
          </div>
        </div>

        {/* Legend */}
        <div className="flex items-center gap-3 text-[11px]">
          <span className="flex items-center gap-1.5 text-emerald-400 font-medium">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" /> Đạt Chuẩn (Pass)
          </span>
          <span className="flex items-center gap-1.5 text-rose-400 font-medium">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" /> Tổn Thất (Damaged)
          </span>
          <span className="flex items-center gap-1.5 text-slate-400 font-medium">
            <span className="w-2.5 h-2.5 rounded-full bg-slate-600" /> Không Áp Dụng (N/A)
          </span>
        </div>
      </div>

      {/* Main 2D Container Canvas & Quick Inspector Side Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* SVG Container Visualizer (8 cols) */}
        <div className="lg:col-span-8 bg-slate-950/80 border border-slate-800/80 rounded-2xl p-4 flex flex-col items-center justify-center relative overflow-hidden">
          <div className="w-full flex items-center justify-between text-xs text-slate-400 mb-2">
            <span className="font-mono text-[11px]">
              &bull; SƠ ĐỒ MẶT BẰNG TRẢI (UNFOLDED CONTAINER SHELL SCHEMATIC)
            </span>
            <span className="text-[10px] text-amber-400 font-medium flex items-center gap-1">
              <Info className="w-3 h-3" /> Chạm vào vùng để mở vị trí
            </span>
          </div>

          {/* SVG Map */}
          <div className="w-full overflow-x-auto py-2">
            <svg
              viewBox="0 0 720 460"
              className="w-full max-w-[680px] mx-auto select-none transition"
            >
              {/* Outer boundary guides */}
              <rect
                x="180"
                y="20"
                width="360"
                height="430"
                fill="none"
                stroke="#1e293b"
                strokeWidth="1.5"
                strokeDasharray="4 4"
                rx="8"
              />

              {/* Zones */}
              {zones.map((zone) => {
                const status = getZoneStatus(zone.key);
                const isSelected = activeZone === zone.key;
                const zoneDmg = getZoneDamages(zone.key);

                let fillColor = '#0f172a';
                let strokeColor = '#334155';
                let textColor = '#94a3b8';

                if (status === 'DAMAGED' || status === 'FAIL') {
                  fillColor = isSelected ? '#450a0a' : '#2b0c0c';
                  strokeColor = '#ef4444';
                  textColor = '#fca5a5';
                } else if (status === 'PASS') {
                  fillColor = isSelected ? '#064e3b' : '#022c22';
                  strokeColor = isSelected ? '#10b981' : '#065f46';
                  textColor = '#6ee7b7';
                } else if (status === 'NA') {
                  fillColor = '#1e293b';
                  strokeColor = '#475569';
                  textColor = '#64748b';
                }

                if (isSelected && status !== 'DAMAGED') {
                  fillColor = '#1e3a8a';
                  strokeColor = '#3b82f6';
                  textColor = '#93c5fd';
                }

                return (
                  <g
                    key={zone.key}
                    onClick={() => {
                      setActiveZone(zone.key);
                      onSelectZone(zone.key, zone.vietnameseName);
                    }}
                    className="cursor-pointer transition-all duration-200 group"
                  >
                    <rect
                      x={zone.x}
                      y={zone.y}
                      width={zone.width}
                      height={zone.height}
                      rx="8"
                      fill={fillColor}
                      stroke={strokeColor}
                      strokeWidth={isSelected ? 2.5 : 1.5}
                      className="transition duration-150"
                    />

                    {/* Corrugation lines simulation for walls/roof */}
                    {['ROOF', 'LEFT_WALL', 'RIGHT_WALL', 'FLOOR'].includes(zone.key) && (
                      <g stroke="#ffffff0a" strokeWidth="1">
                        <line x1={zone.x + 40} y1={zone.y + 10} x2={zone.x + 40} y2={zone.y + zone.height - 10} />
                        <line x1={zone.x + 80} y1={zone.y + 10} x2={zone.x + 80} y2={zone.y + zone.height - 10} />
                        <line x1={zone.x + 120} y1={zone.y + 10} x2={zone.x + 120} y2={zone.y + zone.height - 10} />
                        <line x1={zone.x + 160} y1={zone.y + 10} x2={zone.x + 160} y2={zone.y + zone.height - 10} />
                        <line x1={zone.x + 200} y1={zone.y + 10} x2={zone.x + 200} y2={zone.y + zone.height - 10} />
                        <line x1={zone.x + 240} y1={zone.y + 10} x2={zone.x + 240} y2={zone.y + zone.height - 10} />
                        <line x1={zone.x + 280} y1={zone.y + 10} x2={zone.x + 280} y2={zone.y + zone.height - 10} />
                        <line x1={zone.x + 320} y1={zone.y + 10} x2={zone.x + 320} y2={zone.y + zone.height - 10} />
                      </g>
                    )}

                    {/* Zone Labels */}
                    <text
                      x={zone.x + zone.width / 2}
                      y={zone.y + zone.height / 2 - 6}
                      textAnchor="middle"
                      fill={textColor}
                      fontSize="11"
                      fontWeight="bold"
                      fontFamily="system-ui"
                    >
                      {zone.vietnameseName}
                    </text>

                    <text
                      x={zone.x + zone.width / 2}
                      y={zone.y + zone.height / 2 + 10}
                      textAnchor="middle"
                      fill="#64748b"
                      fontSize="9"
                      fontFamily="monospace"
                    >
                      [{zone.code}]
                    </text>

                    {/* Damage Indicator Badge / Pin */}
                    {zoneDmg.length > 0 && (
                      <g>
                        <circle
                          cx={zone.x + zone.width - 16}
                          cy={zone.y + 16}
                          r="10"
                          fill="#ef4444"
                          stroke="#7f1d1d"
                          strokeWidth="2"
                        />
                        <text
                          x={zone.x + zone.width - 16}
                          y={zone.y + 20}
                          textAnchor="middle"
                          fill="#ffffff"
                          fontSize="10"
                          fontWeight="black"
                        >
                          {zoneDmg.length}
                        </text>
                      </g>
                    )}
                  </g>
                );
              })}
            </svg>
          </div>
        </div>

        {/* Selected Zone Inspector Details (4 cols) */}
        <div className="lg:col-span-4 bg-slate-950/80 border border-slate-800/80 rounded-2xl p-4 flex flex-col justify-between space-y-4">
          <div className="space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div>
                <span className="text-[10px] font-mono font-bold text-blue-400 uppercase">
                  VÙNG ĐANG CHỌN
                </span>
                <h4 className="text-sm font-bold text-white">{selectedZoneDef.vietnameseName}</h4>
              </div>
              <span className="px-2 py-0.5 bg-slate-800 font-mono text-[10px] text-slate-300 font-bold rounded">
                {selectedZoneDef.code}
              </span>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              {selectedZoneDef.description}
            </p>

            {/* Status of this zone */}
            <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">Trạng thái kỹ thuật:</span>
                {selectedZoneDamages.length > 0 ? (
                  <span className="text-rose-400 font-bold flex items-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5" /> Có {selectedZoneDamages.length} lỗi
                  </span>
                ) : (
                  <span className="text-emerald-400 font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Đạt chuẩn IICL
                  </span>
                )}
              </div>
            </div>

            {/* List of damages for this zone */}
            <div className="space-y-1.5">
              <span className="text-[11px] font-semibold text-slate-300 block">
                Tổn thất đã ghi nhận tại vùng này:
              </span>
              {selectedZoneDamages.length === 0 ? (
                <div className="p-3 bg-slate-900/50 border border-slate-800/60 rounded-xl text-center text-xs text-slate-400">
                  Chưa ghi nhận hư hỏng nào tại đây.
                </div>
              ) : (
                <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
                  {selectedZoneDamages.map((dmg) => (
                    <div
                      key={dmg.id}
                      className="p-2.5 bg-rose-950/40 border border-rose-800/50 rounded-xl text-xs space-y-1"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-mono font-bold text-rose-300">
                          {dmg.damageCode} &bull; {dmg.damageName}
                        </span>
                        <span className="text-[10px] bg-rose-900 text-rose-200 px-1.5 py-0.5 rounded">
                          {dmg.severity}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-300">{dmg.description}</p>
                      <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1 border-t border-rose-900/40">
                        <span>Sửa chữa: {dmg.repairName || dmg.repairCode}</span>
                        {dmg.lengthMm && <span>{dmg.lengthMm}x{dmg.widthMm}mm</span>}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Action to add damage at this zone */}
          <button
            onClick={() => onAddDamageAtZone(selectedZoneDef.code, selectedZoneDef.vietnameseName)}
            className="w-full py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-rose-600/20 transition flex items-center justify-center gap-2 cursor-pointer"
          >
            <PlusCircle className="w-4 h-4" />
            <span>+ Ghi Nhận Hư Hỏng Tại {selectedZoneDef.vietnameseName}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
