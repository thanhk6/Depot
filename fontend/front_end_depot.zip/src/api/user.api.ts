import apiClient from './axios';
import { API_ENDPOINTS } from './endpoints';
import { ApiResponse } from '../types/common';
import { User } from '../types/auth';

export const userApi = {
  getUsers: async () => {
    const res = await apiClient.get<ApiResponse<User[]>>(API_ENDPOINTS.SYSTEM.USERS);
    return res.data;
  },
  createUser: async (user: Partial<User>) => {
    const res = await apiClient.post<ApiResponse<User>>(API_ENDPOINTS.SYSTEM.USERS, user);
    return res.data;
  },
  updateUser: async (id: string, user: Partial<User>) => {
    const res = await apiClient.put<ApiResponse<User>>(API_ENDPOINTS.SYSTEM.USER_BY_ID(id), user);
    return res.data;
  },
};

export const roleApi = {
  getRoles: async () => {
    const res = await apiClient.get<ApiResponse<any[]>>(API_ENDPOINTS.SYSTEM.ROLES);
    return res.data;
  },
};

export const permissionApi = {
  getPermissions: async () => {
    const res = await apiClient.get<ApiResponse<any[]>>(API_ENDPOINTS.SYSTEM.PERMISSIONS);
    return res.data;
  },
};

export const menuApi = {
  getMenus: async () => {
    const res = await apiClient.get<ApiResponse<any[]>>(API_ENDPOINTS.SYSTEM.MENUS);
    return res.data;
  },
};

