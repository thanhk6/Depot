import React from 'react';
import {
  DollarSign,
  AlertTriangle,
  TrendingUp,
  CreditCard,
  Scale,
  PlusCircle,
  RefreshCw,
  CalendarCheck,
  Download,
  FileSpreadsheet
} from 'lucide-react';

interface DebtDashboardKPIProps {
  totalReceivables: number;
  overdueAmount: number;
  periodDebit: number;
  periodCredit: number;
  closingBalance: number;
  currency: 'VND' | 'USD';
  onOpenPaymentModal: () => void;
  onOpenSyncModal: () => void;
  onOpenClosePeriodModal: () => void;
  onExportExcel: () => void;
  onExportPDF: () => void;
}

export const DebtDashboardKPI: React.FC<DebtDashboardKPIProps> = ({
  totalReceivables,
  overdueAmount,
  periodDebit,
  periodCredit,
  closingBalance,
  currency,
  onOpenPaymentModal,
  onOpenSyncModal,
  onOpenClosePeriodModal,
  onExportExcel,
  onExportPDF
}) => {
  const formatMoney = (amount: number) => {
    return amount.toLocaleString('vi-VN') + (currency === 'VND' ? ' đ' : ' $');
  };

  return (
    <div className="space-y-4">
      {/* Header & Quick Action Bar */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 bg-slate-900/90 border border-slate-800 p-4 sm:p-5 rounded-2xl">
        <div>
          <div className="flex items-center gap-2.5">
            <span className="p-2 rounded-xl bg-sky-500/10 text-sky-400 border border-sky-500/20">
              <Scale className="w-5 h-5" />
            </span>
            <div>
              <h1 className="text-lg sm:text-xl font-bold text-white tracking-tight">
                Quản Lý Công Nợ Hãng Tàu (Shipping Line AR)
              </h1>
              <p className="text-xs text-slate-400">
                Theo dõi phát sinh công nợ từ Báo giá & Sửa chữa hoàn thành, đối soát theo kỳ và phân bổ thanh toán
              </p>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={onOpenSyncModal}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition cursor-pointer"
            title="Quét dữ liệu Báo giá đã duyệt & Container đã sửa xong để tạo công nợ"
          >
            <RefreshCw className="w-3.5 h-3.5 text-sky-400" />
            <span>Đồng bộ từ Sửa chữa</span>
          </button>

          <button
            onClick={onOpenClosePeriodModal}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-purple-900/40 hover:bg-purple-800/60 text-purple-200 text-xs font-semibold border border-purple-700/50 transition cursor-pointer"
            title="Chốt kỳ công nợ hiện tại và chuyển số dư sang kỳ tiếp theo"
          >
            <CalendarCheck className="w-3.5 h-3.5 text-purple-400" />
            <span>Chốt kỳ công nợ</span>
          </button>

          <button
            onClick={onOpenPaymentModal}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold shadow-lg shadow-sky-900/40 transition cursor-pointer"
            title="Ghi nhận tiền thanh toán và phân bổ cho từng container"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Xác nhận & Phân bổ Thanh toán</span>
          </button>
        </div>
      </div>

      {/* 5 Core Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 sm:gap-4">
        {/* Card 1: Tổng Phải Thu (Total Receivables) */}
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl space-y-2 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">
              Tổng nợ phải thu
            </span>
            <div className="p-1.5 rounded-lg bg-sky-500/10 text-sky-400">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-black text-white tracking-tight">
            {formatMoney(totalReceivables)}
          </div>
          <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
            <span className="inline-block w-2 h-2 rounded-full bg-sky-400"></span>
            <span>Tổng các khoản nợ còn lại</span>
          </div>
        </div>

        {/* Card 2: Công nợ Quá Hạn (Overdue) */}
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl space-y-2 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-rose-400 uppercase tracking-wider">
              Công nợ quá hạn
            </span>
            <div className="p-1.5 rounded-lg bg-rose-500/10 text-rose-400">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-black text-rose-400 tracking-tight">
            {formatMoney(overdueAmount)}
          </div>
          <div className="flex items-center gap-1.5 text-[11px] text-rose-300">
            <span className="inline-block w-2 h-2 rounded-full bg-rose-500 animate-pulse"></span>
            <span>Quá hạn Net 30 ngày</span>
          </div>
        </div>

        {/* Card 3: Phát Sinh Kỳ Này (Period Debit) */}
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl space-y-2 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-amber-400 uppercase tracking-wider">
              Phát sinh kỳ này (+)
            </span>
            <div className="p-1.5 rounded-lg bg-amber-500/10 text-amber-400">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-black text-amber-300 tracking-tight">
            +{formatMoney(periodDebit)}
          </div>
          <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
            <span>Từ sửa chữa hoàn thành</span>
          </div>
        </div>

        {/* Card 4: Đã Thanh Toán Kỳ Này (Period Credit) */}
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl space-y-2 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-emerald-400 uppercase tracking-wider">
              Đã thu kỳ này (-)
            </span>
            <div className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400">
              <CreditCard className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-black text-emerald-400 tracking-tight">
            -{formatMoney(periodCredit)}
          </div>
          <div className="flex items-center gap-1.5 text-[11px] text-emerald-300">
            <span>Đã phân bổ cho container</span>
          </div>
        </div>

        {/* Card 5: Dư Cuối Kỳ (Closing Balance) */}
        <div className="bg-slate-900 border border-sky-800/40 p-4 rounded-2xl space-y-2 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-sky-300 uppercase tracking-wider">
              Dư nợ cuối kỳ
            </span>
            <div className="p-1.5 rounded-lg bg-sky-500/20 text-sky-300">
              <Scale className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-black text-sky-400 tracking-tight">
            {formatMoney(closingBalance)}
          </div>
          <div className="flex items-center gap-1.5 text-[11px] text-sky-300">
            <span>= Dư đầu + Phát sinh - Thu</span>
          </div>
        </div>
      </div>
    </div>
  );
};
