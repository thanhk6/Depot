import React, { useState } from 'react';
import { ShippingLineDebt } from '../types';
import {
  X,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  FileCheck,
  Wrench,
  Container,
  ShieldCheck
} from 'lucide-react';

interface EligibleCandidate {
  containerNo: string;
  shippingLineId: string;
  shippingLineName: string;
  quotationId: string;
  quotationNo: string;
  repairId: string;
  repairNo: string;
  completedDate: string;
  description: string;
  amount: number;
  approvalRef: string;
}

interface SyncDebtModalProps {
  isOpen: boolean;
  onClose: () => void;
  existingDebts: ShippingLineDebt[];
  onSyncDebts: (newDebts: ShippingLineDebt[]) => void;
  currency: 'VND' | 'USD';
}

export const SyncDebtModal: React.FC<SyncDebtModalProps> = ({
  isOpen,
  onClose,
  existingDebts,
  onSyncDebts,
  currency
}) => {
  // Candidates derived from completed work orders / approved estimates that are not yet in existingDebts
  const candidatePool: EligibleCandidate[] = [
    {
      containerNo: 'MAEU7719283',
      shippingLineId: 'MAERSK',
      shippingLineName: 'MAERSK LINE A/S',
      quotationId: 'EST-REC-014',
      quotationNo: 'BG-2026-00148',
      repairId: 'WO-REC-014',
      repairNo: 'WO-20260817-00008',
      completedDate: '2026-08-17',
      description: 'Nắn cong vênh xà nóc trần + Hàn đắp kín nước chuẩn IICL-6',
      amount: 4200000,
      approvalRef: 'MAE-AUTH-2026-99120'
    },
    {
      containerNo: 'MSKU6610293',
      shippingLineId: 'MAERSK',
      shippingLineName: 'MAERSK LINE A/S',
      quotationId: 'EST-REC-015',
      quotationNo: 'BG-2026-00149',
      repairId: 'WO-REC-015',
      repairNo: 'WO-20260817-00009',
      completedDate: '2026-08-17',
      description: 'Thay 2 tấm ván sàn Apitong 28mm và thay gioăng cao su cửa chữ J',
      amount: 5800000,
      approvalRef: 'MAE-AUTH-2026-99125'
    },
    {
      containerNo: 'MAEU3391088',
      shippingLineId: 'MAERSK',
      shippingLineName: 'MAERSK LINE A/S',
      quotationId: 'EST-REC-016',
      quotationNo: 'BG-2026-00150',
      repairId: 'WO-REC-016',
      repairNo: 'WO-20260817-00010',
      completedDate: '2026-08-17',
      description: 'Gia nhiệt nắn tay khóa cửa kẹt cứng và xịt rửa khử mùi tanh thực phẩm',
      amount: 1950000,
      approvalRef: 'MAE-AUTH-2026-99130'
    }
  ];

  // Filter candidates that are NOT already in existingDebts
  const eligibleCandidates = candidatePool.filter(
    (c) => !(existingDebts || []).some((d) => d.quotationId === c.quotationId || d.containerNo === c.containerNo)
  );

  const [selectedCandidates, setSelectedCandidates] = useState<string[]>(
    eligibleCandidates.map((c) => c.containerNo)
  );

  if (!isOpen) return null;

  const toggleSelect = (contNo: string) => {
    setSelectedCandidates((prev) =>
      prev.includes(contNo) ? prev.filter((c) => c !== contNo) : [...prev, contNo]
    );
  };

  const toggleSelectAll = () => {
    if (selectedCandidates.length === eligibleCandidates.length) {
      setSelectedCandidates([]);
    } else {
      setSelectedCandidates(eligibleCandidates.map((c) => c.containerNo));
    }
  };

  const formatMoney = (amount: number) => {
    return (amount || 0).toLocaleString('vi-VN') + (currency === 'VND' ? ' đ' : ' $');
  };

  const handleConfirmSync = () => {
    const toImport = eligibleCandidates.filter((c) =>
      selectedCandidates.includes(c.containerNo)
    );

    const newDebts: ShippingLineDebt[] = toImport.map((c, idx) => ({
      id: `DEBT-SYNC-${Date.now()}-${idx}`,
      shippingLineId: c.shippingLineId,
      shippingLineName: c.shippingLineName,
      containerId: `CONT-${c.containerNo}`,
      containerNo: c.containerNo,
      quotationId: c.quotationId,
      quotationNo: c.quotationNo,
      repairId: c.repairId,
      repairNo: c.repairNo,
      debtPeriodId: 'PERIOD-2026-08-16',
      debtDate: c.completedDate,
      dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      serviceType: 'REPAIR',
      description: c.description,
      totalAmount: c.amount,
      paidAmount: 0,
      remainingAmount: c.amount,
      status: 'UNPAID',
      currency: 'VND',
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
      updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
      approvalRef: c.approvalRef,
      notes: 'Tự động đồng bộ từ Báo giá đã duyệt & Sửa chữa hoàn thành.'
    }));

    onSyncDebts(newDebts);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/70">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-sky-500/20 text-sky-400 border border-sky-500/30">
              <RefreshCw className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-tight">
                Đồng Bộ Công Nợ Từ Sửa Chữa Hoàn Thành
              </h2>
              <p className="text-xs text-slate-400">
                Tự động kiểm tra Báo giá đã duyệt & Container hoàn tất sửa chữa để ghi nhận vào sổ công nợ
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 space-y-4">
          {/* Business rules verification badge */}
          <div className="bg-slate-950 border border-slate-800 p-3.5 rounded-2xl text-xs space-y-1.5 text-slate-300">
            <div className="font-bold text-white flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Tiêu chí kiểm tra hợp lệ (5 điều kiện bắt buộc):</span>
            </div>
            <ul className="text-[11px] text-slate-400 list-disc list-inside space-y-0.5">
              <li>Báo giá đã được hãng tàu phê duyệt (Status = APPROVED)</li>
              <li>Container đã thi công sửa chữa hoàn tất & nghiệm thu QC Pass</li>
              <li>Có số tiền phải thu &gt; 0</li>
              <li>Chưa tạo công nợ trùng lặp (Anti-Duplicate Guard)</li>
            </ul>
          </div>

          {/* Candidates List */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <div className="font-bold text-white uppercase">
                Danh sách phát hiện ({eligibleCandidates.length} container mới)
              </div>
              {eligibleCandidates.length > 0 && (
                <button
                  type="button"
                  onClick={toggleSelectAll}
                  className="text-sky-400 hover:text-sky-300 underline cursor-pointer"
                >
                  {selectedCandidates.length === eligibleCandidates.length
                    ? 'Bỏ chọn tất cả'
                    : 'Chọn tất cả'}
                </button>
              )}
            </div>

            {eligibleCandidates.length === 0 ? (
              <div className="bg-slate-950/60 border border-slate-800 p-8 rounded-2xl text-center text-xs text-slate-500">
                <CheckCircle2 className="w-8 h-8 mx-auto text-emerald-400/50 mb-2" />
                Toàn bộ Container đã sửa chữa hoàn thành đều đã được đồng bộ vào Sổ công nợ. Không phát hiện bản ghi mới nào.
              </div>
            ) : (
              <div className="space-y-2 max-h-60 overflow-y-auto">
                {eligibleCandidates.map((cand) => {
                  const isChecked = selectedCandidates.includes(cand.containerNo);
                  return (
                    <div
                      key={cand.containerNo}
                      onClick={() => toggleSelect(cand.containerNo)}
                      className={`p-3 rounded-2xl border transition cursor-pointer flex items-center justify-between gap-3 select-none ${
                        isChecked
                          ? 'bg-slate-950 border-sky-500/50 shadow-md'
                          : 'bg-slate-950/50 border-slate-800 opacity-60'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => {}}
                          className="w-4 h-4 accent-sky-500 rounded cursor-pointer"
                        />
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-mono font-bold text-white text-xs">
                              {cand.containerNo}
                            </span>
                            <span className="px-2 py-0.5 rounded-md bg-slate-800 text-sky-400 font-mono text-[10px] border border-slate-700">
                              {cand.shippingLineId}
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-400 mt-0.5">
                            Báo giá: <strong className="text-slate-300 font-mono">{cand.quotationNo}</strong> | Lệnh SC: <strong className="text-slate-300 font-mono">{cand.repairNo}</strong>
                          </div>
                        </div>
                      </div>

                      <div className="text-right">
                        <div className="font-mono font-bold text-emerald-400 text-sm">
                          {formatMoney(cand.amount)}
                        </div>
                        <div className="text-[10px] text-slate-500 font-mono">
                          {cand.approvalRef}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Actions */}
          <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition cursor-pointer"
            >
              Hủy
            </button>
            <button
              type="button"
              onClick={handleConfirmSync}
              disabled={selectedCandidates.length === 0}
              className={`px-5 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-2 shadow-lg ${
                selectedCandidates.length > 0
                  ? 'bg-sky-600 hover:bg-sky-500 text-white shadow-sky-900/40'
                  : 'bg-slate-800 text-slate-500 cursor-not-allowed'
              }`}
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Đồng Bộ {selectedCandidates.length} Khoản Công Nợ Mới</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
