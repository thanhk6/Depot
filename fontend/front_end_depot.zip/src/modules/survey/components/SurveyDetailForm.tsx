import React, { useState } from 'react';
import {
  SurveyItemRecord,
  ContainerConditionGrade,
  QualityGradeType,
  CleaningReasonType,
  CleaningMethodType,
  CleaningTariffMasterItem,
  SurveyCleaningItemRecord,
  InspectionZoneKey,
  ZoneCheckStatus,
  DamageRecord,
  SurveyPhoto,
  DamageLocationMasterItem,
  DamageCodeMasterItem,
  RepairCodeMasterItem
} from '../types';
import { INITIAL_CLEANING_TARIFFS } from '../mockData';
import { DamageListTable } from './DamageListTable';
import { DamageFormModal } from './DamageFormModal';
import {
  ClipboardCheck,
  CheckCircle2,
  AlertTriangle,
  Wrench,
  Sparkles,
  ShieldCheck,
  Camera,
  Image as ImageIcon,
  FileText,
  Save,
  ArrowLeft,
  Truck,
  Ship,
  Calendar,
  User,
  Plus,
  Trash2,
  HelpCircle,
  Maximize2,
  XCircle,
  AlertCircle,
  Tag,
  Zap,
  Droplets,
  Receipt,
  DollarSign,
  CheckSquare,
  Square,
  Flame,
  Check,
  Clock
} from 'lucide-react';

interface SurveyDetailFormProps {
  survey: SurveyItemRecord;
  locations: DamageLocationMasterItem[];
  damageCodes: DamageCodeMasterItem[];
  repairCodes: RepairCodeMasterItem[];
  currentUser: string;
  onBack: () => void;
  onSaveSurvey: (updated: SurveyItemRecord) => void;
  onOpenEEIR: (survey: SurveyItemRecord) => void;
  onTransferToOperation?: (survey: SurveyItemRecord) => void;
}

export const SurveyDetailForm: React.FC<SurveyDetailFormProps> = ({
  survey,
  locations,
  damageCodes,
  repairCodes,
  currentUser,
  onBack,
  onSaveSurvey,
  onOpenEEIR,
  onTransferToOperation
}) => {
  // Form working states - Default tab is directly DAMAGES
  const [formData, setFormData] = useState<SurveyItemRecord>({ ...survey });
  const [activeTab, setActiveTab] = useState<'DAMAGES' | 'CHECKLIST' | 'CLEANING' | 'PHOTOS'>(
    survey.condition === 'CL' ? 'CLEANING' : 'DAMAGES'
  );

  // Helper to calculate price of a cleaning tariff for current container size & type
  const getTariffCost = (tariff: CleaningTariffMasterItem): number => {
    const isReefer = formData.isReefer || formData.type?.includes('R') || formData.sizeType?.includes('R') || false;
    const size = formData.sizeType || `${formData.size}${formData.type}` || '40HC';
    if (isReefer) {
      if (size.includes('20')) return tariff.price20RF;
      return tariff.price40HR;
    }
    if (size.includes('20')) return tariff.price20DC;
    if (size.includes('45')) return tariff.price45HC;
    if (size.includes('HC')) return tariff.price40HC;
    return tariff.price40DC;
  };

  const handleAddCleaningItem = (tariff: CleaningTariffMasterItem) => {
    const unitPrice = getTariffCost(tariff);
    const newItem: SurveyCleaningItemRecord = {
      id: 'CLN-' + Math.random().toString(36).substring(2, 9).toUpperCase(),
      cleaningCode: tariff.cleaningCode,
      cleaningName: tariff.vietnameseName || tariff.name,
      category: tariff.category,
      chemicalRequired: !!tariff.chemicalRequired,
      chemicalName: tariff.chemicalRequired || undefined,
      quantity: 1,
      unitPrice,
      totalPrice: unitPrice,
      responsibleParty: tariff.responsiblePartyDefault || 'U',
      status: 'REQUIRED',
      notes: ''
    };

    setFormData((prev) => {
      const currentList = prev.cleaningItems || [];
      const updatedList = [...currentList, newItem];
      const newTotal = updatedList.reduce((sum, item) => sum + (item.totalPrice || 0), 0);
      return {
        ...prev,
        condition: 'CL',
        cleaningItems: updatedList,
        cleaningTotalCost: newTotal,
        cleaningEstimatedCost: newTotal
      };
    });
    setSaveSuccessMessage(`Đã thêm dịch vụ vệ sinh "${tariff.vietnameseName || tariff.name}" (${unitPrice.toLocaleString('vi-VN')} đ)`);
    setTimeout(() => setSaveSuccessMessage(null), 3000);
  };

  const handleRemoveCleaningItem = (id: string) => {
    setFormData((prev) => {
      const updatedList = (prev.cleaningItems || []).filter((item) => item.id !== id);
      const newTotal = updatedList.reduce((sum, item) => sum + (item.totalPrice || 0), 0);
      return {
        ...prev,
        cleaningItems: updatedList,
        cleaningTotalCost: newTotal,
        cleaningEstimatedCost: newTotal,
        condition: updatedList.length > 0 ? 'CL' : prev.damages?.length ? 'DM' : 'AV'
      };
    });
  };

  const handleToggleCleaningStatus = (id: string) => {
    setFormData((prev) => {
      const updatedList: SurveyCleaningItemRecord[] = (prev.cleaningItems || []).map((item) => {
        if (item.id === id) {
          const nextStatus: 'REQUIRED' | 'IN_PROGRESS' | 'COMPLETED' =
            item.status === 'COMPLETED'
              ? 'REQUIRED'
              : item.status === 'IN_PROGRESS'
              ? 'COMPLETED'
              : 'IN_PROGRESS';
          return {
            ...item,
            status: nextStatus,
            completedAt:
              nextStatus === 'COMPLETED'
                ? new Date().toISOString().replace('T', ' ').substring(0, 16)
                : undefined
          };
        }
        return item;
      });
      return { ...prev, cleaningItems: updatedList };
    });
  };

  const handleUpdateCleaningParty = (id: string, party: 'O' | 'U' | 'T') => {
    setFormData((prev) => {
      const updatedList = (prev.cleaningItems || []).map((item) =>
        item.id === id ? { ...item, responsibleParty: party } : item
      );
      return { ...prev, cleaningItems: updatedList };
    });
  };

  // Damage modal state
  const [isDamageModalOpen, setIsDamageModalOpen] = useState(false);
  const [editingDamage, setEditingDamage] = useState<DamageRecord | null>(null);
  const [selectedLocationCode, setSelectedLocationCode] = useState<string>('RIGHT_W');
  const [selectedLocationName, setSelectedLocationName] = useState<string>('Vách hông phải');

  // Quick Damage Direct Entry Inline State
  const [quickLocation, setQuickLocation] = useState<string>('RIGHT_W');
  const [quickDamageCode, setQuickDamageCode] = useState<string>('BENT');
  const [quickRepairCode, setQuickRepairCode] = useState<string>('RP_STRAIGHT');
  const [quickSeverity, setQuickSeverity] = useState<'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL'>('MEDIUM');
  const [quickLength, setQuickLength] = useState<string>('150');
  const [quickWidth, setQuickWidth] = useState<string>('60');
  const [quickQuantity, setQuickQuantity] = useState<string>('1');
  const [quickNote, setQuickNote] = useState<string>('');

  // Photo viewer modal
  const [photoViewerUrl, setPhotoViewerUrl] = useState<{ url: string; caption: string } | null>(null);

  // Validation errors
  const [validationErrors, setValidationErrors] = useState<string[]>([]);
  const [saveSuccessMessage, setSaveSuccessMessage] = useState<string | null>(null);

  // Quick photo upload simulation
  const handleAddPhoto = (type: 'OVERVIEW' | 'DETAIL' | 'DOOR_SEAL' | 'INTERIOR_FLOOR') => {
    const newPhoto: SurveyPhoto = {
      id: 'PH-' + Math.random().toString(36).substring(2, 7).toUpperCase(),
      url:
        type === 'OVERVIEW'
          ? 'https://images.unsplash.com/photo-1578575437130-527eed3abbec?w=600&auto=format&fit=crop&q=60'
          : type === 'DETAIL'
          ? 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=600&auto=format&fit=crop&q=60'
          : 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=600&auto=format&fit=crop&q=60',
      type,
      caption:
        type === 'OVERVIEW'
          ? `Ảnh toàn cảnh vỏ ${formData.containerNo}`
          : type === 'DETAIL'
          ? 'Ảnh chụp cận cảnh tổn thất hiện trường'
          : 'Ảnh kiểm tra ron cao su cửa',
      surveyor: currentUser,
      uploadedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
      fileSizeKb: Math.floor(800 + Math.random() * 800)
    };

    setFormData((prev) => ({
      ...prev,
      photos: [...(prev.photos || []), newPhoto]
    }));
  };

  const handleAddStandardPhotoSet = () => {
    const timestamp = new Date().toISOString().replace('T', ' ').substring(0, 16);
    const overviewPhoto: SurveyPhoto = {
      id: 'PH-' + Math.random().toString(36).substring(2, 7).toUpperCase(),
      url: 'https://images.unsplash.com/photo-1578575437130-527eed3abbec?w=600&auto=format&fit=crop&q=60',
      type: 'OVERVIEW',
      caption: `[01/02] Ảnh toàn cảnh góc 45° vỏ ${formData.containerNo}`,
      surveyor: currentUser,
      uploadedAt: timestamp,
      fileSizeKb: 890
    };

    const detailPhoto: SurveyPhoto = {
      id: 'PH-' + Math.random().toString(36).substring(2, 7).toUpperCase(),
      url: 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=600&auto=format&fit=crop&q=60',
      type: 'DETAIL',
      caption: `[02/02] Ảnh cận cảnh vị trí ${formData.condition === 'CL' ? 'cần vệ sinh' : 'hư hỏng/bẩn'}`,
      surveyor: currentUser,
      uploadedAt: timestamp,
      fileSizeKb: 930
    };

    setFormData((prev) => ({
      ...prev,
      photos: [...(prev.photos || []), overviewPhoto, detailPhoto]
    }));
  };

  const handleDeletePhoto = (photoId: string) => {
    setFormData((prev) => ({
      ...prev,
      photos: (prev.photos || []).filter((p) => p.id !== photoId)
    }));
  };

  // Checklist status toggle
  const handleToggleChecklistStatus = (zoneKey: InspectionZoneKey, status: ZoneCheckStatus) => {
    setFormData((prev) => {
      const updatedChecklist = prev.checklist.map((item) =>
        item.zoneKey === zoneKey ? { ...item, status } : item
      );

      // Auto update condition if failure
      let autoCondition = prev.condition;
      if (status === 'FAIL') {
        if (zoneKey === 'CLEANING') {
          autoCondition = 'CL';
        } else {
          autoCondition = 'DM';
        }
      }

      return {
        ...prev,
        checklist: updatedChecklist,
        condition: autoCondition
      };
    });
  };

  // Damage handlers
  const handleOpenAddDamage = (locCode?: string, locName?: string) => {
    setEditingDamage(null);
    if (locCode) setSelectedLocationCode(locCode);
    if (locName) setSelectedLocationName(locName);
    setIsDamageModalOpen(true);
  };

  const handleSaveDamage = (record: DamageRecord) => {
    setFormData((prev) => {
      const existing = prev.damages || [];
      const updatedDamages = editingDamage
        ? existing.map((d) => (d.id === record.id ? record : d))
        : [...existing, record];

      // Update checklist item to FAIL for this location
      const updatedChecklist = prev.checklist.map((c) => {
        if (record.locationCode.includes(c.zoneKey.replace('_WALL', ''))) {
          return { ...c, status: 'FAIL' as const, damageCount: (c.damageCount || 0) + 1 };
        }
        return c;
      });

      return {
        ...prev,
        damages: updatedDamages,
        condition: 'DM', // Automatic DM when damage is added
        checklist: updatedChecklist
      };
    });
  };

  // Quick Direct Add Handler
  const handleQuickAddDamage = (e: React.FormEvent) => {
    e.preventDefault();
    const loc = locations.find((l) => l.code === quickLocation);
    const dmg = damageCodes.find((d) => d.code === quickDamageCode);
    const rep = repairCodes.find((r) => r.repairCode === quickRepairCode);

    const now = new Date().toISOString().replace('T', ' ').substring(0, 16);

    const newRecord: DamageRecord = {
      id: 'DMG-' + Math.random().toString(36).substring(2, 9).toUpperCase(),
      locationCode: quickLocation,
      locationName: loc?.vietnameseName || quickLocation,
      damageCode: quickDamageCode,
      damageName: dmg?.vietnameseName || quickDamageCode,
      repairCode: quickRepairCode,
      repairName: rep?.vietnameseName || quickRepairCode,
      description: quickNote || `${dmg?.vietnameseName || quickDamageCode} tại ${loc?.vietnameseName || quickLocation}`,
      severity: quickSeverity,
      lengthMm: Number(quickLength) || 0,
      widthMm: Number(quickWidth) || 0,
      quantity: Number(quickQuantity) || 1,
      photoUrl: 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=600&auto=format&fit=crop&q=60',
      createdBy: currentUser,
      createdAt: now
    };

    handleSaveDamage(newRecord);
    setQuickNote('');
    setSaveSuccessMessage(`Đã thêm mã lỗi ${quickDamageCode} (${loc?.vietnameseName}) thành công!`);
    setTimeout(() => setSaveSuccessMessage(null), 3000);
  };

  const handleDeleteDamage = (id: string) => {
    setFormData((prev) => {
      const updatedDamages = (prev.damages || []).filter((d) => d.id !== id);
      return {
        ...prev,
        damages: updatedDamages,
        condition: updatedDamages.length > 0 ? 'DM' : 'AV'
      };
    });
  };

  // Validation Logic
  const validateForm = (): boolean => {
    const errors: string[] = [];

    if (!formData.containerNo || formData.containerNo.length < 10) {
      errors.push('Số Container không hợp lệ (cần đúng 11 ký tự ISO chuẩn quốc tế).');
    }

    if (!formData.surveyor) {
      errors.push('Chưa chỉ định Giám Định Viên thực hiện.');
    }

    if (formData.condition === 'CL') {
      if (!formData.cleaningReason || formData.cleaningReason.length === 0) {
        errors.push('Vui lòng chọn ít nhất 01 lý do cần vệ sinh khi phân loại CL (Bụi bẩn, Rác, Mùi, Dầu mỡ...).');
      }
    }

    if (formData.condition === 'DM') {
      if (!formData.damages || formData.damages.length === 0) {
        errors.push('Phân loại DM (Damaged) bắt buộc phải ghi nhận ít nhất 01 tổn thất (Damage Record).');
      }
    }

    // Required photos: at least 1 overview
    const overviewPhoto = (formData.photos || []).find((p) => p.type === 'OVERVIEW');
    if (!overviewPhoto) {
      errors.push('Quy chuẩn bắt buộc phải có ít nhất 01 Ảnh Toàn Cảnh (Overview Photo) trước khi hoàn tất.');
    }

    setValidationErrors(errors);
    return errors.length === 0;
  };

  const handleSaveDraft = () => {
    onSaveSurvey({
      ...formData,
      status: formData.status === 'NEW' ? 'IN_PROGRESS' : formData.status
    });
    setSaveSuccessMessage('Đã lưu nháp tiến độ giám định thành công.');
    setTimeout(() => setSaveSuccessMessage(null), 3500);
  };

  const handleCompleteSurvey = () => {
    if (!validateForm()) {
      return;
    }

    const completedRecord: SurveyItemRecord = {
      ...formData,
      status: 'COMPLETED',
      eeirNo: formData.eeirNo || `EIR-2026-${Math.floor(100000 + Math.random() * 900000)}`,
      eeirIssuedAt: new Date().toISOString().replace('T', ' ').substring(0, 16)
    };

    setFormData(completedRecord);
    onSaveSurvey(completedRecord);
    setSaveSuccessMessage('Đã hoàn tất giám định và tự động sinh số e-EIR thành công!');
    setTimeout(() => setSaveSuccessMessage(null), 4000);
  };

  const handleIssueEEIR = () => {
    if (formData.status !== 'COMPLETED' && formData.status !== 'EEIR_ISSUED') {
      if (!validateForm()) return;
    }
    const issuedRecord: SurveyItemRecord = {
      ...formData,
      status: 'EEIR_ISSUED',
      eeirNo: formData.eeirNo || `EIR-2026-${Math.floor(100000 + Math.random() * 900000)}`,
      eeirIssuedAt: new Date().toISOString().replace('T', ' ').substring(0, 16)
    };
    setFormData(issuedRecord);
    onSaveSurvey(issuedRecord);
    onOpenEEIR(issuedRecord);
  };

  const handleIssueEEIRAndTransfer = () => {
    if (formData.status !== 'COMPLETED' && formData.status !== 'EEIR_ISSUED') {
      if (!validateForm()) return;
    }
    const issuedRecord: SurveyItemRecord = {
      ...formData,
      status: 'EEIR_ISSUED',
      eeirNo: formData.eeirNo || `EIR-2026-${Math.floor(100000 + Math.random() * 900000)}`,
      eeirIssuedAt: new Date().toISOString().replace('T', ' ').substring(0, 16)
    };
    setFormData(issuedRecord);
    onSaveSurvey(issuedRecord);
    if (onTransferToOperation) {
      onTransferToOperation(issuedRecord);
    } else {
      onOpenEEIR(issuedRecord);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header & Breadcrumb */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 bg-slate-900 border border-slate-800 rounded-3xl shadow-xl">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl transition cursor-pointer"
            title="Quay lại danh sách"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <div className="flex items-center gap-2.5">
              <span className="text-xl font-black font-mono text-amber-400">
                {formData.containerNo}
              </span>
              <span
                className={`text-[10px] font-black px-2.5 py-0.5 rounded-full border ${
                  formData.condition === 'AV'
                    ? 'bg-emerald-950 text-emerald-300 border-emerald-800'
                    : formData.condition === 'CL'
                    ? 'bg-amber-950 text-amber-300 border-amber-800'
                    : 'bg-rose-950 text-rose-300 border-rose-800'
                }`}
              >
                {formData.condition} &bull;{' '}
                {formData.condition === 'AV' ? 'ĐẠT CHUẨN' : formData.condition === 'CL' ? 'CẦN VỆ SINH' : 'HƯ HỎNG'}
              </span>
              <span className="text-xs text-slate-400 font-mono">[{formData.surveyNo}]</span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              {formData.shippingLine} &bull; {formData.size} {formData.type} &bull; Gate-In:{' '}
              {formData.gateInTime}
            </p>
          </div>
        </div>

        {/* Top Control Buttons */}
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={handleSaveDraft}
            className="px-3 py-2 bg-slate-800 hover:bg-slate-750 text-slate-300 font-semibold text-xs rounded-xl border border-slate-700 transition flex items-center gap-1.5 cursor-pointer"
          >
            <Save className="w-3.5 h-3.5 text-blue-400" />
            <span>Lưu Tạm</span>
          </button>

          <button
            onClick={handleCompleteSurvey}
            className="px-3.5 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl shadow transition flex items-center gap-1.5 cursor-pointer"
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Hoàn Tất Giám Định</span>
          </button>

          <button
            onClick={handleIssueEEIR}
            className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl shadow transition flex items-center gap-1.5 cursor-pointer"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Xem e-EIR</span>
          </button>

          <button
            onClick={handleIssueEEIRAndTransfer}
            className="px-4 py-2 bg-gradient-to-r from-sky-600 to-blue-600 hover:from-sky-500 hover:to-blue-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-sky-600/25 transition flex items-center gap-1.5 cursor-pointer"
            title="Phát hành e-EIR điện tử và chuyển ngay sang phân hệ Khai Thác Gate-In để lập Phiếu Dịch Vụ Tariff"
          >
            <Receipt className="w-3.5 h-3.5" />
            <span>Phát Hành & Chuyển Khai Thác</span>
          </button>
        </div>
      </div>

      {/* Success Alert Banner */}
      {saveSuccessMessage && (
        <div className="p-4 bg-emerald-950/80 border border-emerald-700 rounded-2xl flex items-center justify-between text-xs text-emerald-300 shadow-lg animate-fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0" />
            <span className="font-bold">{saveSuccessMessage}</span>
          </div>
          <button onClick={() => setSaveSuccessMessage(null)} className="text-slate-400 hover:text-white">✕</button>
        </div>
      )}

      {/* Validation Errors Alert Box */}
      {validationErrors.length > 0 && (
        <div className="p-4 bg-rose-950/70 border border-rose-800 rounded-2xl space-y-2 text-xs text-rose-300 animate-fade-in shadow-lg">
          <div className="flex items-center gap-2 font-bold text-rose-200">
            <AlertTriangle className="w-4 h-4 text-rose-400 flex-shrink-0" />
            <span>Vui lòng hoàn thiện các tiêu chuẩn giám định sau trước khi tiếp tục:</span>
          </div>
          <ul className="list-disc list-inside space-y-1 pl-2 text-rose-200">
            {validationErrors.map((err, idx) => (
              <li key={idx}>{err}</li>
            ))}
          </ul>
        </div>
      )}

      {/* Container Information & Standards Header Panel */}
      <div className="p-5 bg-slate-900 border border-slate-800 rounded-3xl space-y-4">
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-4 text-xs">
          <div>
            <span className="text-[10px] text-slate-400 uppercase font-semibold block">Hãng Tàu (Carrier)</span>
            <strong className="text-white font-bold text-sm block mt-0.5">{formData.shippingLine}</strong>
            <span className="text-[10px] text-slate-400 truncate block">{formData.owner}</span>
          </div>

          <div>
            <span className="text-[10px] text-slate-400 uppercase font-semibold block">Kích Cỡ &amp; ISO Code</span>
            <strong className="text-white font-bold text-sm block mt-0.5">{formData.size} {formData.type}</strong>
            <span className="text-[10px] font-mono text-slate-400">ISO: {formData.isoCode}</span>
          </div>

          <div>
            <span className="text-[10px] text-slate-400 uppercase font-semibold block">Tiêu Chuẩn Giám Định</span>
            <select
              value={formData.standard}
              onChange={(e) => setFormData({ ...formData, standard: e.target.value as any })}
              className="mt-1 px-2.5 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-blue-400 font-bold text-xs focus:outline-none focus:border-blue-500 w-full"
            >
              <option value="IICL-6">IICL-6 (Quốc Tế)</option>
              <option value="MCIC">MCIC (Châu Á)</option>
              <option value="MRIC">MRIC (SITC/Wan Hai)</option>
              <option value="CARRIER_CUSTOM">CARRIER_CUSTOM</option>
            </select>
          </div>

          <div>
            <span className="text-[10px] text-slate-400 uppercase font-semibold block">Giám Định Viên (Surveyor)</span>
            <input
              type="text"
              value={formData.surveyor}
              onChange={(e) => setFormData({ ...formData, surveyor: e.target.value })}
              className="mt-1 px-2.5 py-1 bg-slate-950 border border-slate-800 rounded-xl text-white text-xs focus:outline-none w-full"
            />
          </div>

          <div>
            <span className="text-[10px] text-slate-400 uppercase font-semibold block">Thời Điểm Gate-In</span>
            <span className="text-slate-300 font-mono text-xs block mt-1.5">{formData.gateInTime}</span>
          </div>

          <div>
            <span className="text-[10px] text-slate-400 uppercase font-semibold block">Trạng Thái Survey</span>
            <span className="mt-1 inline-block px-2.5 py-0.5 bg-blue-950 text-blue-300 font-bold rounded-lg border border-blue-800 text-[11px]">
              {formData.status}
            </span>
          </div>
        </div>
      </div>

      {/* Grading & Condition Interactive Selector Cards */}
      <div className="space-y-3">
        <h3 className="text-sm font-bold text-white flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>Phân Loại Tình Trạng Vỏ Container (Grading &amp; Condition Classification)*</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Card 1: AV */}
          <div
            onClick={() => setFormData({ ...formData, condition: 'AV' })}
            className={`p-5 rounded-3xl border transition duration-200 cursor-pointer space-y-3 relative ${
              formData.condition === 'AV'
                ? 'bg-emerald-950/40 border-emerald-500 shadow-xl ring-2 ring-emerald-500/20'
                : 'bg-slate-900 border-slate-800 opacity-70 hover:opacity-100'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-xl">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-base font-black text-emerald-300">AV - AVAILABLE</h4>
                  <span className="text-[11px] text-slate-400">Đạt chuẩn &amp; Sẵn sàng cấp</span>
                </div>
              </div>
              <input
                type="radio"
                name="conditionGrade"
                checked={formData.condition === 'AV'}
                onChange={() => setFormData({ ...formData, condition: 'AV' })}
                className="w-4 h-4 text-emerald-500"
              />
            </div>

            <p className="text-xs text-slate-300">
              Vỏ kín nước 100%, sàn sạch, khung kết cấu đạt dung sai tiêu chuẩn IICL-6.
            </p>

            {formData.condition === 'AV' && (
              <div className="pt-3 border-t border-emerald-800/60 space-y-1.5">
                <label className="text-[10px] font-bold text-emerald-400 uppercase">
                  Chọn Phân Hạng Chất Lượng (Quality Grade):
                </label>
                <select
                  value={formData.qualityGrade || 'GRADE_A'}
                  onChange={(e) => setFormData({ ...formData, qualityGrade: e.target.value as any })}
                  className="w-full px-3 py-1.5 bg-slate-950 border border-emerald-700/80 rounded-xl text-emerald-200 text-xs font-bold focus:outline-none"
                >
                  <option value="GRADE_A">Grade A - Hàng Xuất Khẩu Cao Cấp / Điện Tử</option>
                  <option value="FOOD_GRADE">Food Grade - Đóng Nông Sản &amp; Thực Phẩm</option>
                  <option value="GENERAL_CARGO">General Cargo - Bách Hóa Thông Thường</option>
                  <option value="SCRAP_GRADE">Scrap Grade - Phế Liệu &amp; Hàng Nặng</option>
                </select>
              </div>
            )}
          </div>

          {/* Card 2: CL */}
          <div
            onClick={() => setFormData({ ...formData, condition: 'CL' })}
            className={`p-5 rounded-3xl border transition duration-200 cursor-pointer space-y-3 relative ${
              formData.condition === 'CL'
                ? 'bg-amber-950/40 border-amber-500 shadow-xl ring-2 ring-amber-500/20'
                : 'bg-slate-900 border-slate-800 opacity-70 hover:opacity-100'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-amber-500/20 text-amber-400 rounded-xl">
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-base font-black text-amber-300">CL - CLEANING</h4>
                  <span className="text-[11px] text-slate-400">Yêu cầu xịt rửa &amp; Vệ sinh</span>
                </div>
              </div>
              <input
                type="radio"
                name="conditionGrade"
                checked={formData.condition === 'CL'}
                onChange={() => setFormData({ ...formData, condition: 'CL' })}
                className="w-4 h-4 text-amber-500"
              />
            </div>

            <p className="text-xs text-slate-300">
              Kết cấu vỏ tốt nhưng bám dính cặn bẩn, dầu nhớt, mùi hôi, rác dunnage.
            </p>

            {formData.condition === 'CL' && (
              <div className="pt-3 border-t border-amber-800/60 space-y-2 text-xs">
                <div>
                  <label className="text-[10px] font-bold text-amber-400 uppercase block mb-1">
                    Phương Pháp Tẩy Rửa:
                  </label>
                  <select
                    value={formData.cleaningMethod || 'WATER_PRESSURE'}
                    onChange={(e) => setFormData({ ...formData, cleaningMethod: e.target.value as any })}
                    className="w-full px-3 py-1.5 bg-slate-950 border border-amber-700/80 rounded-xl text-amber-200 text-xs font-bold focus:outline-none"
                  >
                    <option value="SWEEPING">Quét dọn &amp; Thu gom rác thải (Sweeping)</option>
                    <option value="WATER_PRESSURE">Xịt nước áp lực cao 200 Bar (Water Wash)</option>
                    <option value="CHEMICAL_WASH">Tẩy rửa hóa chất &amp; Khử trùng (Chemical)</option>
                    <option value="DEODORIZE">Xông nhiệt &amp; Khử mùi tanh hải sản (Deodorize)</option>
                  </select>
                </div>
              </div>
            )}
          </div>

          {/* Card 3: DM */}
          <div
            onClick={() => setFormData({ ...formData, condition: 'DM' })}
            className={`p-5 rounded-3xl border transition duration-200 cursor-pointer space-y-3 relative ${
              formData.condition === 'DM'
                ? 'bg-rose-950/40 border-rose-500 shadow-xl ring-2 ring-rose-500/20'
                : 'bg-slate-900 border-slate-800 opacity-70 hover:opacity-100'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-rose-500/20 text-rose-400 rounded-xl">
                  <Wrench className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-base font-black text-rose-300">DM - DAMAGED</h4>
                  <span className="text-[11px] text-slate-400">Hư hỏng &bull; Chờ sửa chữa</span>
                </div>
              </div>
              <input
                type="radio"
                name="conditionGrade"
                checked={formData.condition === 'DM'}
                onChange={() => setFormData({ ...formData, condition: 'DM' })}
                className="w-4 h-4 text-rose-500"
              />
            </div>

            <p className="text-xs text-slate-300">
              Có vết rách thủng vách, móp dầm, gãy ron hoặc hỏng ván sàn cần sửa chữa.
            </p>

            {formData.condition === 'DM' && (
              <div className="pt-3 border-t border-rose-800/60 flex items-center justify-between text-xs">
                <span className="text-rose-300 font-bold">
                  {formData.damages?.length || 0} mục tổn thất đã ghi
                </span>
                <button
                  type="button"
                  onClick={() => handleOpenAddDamage()}
                  className="px-2.5 py-1 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-lg text-[11px] shadow"
                >
                  + Thêm Lỗi
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Sub-Navigation Tabs - Focused on Fast Code Entry */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveTab('DAMAGES')}
          className={`px-4 py-2.5 text-xs font-bold rounded-xl transition flex items-center gap-2 cursor-pointer whitespace-nowrap ${
            activeTab === 'DAMAGES'
              ? 'bg-rose-600 text-white shadow-lg shadow-rose-600/30'
              : 'bg-slate-900 text-slate-400 hover:text-white'
          }`}
        >
          <Wrench className="w-4 h-4" />
          <span>Nhập &amp; Quản Lý Mã Lỗi Tổn Thất</span>
          <span className="px-2 py-0.5 bg-slate-950/80 rounded-full font-mono text-[10px]">
            {formData.damages?.length || 0}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('CLEANING')}
          className={`px-4 py-2.5 text-xs font-bold rounded-xl transition flex items-center gap-2 cursor-pointer whitespace-nowrap ${
            activeTab === 'CLEANING'
              ? 'bg-amber-600 text-white shadow-lg shadow-amber-600/30'
              : 'bg-slate-900 text-slate-400 hover:text-white'
          }`}
        >
          <Droplets className="w-4 h-4 text-cyan-400" />
          <span>Hạng Mục Vệ Sinh &amp; Bảng Giá</span>
          <span className="px-2 py-0.5 bg-slate-950/80 rounded-full font-mono text-[10px] text-amber-300">
            {formData.cleaningItems?.length || 0}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('CHECKLIST')}
          className={`px-4 py-2.5 text-xs font-bold rounded-xl transition flex items-center gap-2 cursor-pointer whitespace-nowrap ${
            activeTab === 'CHECKLIST'
              ? 'bg-blue-600 text-white shadow-lg'
              : 'bg-slate-900 text-slate-400 hover:text-white'
          }`}
        >
          <ClipboardCheck className="w-4 h-4" />
          <span>Checklist 11 Khu Vực Khảo Sát</span>
        </button>

        <button
          onClick={() => setActiveTab('PHOTOS')}
          className={`px-4 py-2.5 text-xs font-bold rounded-xl transition flex items-center gap-2 cursor-pointer whitespace-nowrap ${
            activeTab === 'PHOTOS'
              ? 'bg-emerald-600 text-white shadow-lg'
              : 'bg-slate-900 text-slate-400 hover:text-white'
          }`}
        >
          <Camera className="w-4 h-4" />
          <span>Hình Ảnh Hiện Trường ({formData.photos?.length || 0})</span>
        </button>
      </div>

      {/* Tab 1: Fast Damage Codes Input & Table */}
      {activeTab === 'DAMAGES' && (
        <div className="space-y-5">
          {/* Quick Direct Code Input Bar */}
          <div className="p-5 bg-slate-900 border border-slate-800 rounded-3xl space-y-4 shadow-xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-rose-600/20 border border-rose-500/30 text-rose-400 rounded-xl">
                  <Zap className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <span>Nhập Nhanh Mã Lỗi Hiện Trường (Fast Damage Code Entry)</span>
                    <span className="px-2 py-0.5 bg-rose-500/20 text-rose-300 font-mono text-[10px] font-bold rounded-full">
                      Surveyor Tool
                    </span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Nhân viên nhập trực tiếp mã vị trí, mã hư hỏng IICL và phương án sửa chữa STS.
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => handleOpenAddDamage()}
                className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold text-xs rounded-xl transition flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-4 h-4 text-rose-400" />
                <span>Mở Form Chi Tiết Đầy Đủ</span>
              </button>
            </div>

            {/* Preset 1-Click Quick Chips */}
            <div className="space-y-1.5">
              <span className="text-[11px] text-slate-400 font-semibold block">
                Phím Tắt Nhanh Các Lỗi Thường Gặp (1-Click Presets):
              </span>
              <div className="flex flex-wrap gap-2">
                {[
                  { loc: 'RIGHT_W', dmg: 'BENT', rep: 'RP_STRAIGHT', label: 'Cong vách phải (BENT)', sev: 'MEDIUM' as const },
                  { loc: 'LEFT_W', dmg: 'CUT', rep: 'RP_PATCH_S', label: 'Rách vách trái (CUT)', sev: 'HIGH' as const },
                  { loc: 'ROOF', dmg: 'HOLE', rep: 'RP_PATCH_S', label: 'Thủng nóc (HOLE)', sev: 'CRITICAL' as const },
                  { loc: 'FLOOR', dmg: 'FLOOR_GOUGE', rep: 'RP_INSERT', label: 'Vỡ xước ván sàn (GOUGE)', sev: 'HIGH' as const },
                  { loc: 'DOOR_R', dmg: 'DOOR_SEAL_TEAR', rep: 'RP_DOOR_SEAL', label: 'Rách gioăng cửa (SEAL)', sev: 'MEDIUM' as const },
                  { loc: 'FRONT_W', dmg: 'DENT', rep: 'RP_STRAIGHT', label: 'Móp vách trước (DENT)', sev: 'LOW' as const },
                  { loc: 'CORNER_POST', dmg: 'CRACKED', rep: 'RP_WELD', label: 'Nứt gù/cột góc (CRACK)', sev: 'CRITICAL' as const },
                  { loc: 'UNDERSTRUCTURE', dmg: 'CROSSMEMBER_BENT', rep: 'RP_STRAIGHT', label: 'Cong dầm đáy (X-MEMBER)', sev: 'HIGH' as const }
                ].map((preset, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setQuickLocation(preset.loc);
                      setQuickDamageCode(preset.dmg);
                      setQuickRepairCode(preset.rep);
                      setQuickSeverity(preset.sev);
                    }}
                    className="px-2.5 py-1 bg-slate-950 hover:bg-rose-950/60 text-slate-300 hover:text-rose-200 border border-slate-800 hover:border-rose-700/70 rounded-lg text-[11px] font-medium transition cursor-pointer flex items-center gap-1"
                  >
                    <Tag className="w-3 h-3 text-rose-400" />
                    <span>{preset.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Inline Fast Input Form */}
            <form onSubmit={handleQuickAddDamage} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3 pt-2">
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                  1. Vị Trí (Location)*
                </label>
                <select
                  value={quickLocation}
                  onChange={(e) => setQuickLocation(e.target.value)}
                  className="w-full px-2.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-slate-200 font-medium text-xs focus:outline-none focus:border-rose-500"
                >
                  {locations.map((loc) => (
                    <option key={loc.id} value={loc.code}>
                      {loc.code} - {loc.vietnameseName}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                  2. Mã Lỗi (Damage)*
                </label>
                <select
                  value={quickDamageCode}
                  onChange={(e) => setQuickDamageCode(e.target.value)}
                  className="w-full px-2.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-rose-300 font-mono font-bold text-xs focus:outline-none focus:border-rose-500"
                >
                  {damageCodes.map((dmg) => (
                    <option key={dmg.id} value={dmg.code}>
                      {dmg.code} &bull; {dmg.vietnameseName}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                  3. Mã Sửa (Repair/STS)*
                </label>
                <select
                  value={quickRepairCode}
                  onChange={(e) => setQuickRepairCode(e.target.value)}
                  className="w-full px-2.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-blue-300 font-mono font-bold text-xs focus:outline-none focus:border-rose-500"
                >
                  {repairCodes.map((rep) => (
                    <option key={rep.id} value={rep.repairCode}>
                      {rep.repairCode} &bull; {rep.vietnameseName}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                  4. Mức Độ (Severity)
                </label>
                <select
                  value={quickSeverity}
                  onChange={(e) => setQuickSeverity(e.target.value as any)}
                  className="w-full px-2.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-slate-200 font-medium text-xs focus:outline-none focus:border-rose-500"
                >
                  <option value="LOW">LOW (Nhẹ)</option>
                  <option value="MEDIUM">MEDIUM (Vừa)</option>
                  <option value="HIGH">HIGH (Nặng)</option>
                  <option value="CRITICAL">CRITICAL (Thủng/Nát)</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                  5. Kích Thước (LxW mm)
                </label>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    value={quickLength}
                    onChange={(e) => setQuickLength(e.target.value)}
                    placeholder="Dài"
                    className="w-1/2 px-2 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white font-mono text-xs focus:outline-none"
                  />
                  <span className="text-slate-500">x</span>
                  <input
                    type="number"
                    value={quickWidth}
                    onChange={(e) => setQuickWidth(e.target.value)}
                    placeholder="Rộng"
                    className="w-1/2 px-2 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white font-mono text-xs focus:outline-none"
                  />
                </div>
              </div>

              <div className="flex items-end">
                <button
                  type="submit"
                  className="w-full py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-rose-600/30 transition flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>+ Thêm Mã Lỗi</span>
                </button>
              </div>
            </form>
          </div>

          {/* Damages List Table */}
          <DamageListTable
            damages={formData.damages || []}
            onAddDamage={() => handleOpenAddDamage()}
            onEditDamage={(d) => {
              setEditingDamage(d);
              setIsDamageModalOpen(true);
            }}
            onDeleteDamage={handleDeleteDamage}
            onViewPhoto={(url, caption) => setPhotoViewerUrl({ url, caption })}
          />
        </div>
      )}

      {/* Tab 2: Cleaning Tariffs & Specifications Management */}
      {activeTab === 'CLEANING' && (
        <div className="space-y-5">
          {/* Header Summary Card */}
          <div className="p-5 bg-gradient-to-r from-amber-950/40 via-slate-900 to-slate-900 border border-amber-800/40 rounded-3xl space-y-4 shadow-xl">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded-2xl">
                  <Droplets className="w-6 h-6 text-cyan-400" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <span>Hạng Mục Vệ Sinh &amp; Biểu Phí (Cleaning Services &amp; Tariffs)</span>
                    <span className="px-2 py-0.5 bg-amber-500/20 text-amber-300 font-mono text-xs font-bold rounded-lg">
                      {formData.containerNo}
                    </span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Áp dụng đơn giá theo quy cách <strong className="text-amber-400">{formData.sizeType || `${formData.size}${formData.type}`}</strong> &bull; Hãng tàu <strong className="text-sky-300">{formData.shippingLine}</strong>
                  </p>
                </div>
              </div>

              {/* Financial Quick Metrics */}
              <div className="flex items-center gap-3 bg-slate-950/80 p-2.5 rounded-2xl border border-slate-800 text-xs">
                <div>
                  <span className="text-[10px] text-slate-500 block uppercase font-bold">Chưa VAT</span>
                  <span className="font-mono font-bold text-amber-400 text-sm">
                    {(formData.cleaningTotalCost || formData.cleaningEstimatedCost || 0).toLocaleString('vi-VN')} đ
                  </span>
                </div>
                <div className="h-6 w-px bg-slate-800" />
                <div>
                  <span className="text-[10px] text-slate-500 block uppercase font-bold">VAT (8%)</span>
                  <span className="font-mono font-bold text-slate-300 text-sm">
                    {Math.round((formData.cleaningTotalCost || formData.cleaningEstimatedCost || 0) * 0.08).toLocaleString('vi-VN')} đ
                  </span>
                </div>
                <div className="h-6 w-px bg-slate-800" />
                <div>
                  <span className="text-[10px] text-slate-500 block uppercase font-bold">Tổng Thanh Toán</span>
                  <span className="font-mono font-black text-emerald-400 text-base">
                    {Math.round((formData.cleaningTotalCost || formData.cleaningEstimatedCost || 0) * 1.08).toLocaleString('vi-VN')} đ
                  </span>
                </div>
              </div>
            </div>

            {/* Quick Add from Master Tariffs Grid */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                  <Plus className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Chọn Thêm Dịch Vụ Vệ Sinh Từ Master Tariff ({INITIAL_CLEANING_TARIFFS.length} dịch vụ tiêu chuẩn)</span>
                </span>
                <span className="text-[11px] text-slate-400">
                  Bấm vào thẻ bên dưới để thêm ngay vào phiếu giám định:
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2.5">
                {INITIAL_CLEANING_TARIFFS.map((tariff) => {
                  const unitPrice = getTariffCost(tariff);
                  const isAlreadyAdded = (formData.cleaningItems || []).some(
                    (item) => item.cleaningCode === tariff.cleaningCode
                  );
                  return (
                    <button
                      key={tariff.id}
                      type="button"
                      onClick={() => handleAddCleaningItem(tariff)}
                      className={`p-2.5 rounded-xl border text-left transition cursor-pointer flex flex-col justify-between ${
                        isAlreadyAdded
                          ? 'bg-amber-950/30 border-amber-500/40 text-amber-200'
                          : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 text-slate-300'
                      }`}
                    >
                      <div className="space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="font-mono font-bold text-[10px] text-cyan-400">
                            {tariff.cleaningCode}
                          </span>
                          {isAlreadyAdded && (
                            <span className="px-1.5 py-0.2 bg-amber-500/20 text-amber-300 font-bold rounded text-[9px]">
                              ✓ Đã có
                            </span>
                          )}
                        </div>
                        <div className="text-xs font-semibold text-white line-clamp-1">
                          {tariff.vietnameseName || tariff.name}
                        </div>
                      </div>
                      <div className="pt-2 mt-1 border-t border-slate-800/60 flex items-center justify-between">
                        <span className="text-[10px] text-slate-400">{tariff.estimatedDurationMin}p</span>
                        <span className="font-mono font-bold text-amber-400 text-xs">
                          {unitPrice.toLocaleString('vi-VN')} đ
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Cleaning Items List Table */}
          <div className="p-5 bg-slate-900 border border-slate-800 rounded-3xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <Receipt className="w-4 h-4 text-amber-400" />
                <span>Danh Sách Dịch Vụ Vệ Sinh Được Yêu Cầu ({formData.cleaningItems?.length || 0})</span>
              </h4>
            </div>

            {(!formData.cleaningItems || formData.cleaningItems.length === 0) ? (
              <div className="py-8 text-center border-2 border-dashed border-slate-800 rounded-2xl space-y-2">
                <Droplets className="w-8 h-8 text-slate-600 mx-auto" />
                <p className="text-xs font-bold text-slate-300">Chưa có dịch vụ vệ sinh nào được chọn</p>
                <p className="text-[11px] text-slate-500">
                  Chọn một hoặc nhiều dịch vụ từ bảng biểu phí phía trên để áp dụng giá tự động.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400 font-semibold uppercase text-[11px]">
                      <th className="py-3 px-3">Mã Dịch Vụ</th>
                      <th className="py-3 px-3">Tên Phương Pháp Vệ Sinh</th>
                      <th className="py-3 px-3">Hóa Chất</th>
                      <th className="py-3 px-3 text-center">Bên Trả Phí</th>
                      <th className="py-3 px-3 text-right">Đơn Giá</th>
                      <th className="py-3 px-3 text-right">Thành Tiền</th>
                      <th className="py-3 px-3 text-center">Trạng Thái</th>
                      <th className="py-3 px-3 text-right">Thao Tác</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 text-slate-300">
                    {formData.cleaningItems.map((item) => (
                      <tr key={item.id} className="hover:bg-slate-800/30 transition">
                        <td className="py-3 px-3 font-mono font-bold text-cyan-400">
                          {item.cleaningCode}
                        </td>
                        <td className="py-3 px-3">
                          <div className="font-semibold text-white">{item.cleaningName}</div>
                          {item.notes && <div className="text-[10px] text-slate-400">{item.notes}</div>}
                        </td>
                        <td className="py-3 px-3">
                          {item.chemicalRequired ? (
                            <span className="px-2 py-0.5 bg-purple-500/20 text-purple-300 rounded font-semibold text-[10px]">
                              {item.chemicalName || 'Hóa chất kiềm'}
                            </span>
                          ) : (
                            <span className="text-slate-500 text-[10px]">-</span>
                          )}
                        </td>
                        <td className="py-3 px-3 text-center">
                          <div className="inline-flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
                            {[
                              { id: 'U', label: 'User' },
                              { id: 'O', label: 'Owner' },
                              { id: 'T', label: 'Truck' }
                            ].map((p) => (
                              <button
                                key={p.id}
                                type="button"
                                onClick={() => handleUpdateCleaningParty(item.id, p.id as any)}
                                className={`px-2 py-0.5 rounded text-[10px] font-bold transition cursor-pointer ${
                                  item.responsibleParty === p.id
                                    ? 'bg-amber-500 text-slate-950 font-black'
                                    : 'text-slate-400 hover:text-white'
                                }`}
                              >
                                {p.label}
                              </button>
                            ))}
                          </div>
                        </td>
                        <td className="py-3 px-3 text-right font-mono font-bold text-slate-300">
                          {(item.unitPrice || 0).toLocaleString('vi-VN')} đ
                        </td>
                        <td className="py-3 px-3 text-right font-mono font-bold text-amber-400">
                          {(item.totalPrice || 0).toLocaleString('vi-VN')} đ
                        </td>
                        <td className="py-3 px-3 text-center">
                          <button
                            type="button"
                            onClick={() => handleToggleCleaningStatus(item.id)}
                            className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition cursor-pointer ${
                              item.status === 'COMPLETED'
                                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                                : item.status === 'IN_PROGRESS'
                                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                                : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                            }`}
                          >
                            {item.status === 'COMPLETED'
                              ? '✓ Đã Rửa Xong'
                              : item.status === 'IN_PROGRESS'
                              ? '⏳ Đang Rửa'
                              : 'Chờ Xử Lý'}
                          </button>
                        </td>
                        <td className="py-3 px-3 text-right">
                          <button
                            type="button"
                            onClick={() => handleRemoveCleaningItem(item.id)}
                            className="p-1.5 text-slate-400 hover:text-rose-400 rounded-lg hover:bg-slate-800 transition cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab 4: Photos Management */}
      {activeTab === 'PHOTOS' && (
        <div className="p-5 bg-slate-900 border border-slate-800 rounded-3xl space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Camera className="w-4 h-4 text-emerald-400" />
                <span>Quản Lý Hình Ảnh Giám Định Hiện Trường (Survey Photos)</span>
              </h3>
              <p className="text-xs text-slate-400">
                Bắt buộc tối thiểu 01 Ảnh Toàn Cảnh (Overview) và các ảnh chụp chi tiết tổn thất.
              </p>
            </div>

            {/* Quick Upload Buttons */}
            <div className="flex items-center gap-2 flex-wrap">
              <button
                type="button"
                onClick={handleAddStandardPhotoSet}
                className="px-3 py-1.5 bg-emerald-600/30 hover:bg-emerald-600/40 text-emerald-300 border border-emerald-500/40 font-bold text-xs rounded-xl transition flex items-center gap-1 cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                <span>+ Bộ Ảnh Chuẩn (Toàn cảnh + Cận cảnh)</span>
              </button>

              <button
                type="button"
                onClick={() => handleAddPhoto('OVERVIEW')}
                className="px-3 py-1.5 bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border border-blue-500/30 font-bold text-xs rounded-xl transition flex items-center gap-1 cursor-pointer"
              >
                <Camera className="w-3.5 h-3.5" />
                <span>+ Ảnh Toàn Cảnh</span>
              </button>

              <button
                type="button"
                onClick={() => handleAddPhoto('DETAIL')}
                className="px-3 py-1.5 bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/30 font-bold text-xs rounded-xl transition flex items-center gap-1 cursor-pointer"
              >
                <Camera className="w-3.5 h-3.5" />
                <span>+ Ảnh Chi Tiết Lỗi</span>
              </button>
            </div>
          </div>

          {/* Photo Cards Grid */}
          {(!formData.photos || formData.photos.length === 0) ? (
            <div className="p-8 bg-slate-950/60 border border-slate-800 rounded-2xl text-center space-y-2">
              <Camera className="w-8 h-8 text-slate-600 mx-auto" />
              <h4 className="text-sm font-bold text-slate-300">Chưa có hình ảnh nào được tải lên</h4>
              <p className="text-xs text-slate-500">
                Vui lòng nhấn "+ Bộ Ảnh Chuẩn" hoặc "+ Ảnh Toàn Cảnh" để hoàn tất yêu cầu kiểm định.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {formData.photos.map((photo) => (
                <div
                  key={photo.id}
                  className="bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden group space-y-2 p-3 shadow-lg"
                >
                  <div className="relative aspect-video rounded-xl overflow-hidden bg-slate-900">
                    <img
                      src={photo.url}
                      alt={photo.caption}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                    <span className="absolute top-2 left-2 px-2 py-0.5 bg-slate-950/90 text-white font-mono text-[9px] rounded font-bold">
                      {photo.type}
                    </span>
                    <span className="absolute bottom-2 right-2 px-2 py-0.5 bg-black/85 text-amber-300 font-mono text-[9px] rounded font-bold flex items-center gap-1">
                      <Clock className="w-2.5 h-2.5" />
                      {photo.uploadedAt || '2026-08-14 09:00'}
                    </span>
                  </div>

                  <div className="space-y-1 text-xs">
                    <p className="font-semibold text-slate-200 line-clamp-1">{photo.caption}</p>
                    <div className="flex items-center justify-between text-[10px] text-slate-400">
                      <span>{photo.surveyor}</span>
                      <span>{photo.uploadedAt}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-slate-800">
                    <button
                      type="button"
                      onClick={() => setPhotoViewerUrl({ url: photo.url, caption: photo.caption })}
                      className="text-xs text-blue-400 hover:text-blue-300 font-semibold flex items-center gap-1 cursor-pointer"
                    >
                      <Maximize2 className="w-3.5 h-3.5" /> Xem lớn
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDeletePhoto(photo.id)}
                      className="text-xs text-slate-400 hover:text-rose-400 transition cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* General Remarks / Notes */}
      <div className="p-5 bg-slate-900 border border-slate-800 rounded-3xl space-y-2">
        <label className="block text-xs font-bold text-white uppercase">
          Ghi Chú Tổng Quan Của Surveyor &amp; Chỉ Đạo Khai Thác Bãi
        </label>
        <textarea
          rows={2}
          value={formData.remarks || ''}
          onChange={(e) => setFormData({ ...formData, remarks: e.target.value })}
          placeholder="Nhập ghi chú tình trạng đặc biệt, yêu cầu chuyển bãi sửa chữa EMR hoặc lưu ý khi cấp vỏ cho khách..."
          className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-2xl text-white text-xs focus:outline-none resize-none"
        />
      </div>

      {/* Bottom Floating Control Bar */}
      <div className="p-4 bg-slate-900/90 backdrop-blur-md border border-slate-800 rounded-3xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-2xl sticky bottom-4 z-40">
        <div className="flex items-center gap-2 text-xs text-slate-400">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
          <span>Chế độ kiểm định trực tiếp tại bãi &bull; Surveyor: <strong className="text-white">{formData.surveyor}</strong></span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onBack}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-xl cursor-pointer"
          >
            Đóng Lại
          </button>
          <button
            onClick={handleSaveDraft}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-100 text-xs font-bold rounded-xl border border-slate-700 transition cursor-pointer"
          >
            Lưu Tạm
          </button>
          <button
            onClick={handleCompleteSurvey}
            className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-xl shadow-lg transition flex items-center gap-1.5 cursor-pointer"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Hoàn Tất Giám Định</span>
          </button>
          <button
            onClick={handleIssueEEIR}
            className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl shadow-lg shadow-emerald-600/20 transition flex items-center gap-1.5 cursor-pointer"
          >
            <FileText className="w-4 h-4" />
            <span>Phát Hành e-EIR</span>
          </button>
        </div>
      </div>

      {/* Damage Add/Edit Modal */}
      <DamageFormModal
        isOpen={isDamageModalOpen}
        onClose={() => setIsDamageModalOpen(false)}
        onSave={handleSaveDamage}
        initialData={editingDamage}
        defaultLocationCode={selectedLocationCode}
        defaultLocationName={selectedLocationName}
        locations={locations}
        damageCodes={damageCodes}
        repairCodes={repairCodes}
        currentUser={currentUser}
      />

      {/* Image Lightbox Viewer Modal */}
      {photoViewerUrl && (
        <div className="fixed inset-0 bg-slate-950/90 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 max-w-3xl w-full space-y-3 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <h4 className="text-sm font-bold text-white">{photoViewerUrl.caption}</h4>
              <button
                onClick={() => setPhotoViewerUrl(null)}
                className="text-slate-400 hover:text-white font-bold p-1"
              >
                ✕
              </button>
            </div>
            <div className="bg-slate-950 rounded-2xl max-h-[70vh] flex items-center justify-center overflow-hidden">
              <img
                src={photoViewerUrl.url}
                alt={photoViewerUrl.caption}
                referrerPolicy="no-referrer"
                className="max-h-[68vh] object-contain select-none"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
