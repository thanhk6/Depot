import React from 'react';
import {
  Smartphone,
  Settings,
  Radio,
  FileCode,
  Receipt,
  MessageSquare,
  Activity,
  Sparkles,
  Layers,
  Send
} from 'lucide-react';

export type ZaloSubTab =
  | 'overview'
  | 'simulator'
  | 'templates'
  | 'settings'
  | 'logs';

interface ZaloHeaderProps {
  currentTab: ZaloSubTab;
  onSelectTab: (tab: ZaloSubTab) => void;
}

export const ZaloHeader: React.FC<ZaloHeaderProps> = ({ currentTab, onSelectTab }) => {
  const tabs: { id: ZaloSubTab; label: string; icon: React.ReactNode; badge?: string }[] = [
    {
      id: 'overview',
      label: 'Tổng Quan Zalo',
      icon: <Activity className="w-4 h-4 text-sky-400" />,
      badge: 'Online'
    },
    {
      id: 'simulator',
      label: 'Zalo Simulator & Chat',
      icon: <Smartphone className="w-4 h-4 text-emerald-400" />,
      badge: '2 Chiều'
    },
    {
      id: 'templates',
      label: 'Mẫu ZNS & Zalo OA',
      icon: <FileCode className="w-4 h-4 text-amber-400" />,
      badge: '12 Mẫu'
    },
    {
      id: 'settings',
      label: 'Cấu Hình OA & Token',
      icon: <Settings className="w-4 h-4 text-cyan-400" />
    },
    {
      id: 'logs',
      label: 'Nhật Ký Webhook & API',
      icon: <Receipt className="w-4 h-4 text-purple-400" />
    }
  ];

  return (
    <div className="bg-[#0b132b] border border-slate-800 rounded-3xl p-4 sm:p-5 shadow-2xl space-y-4">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-blue-600 to-sky-400 flex items-center justify-center text-white shadow-lg shadow-blue-500/20">
            <Radio className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-black text-white tracking-tight">
                ZALO GATEWAY & OFFICIAL ACCOUNT (OA)
              </h1>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-950 text-emerald-300 border border-emerald-700">
                ACTIVE GATEWAY
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Hệ thống kết nối Zalo OA, phát tin ZNS tự động, quản lý tương tác 2 chiều và mô phỏng phản hồi nghiệp vụ
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center gap-2 text-xs">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <span className="text-slate-300 font-medium">OA ID: <strong className="text-sky-400 font-mono">182736455241</strong></span>
          </div>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 border-t border-slate-800/80 pt-3">
        {tabs.map((tab) => {
          const isActive = currentTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onSelectTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-bold transition whitespace-nowrap cursor-pointer select-none ${
                isActive
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30'
                  : 'bg-slate-900/90 text-slate-400 hover:text-slate-200 hover:bg-slate-800/90 border border-slate-800'
              }`}
            >
              {tab.icon}
              <span>{tab.label}</span>
              {tab.badge && (
                <span
                  className={`px-1.5 py-0.2 rounded-full text-[10px] font-extrabold ${
                    isActive
                      ? 'bg-white/20 text-white'
                      : 'bg-slate-800 text-slate-300 border border-slate-700'
                  }`}
                >
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};
