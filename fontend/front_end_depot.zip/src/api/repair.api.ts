import apiClient from './axios';
import { ApiResponse } from '../types/common';
import { RepairWorkOrder } from '../types/container';

export const repairApi = {
  assignWorkOrder: async (jobId: string, team: string, workers: string[], materials: any[]) => {
    const res = await apiClient.post<ApiResponse<RepairWorkOrder>>(`/depot/jobs/${jobId}/repair/assign`, { team, workers, materials });
    return res.data;
  },
  completeWorkOrder: async (jobId: string, photos: any[]) => {
    const res = await apiClient.post<ApiResponse<RepairWorkOrder>>(`/depot/jobs/${jobId}/repair/complete`, { photos });
    return res.data;
  },
};
