import React, { useState, useMemo } from 'react';
import {
  LoLoTariffItem,
  StorageTariffRule,
  INITIAL_LOLO_TARIFFS,
  INITIAL_STORAGE_TARIFFS
} from '../mockTariffData';
import {
  Receipt,
  Truck,
  Layers,
  Calculator,
  Search,
  Filter,
  Plus,
  Edit2,
  Trash2,
  Download,
  Upload,
  RefreshCw,
  Clock,
  Zap,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Building2,
  Calendar,
  Percent,
  SlidersHorizontal,
  ChevronRight,
  ShieldCheck,
  Container as ContainerIcon,
  Sparkles,
  Info,
  DollarSign,
  ArrowUpRight,
  Printer,
  Copy,
  Check,
  X
} from 'lucide-react';

export interface LiftOnLiftOffAndStorageMasterProps {
  onUpdateTariffs?: (lolo: LoLoTariffItem[], storage: StorageTariffRule[]) => void;
}

export const LiftOnLiftOffAndStorageMaster: React.FC<LiftOnLiftOffAndStorageMasterProps> = ({
  onUpdateTariffs
}) => {
  // Main Data States
  const [loloTariffs, setLoloTariffs] = useState<LoLoTariffItem[]>(INITIAL_LOLO_TARIFFS);
  const [storageRules, setStorageRules] = useState<StorageTariffRule[]>(INITIAL_STORAGE_TARIFFS);

  // Active Sub-Tab
  const [activeTab, setActiveTab] = useState<'LOLO' | 'STORAGE' | 'CALCULATOR'>('LOLO');

  // Filters & Search
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [loloCategoryFilter, setLoloCategoryFilter] = useState<string>('ALL');
  const [shippingLineFilter, setShippingLineFilter] = useState<string>('ALL');

  // LoLo Modal State
  const [isLoloModalOpen, setIsLoloModalOpen] = useState<boolean>(false);
  const [editingLolo, setEditingLolo] = useState<LoLoTariffItem | null>(null);
  const [loloForm, setLoloForm] = useState<Partial<LoLoTariffItem>>({
    tariffCode: '',
    serviceCategory: 'LIFT_EMPTY',
    nameVi: '',
    nameEn: '',
    unit: 'Lần / Cont',
    price20GP: 280000,
    price40GP_HC: 420000,
    price45HC: 500000,
    price20RF: 350000,
    price40RH: 520000,
    priceSpecial: 650000,
    vatPercent: 8,
    currency: 'VND',
    description: '',
    applicableShift: 'ALL',
    status: 'ACTIVE'
  });

  // Storage Modal State
  const [isStorageModalOpen, setIsStorageModalOpen] = useState<boolean>(false);
  const [editingStorage, setEditingStorage] = useState<StorageTariffRule | null>(null);
  const [storageForm, setStorageForm] = useState<Partial<StorageTariffRule>>({
    ruleCode: '',
    shippingLineCode: 'ALL',
    shippingLineName: 'Áp dụng chung',
    containerTypeCategory: 'DRY_STANDARD',
    defaultFreeDays: 5,
    calculationUnit: 'VND/Cont/Day',
    vatPercent: 8,
    status: 'ACTIVE',
    notes: '',
    tiers: [
      { tierName: 'Bậc 1 (Free Time)', fromDay: 1, toDay: 5, price20Dry: 0, price40Dry: 0, price45Dry: 0, price20Reefer: 0, price40Reefer: 0, priceSpecial: 0 },
      { tierName: 'Bậc 2 (Lưu bãi ngắn)', fromDay: 6, toDay: 15, price20Dry: 35000, price40Dry: 60000, price45Dry: 75000, price20Reefer: 70000, price40Reefer: 120000, priceSpecial: 110000 },
      { tierName: 'Bậc 3 (Lưu bãi dài ngày)', fromDay: 16, toDay: null, price20Dry: 65000, price40Dry: 110000, price45Dry: 135000, price20Reefer: 130000, price40Reefer: 220000, priceSpecial: 180000 }
    ]
  });

  // Bulk Price Adjust Modal
  const [isBulkAdjustOpen, setIsBulkAdjustOpen] = useState<boolean>(false);
  const [bulkPercent, setBulkPercent] = useState<number>(5);
  const [bulkTarget, setBulkTarget] = useState<'LOLO' | 'STORAGE'>('LOLO');

  // Calculator State
  const [calcContSize, setCalcContSize] = useState<'20GP' | '40GP_HC' | '45HC' | '20RF' | '40RH' | 'SPECIAL'>('20GP');
  const [calcLoloAction, setCalcLoloAction] = useState<string>('LOLO_MT_NORMAL');
  const [calcStorageRule, setCalcStorageRule] = useState<string>('STOR_DRY_STANDARD');
  const [calcStorageDays, setCalcStorageDays] = useState<number>(10);
  const [calcNightShift, setCalcNightShift] = useState<boolean>(false);

  // Currency helper
  const formatVND = (amount: number) => {
    return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(amount);
  };

  // Filtered LoLo Items
  const filteredLoloTariffs = useMemo(() => {
    return loloTariffs.filter((item) => {
      const matchSearch =
        item.tariffCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.nameVi.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.nameEn.toLowerCase().includes(searchTerm.toLowerCase());
      const matchCategory = loloCategoryFilter === 'ALL' || item.serviceCategory === loloCategoryFilter;
      return matchSearch && matchCategory;
    });
  }, [loloTariffs, searchTerm, loloCategoryFilter]);

  // Filtered Storage Rules
  const filteredStorageRules = useMemo(() => {
    return storageRules.filter((rule) => {
      const matchSearch =
        rule.ruleCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
        rule.shippingLineName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        rule.notes.toLowerCase().includes(searchTerm.toLowerCase());
      const matchLine = shippingLineFilter === 'ALL' || rule.shippingLineCode === shippingLineFilter;
      return matchSearch && matchLine;
    });
  }, [storageRules, searchTerm, shippingLineFilter]);

  // Save LoLo Handlers
  const handleSaveLolo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loloForm.tariffCode || !loloForm.nameVi) {
      alert('Vui lòng nhập Mã biểu cước và Tên dịch vụ nâng hạ');
      return;
    }

    if (editingLolo) {
      const updated = loloTariffs.map((item) =>
        item.id === editingLolo.id
          ? {
              ...item,
              ...loloForm,
              updatedAt: new Date().toISOString().substring(0, 10)
            } as LoLoTariffItem
          : item
      );
      setLoloTariffs(updated);
      onUpdateTariffs?.(updated, storageRules);
    } else {
      const newItem: LoLoTariffItem = {
        id: `LOLO-${Date.now().toString().slice(-4)}`,
        tariffCode: loloForm.tariffCode || `LOLO_${Date.now().toString().slice(-3)}`,
        serviceCategory: loloForm.serviceCategory || 'LIFT_EMPTY',
        nameVi: loloForm.nameVi || '',
        nameEn: loloForm.nameEn || '',
        unit: loloForm.unit || 'Lần / Cont',
        price20GP: Number(loloForm.price20GP) || 0,
        price40GP_HC: Number(loloForm.price40GP_HC) || 0,
        price45HC: Number(loloForm.price45HC) || 0,
        price20RF: Number(loloForm.price20RF) || 0,
        price40RH: Number(loloForm.price40RH) || 0,
        priceSpecial: Number(loloForm.priceSpecial) || 0,
        vatPercent: Number(loloForm.vatPercent) || 8,
        currency: 'VND',
        description: loloForm.description || '',
        applicableShift: loloForm.applicableShift || 'ALL',
        status: loloForm.status || 'ACTIVE',
        updatedAt: new Date().toISOString().substring(0, 10)
      };
      const updated = [newItem, ...loloTariffs];
      setLoloTariffs(updated);
      onUpdateTariffs?.(updated, storageRules);
    }

    setIsLoloModalOpen(false);
    setEditingLolo(null);
  };

  const handleDeleteLolo = (id: string) => {
    if (confirm('Bạn có chắc chắn muốn xóa hạng mục cước nâng hạ này?')) {
      const updated = loloTariffs.filter((t) => t.id !== id);
      setLoloTariffs(updated);
      onUpdateTariffs?.(updated, storageRules);
    }
  };

  const handleOpenEditLolo = (item: LoLoTariffItem) => {
    setEditingLolo(item);
    setLoloForm({ ...item });
    setIsLoloModalOpen(true);
  };

  const handleOpenCreateLolo = () => {
    setEditingLolo(null);
    setLoloForm({
      tariffCode: `LOLO_${Math.floor(100 + Math.random() * 900)}`,
      serviceCategory: 'LIFT_EMPTY',
      nameVi: '',
      nameEn: '',
      unit: 'Lần / Cont',
      price20GP: 280000,
      price40GP_HC: 420000,
      price45HC: 500000,
      price20RF: 350000,
      price40RH: 520000,
      priceSpecial: 650000,
      vatPercent: 8,
      currency: 'VND',
      description: '',
      applicableShift: 'ALL',
      status: 'ACTIVE'
    });
    setIsLoloModalOpen(true);
  };

  // Bulk price adjustment
  const handleApplyBulkAdjust = () => {
    const multiplier = 1 + bulkPercent / 100;
    if (bulkTarget === 'LOLO') {
      const updated = loloTariffs.map((item) => ({
        ...item,
        price20GP: Math.round((item.price20GP * multiplier) / 1000) * 1000,
        price40GP_HC: Math.round((item.price40GP_HC * multiplier) / 1000) * 1000,
        price45HC: Math.round((item.price45HC * multiplier) / 1000) * 1000,
        price20RF: Math.round((item.price20RF * multiplier) / 1000) * 1000,
        price40RH: Math.round((item.price40RH * multiplier) / 1000) * 1000,
        priceSpecial: Math.round((item.priceSpecial * multiplier) / 1000) * 1000,
        updatedAt: new Date().toISOString().substring(0, 10)
      }));
      setLoloTariffs(updated);
      onUpdateTariffs?.(updated, storageRules);
      alert(`Đã cập nhật ${bulkPercent > 0 ? 'tăng' : 'giảm'} ${Math.abs(bulkPercent)}% toàn bộ biểu cước nâng hạ!`);
    } else {
      const updated = storageRules.map((rule) => ({
        ...rule,
        tiers: rule.tiers.map((t) => ({
          ...t,
          price20Dry: Math.round((t.price20Dry * multiplier) / 1000) * 1000,
          price40Dry: Math.round((t.price40Dry * multiplier) / 1000) * 1000,
          price45Dry: Math.round((t.price45Dry * multiplier) / 1000) * 1000,
          price20Reefer: Math.round((t.price20Reefer * multiplier) / 1000) * 1000,
          price40Reefer: Math.round((t.price40Reefer * multiplier) / 1000) * 1000,
          priceSpecial: Math.round((t.priceSpecial * multiplier) / 1000) * 1000
        })),
        updatedAt: new Date().toISOString().substring(0, 10)
      }));
      setStorageRules(updated);
      onUpdateTariffs?.(loloTariffs, updated);
      alert(`Đã cập nhật ${bulkPercent > 0 ? 'tăng' : 'giảm'} ${Math.abs(bulkPercent)}% toàn bộ biểu cước lưu bãi!`);
    }
    setIsBulkAdjustOpen(false);
  };

  // Calculator Logic
  const calculationResult = useMemo(() => {
    // 1. LoLo Cost
    const selectedLolo = loloTariffs.find((t) => t.tariffCode === calcLoloAction) || loloTariffs[0];
    let loloBasePrice = 0;
    if (calcContSize === '20GP') loloBasePrice = selectedLolo.price20GP;
    else if (calcContSize === '40GP_HC') loloBasePrice = selectedLolo.price40GP_HC;
    else if (calcContSize === '45HC') loloBasePrice = selectedLolo.price45HC;
    else if (calcContSize === '20RF') loloBasePrice = selectedLolo.price20RF;
    else if (calcContSize === '40RH') loloBasePrice = selectedLolo.price40RH;
    else loloBasePrice = selectedLolo.priceSpecial;

    // Night surcharge if any
    let nightSurcharge = 0;
    if (calcNightShift) {
      const nightTariff = loloTariffs.find((t) => t.applicableShift === 'NIGHT_SURCHARGE');
      if (nightTariff) {
        if (calcContSize === '20GP') nightSurcharge = nightTariff.price20GP;
        else if (calcContSize === '40GP_HC') nightSurcharge = nightTariff.price40GP_HC;
        else if (calcContSize === '45HC') nightSurcharge = nightTariff.price45HC;
        else if (calcContSize === '20RF') nightSurcharge = nightTariff.price20RF;
        else if (calcContSize === '40RH') nightSurcharge = nightTariff.price40RH;
        else nightSurcharge = nightTariff.priceSpecial;
      } else {
        nightSurcharge = loloBasePrice * 0.25;
      }
    }

    const totalLoloCost = loloBasePrice + nightSurcharge;

    // 2. Storage Calculation Tier-by-Tier
    const selectedStorage = storageRules.find((r) => r.ruleCode === calcStorageRule) || storageRules[0];
    const isReefer = calcContSize === '20RF' || calcContSize === '40RH';
    const isSpecial = calcContSize === 'SPECIAL';

    let totalStorageCost = 0;
    const tierBreakdown: Array<{ name: string; days: number; dailyRate: number; subtotal: number }> = [];

    let remainingDays = calcStorageDays;
    let currentDayPointer = 1;

    for (const tier of selectedStorage.tiers) {
      if (remainingDays <= 0) break;

      const tierStart = tier.fromDay;
      const tierEnd = tier.toDay !== null ? tier.toDay : 999999;
      const tierCapacity = tierEnd - tierStart + 1;

      // Check how many days fall into this tier
      if (calcStorageDays >= tierStart) {
        const daysInThisTier = Math.min(calcStorageDays - tierStart + 1, tierCapacity);
        const effectiveDays = Math.max(0, Math.min(remainingDays, daysInThisTier));

        if (effectiveDays > 0) {
          let dailyRate = 0;
          if (isReefer) {
            dailyRate = calcContSize === '20RF' ? tier.price20Reefer : tier.price40Reefer;
          } else if (isSpecial) {
            dailyRate = tier.priceSpecial;
          } else {
            if (calcContSize === '20GP') dailyRate = tier.price20Dry;
            else if (calcContSize === '40GP_HC') dailyRate = tier.price40Dry;
            else dailyRate = tier.price45Dry;
          }

          const tierSubtotal = effectiveDays * dailyRate;
          totalStorageCost += tierSubtotal;

          tierBreakdown.push({
            name: tier.tierName,
            days: effectiveDays,
            dailyRate,
            subtotal: tierSubtotal
          });

          remainingDays -= effectiveDays;
        }
      }
    }

    const totalBeforeVat = totalLoloCost + totalStorageCost;
    const vatRate = 0.08;
    const vatAmount = totalBeforeVat * vatRate;
    const grandTotal = totalBeforeVat + vatAmount;

    return {
      selectedLolo,
      loloBasePrice,
      nightSurcharge,
      totalLoloCost,
      selectedStorage,
      tierBreakdown,
      totalStorageCost,
      isReefer,
      totalBeforeVat,
      vatAmount,
      grandTotal
    };
  }, [
    loloTariffs,
    storageRules,
    calcContSize,
    calcLoloAction,
    calcStorageRule,
    calcStorageDays,
    calcNightShift
  ]);

  return (
    <div className="space-y-6">
      {/* Header Info Banner */}
      <div className="p-6 bg-slate-900 border border-slate-800 rounded-3xl flex flex-col lg:flex-row lg:items-center justify-between gap-4 shadow-xl">
        <div className="flex items-start gap-4">
          <div className="p-3.5 bg-cyan-600/20 border border-cyan-500/30 text-cyan-400 rounded-2xl shadow-lg shrink-0">
            <Receipt className="w-8 h-8" />
          </div>
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <h2 className="text-xl font-bold text-white tracking-tight">
                BIỂU CƯỚC NÂNG HẠ (LOLO) &amp; LƯU BÃI (STORAGE)
              </h2>
              <span className="px-2.5 py-0.5 bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-[11px] font-bold rounded-full">
                VND / Tự Động Tính Thuế VAT 8%
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1 max-w-3xl">
              Cấu hình biểu giá nâng/hạ vỏ rỗng chuyên dụng (Gate-In / Gate-Out), phí đảo chuyển vỏ rỗng bãi, chính sách ngày miễn phí (Free Time) và biểu phí lưu bãi lũy tiến theo từng hãng tàu.
            </p>
          </div>
        </div>

        {/* Global Action Buttons */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setIsBulkAdjustOpen(true)}
            className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow"
          >
            <Percent className="w-4 h-4 text-amber-400" />
            <span>Điều Chỉnh % Biểu Giá</span>
          </button>

          <button
            onClick={() => {
              const exportBlob = new Blob([
                JSON.stringify({ loloTariffs, storageRules, exportedAt: new Date().toISOString() }, null, 2)
              ], { type: 'application/json' });
              const url = URL.createObjectURL(exportBlob);
              const a = document.createElement('a');
              a.href = url;
              a.download = `DEPOT-LOLO-STORAGE-TARIFFS-${new Date().toISOString().substring(0, 10)}.json`;
              a.click();
            }}
            className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow"
          >
            <Download className="w-4 h-4 text-emerald-400" />
            <span>Xuất Biểu Cước JSON</span>
          </button>
        </div>
      </div>

      {/* KPI Highlight Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-2xl">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Nâng Hạ Vỏ Rỗng 20'</span>
            <Truck className="w-4 h-4 text-cyan-400" />
          </div>
          <p className="text-xl font-bold font-mono text-cyan-300 mt-2">
            {formatVND(loloTariffs.find((t) => t.tariffCode === 'LOLO_MT_NORMAL')?.price20GP || 280000)}
          </p>
          <span className="text-[11px] text-slate-500">Áp dụng Gate-In & Gate-Out</span>
        </div>

        <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-2xl">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Nâng Hạ Vỏ Rỗng 40' HC</span>
            <Truck className="w-4 h-4 text-blue-400" />
          </div>
          <p className="text-xl font-bold font-mono text-blue-300 mt-2">
            {formatVND(loloTariffs.find((t) => t.tariffCode === 'LOLO_MT_NORMAL')?.price40GP_HC || 420000)}
          </p>
          <span className="text-[11px] text-slate-500">45' HC: {formatVND(loloTariffs.find((t) => t.tariffCode === 'LOLO_MT_NORMAL')?.price45HC || 500000)}</span>
        </div>

        <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-2xl">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Free Time Tiêu Chuẩn</span>
            <Calendar className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-xl font-bold font-mono text-emerald-400 mt-2">
            5 Ngày Miễn Phí
          </p>
          <span className="text-[11px] text-slate-500">Sau đó: 35k - 60k đ/ngày</span>
        </div>

        <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-2xl">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Phụ Phí Ca Đêm / Lễ</span>
            <Clock className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-xl font-bold font-mono text-amber-300 mt-2">
            {formatVND(loloTariffs.find((t) => t.applicableShift === 'NIGHT_SURCHARGE')?.price20GP || 80000)}
          </p>
          <span className="text-[11px] text-slate-500">40' HC: {formatVND(loloTariffs.find((t) => t.applicableShift === 'NIGHT_SURCHARGE')?.price40GP_HC || 120000)}</span>
        </div>
      </div>

      {/* Main Tabs Navigation */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-2 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-lg">
        <div className="flex items-center gap-1.5 w-full sm:w-auto">
          <button
            onClick={() => setActiveTab('LOLO')}
            className={`flex-1 sm:flex-initial px-4 py-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer ${
              activeTab === 'LOLO'
                ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-600/30'
                : 'bg-slate-950/60 text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Truck className="w-4 h-4" />
            <span>1. Biểu Cước Nâng Hạ (LoLo)</span>
            <span className="px-2 py-0.5 bg-cyan-950 text-cyan-200 text-[10px] rounded-full font-mono">
              {loloTariffs.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('STORAGE')}
            className={`flex-1 sm:flex-initial px-4 py-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer ${
              activeTab === 'STORAGE'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                : 'bg-slate-950/60 text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>2. Biểu Cước Lưu Bãi Lũy Tiến</span>
            <span className="px-2 py-0.5 bg-indigo-950 text-indigo-200 text-[10px] rounded-full font-mono">
              {storageRules.length} Quy tắc
            </span>
          </button>

          <button
            onClick={() => setActiveTab('CALCULATOR')}
            className={`flex-1 sm:flex-initial px-4 py-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer ${
              activeTab === 'CALCULATOR'
                ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/30'
                : 'bg-slate-950/60 text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Calculator className="w-4 h-4" />
            <span>3. Máy Tính Tự Động Chi Phí</span>
          </button>
        </div>

        {/* Search bar */}
        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-slate-400" />
          <input
            type="text"
            placeholder="Tìm theo mã, tên biểu cước..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
          />
        </div>
      </div>

      {/* TAB 1: LOLO TARIFF MATRIX */}
      {activeTab === 'LOLO' && (
        <div className="p-6 bg-slate-900 border border-slate-800 rounded-3xl space-y-4 shadow-xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Truck className="w-5 h-5 text-cyan-400" />
                <span>Bảng Đơn Giá Cước Nâng Hạ Container (Lift-On / Lift-Off Master Matrix)</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Bảng giá chi tiết theo từng quy cách container 20GP, 40GP/HC, 45HC, 20RF, 40RH và hàng đặc chủng.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <select
                value={loloCategoryFilter}
                onChange={(e) => setLoloCategoryFilter(e.target.value)}
                className="px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-300 font-medium focus:outline-none focus:border-cyan-500"
              >
                <option value="ALL">Tất cả phân loại vỏ rỗng</option>
                <option value="LIFT_EMPTY">Nâng hạ vỏ rỗng (Gate-In / Out)</option>
                <option value="SHIFTING">Đảo chuyển vỏ rỗng bãi (Shifting)</option>
                <option value="NIGHT_SURCHARGE">Phụ phí ca đêm vỏ rỗng</option>
              </select>

              <button
                onClick={handleOpenCreateLolo}
                className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow-lg shadow-cyan-600/30 whitespace-nowrap"
              >
                <Plus className="w-4 h-4" />
                <span>+ Thêm Hạng Mục LoLo</span>
              </button>
            </div>
          </div>

          {/* Pricing Table */}
          <div className="overflow-x-auto rounded-2xl border border-slate-800">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 bg-slate-950 text-slate-400 font-bold uppercase">
                  <th className="py-3 px-4">Mã Cước</th>
                  <th className="py-3 px-4 min-w-[220px]">Tên Dịch Vụ Nâng Hạ</th>
                  <th className="py-3 px-3">Phân Loại</th>
                  <th className="py-3 px-3">ĐVT</th>
                  <th className="py-3 px-3 text-right bg-cyan-950/20 text-cyan-300">20' GP/DC</th>
                  <th className="py-3 px-3 text-right bg-blue-950/20 text-blue-300">40' GP/HC</th>
                  <th className="py-3 px-3 text-right bg-indigo-950/20 text-indigo-300">45' HC</th>
                  <th className="py-3 px-3 text-right bg-teal-950/20 text-teal-300">20' RF (Lạnh)</th>
                  <th className="py-3 px-3 text-right bg-emerald-950/20 text-emerald-300">40' RH (Lạnh)</th>
                  <th className="py-3 px-3 text-right bg-amber-950/20 text-amber-300">OOG / Tank / FR</th>
                  <th className="py-3 px-3 text-center">VAT</th>
                  <th className="py-3 px-3 text-center">Trạng Thái</th>
                  <th className="py-3 px-3 text-center">Thao Tác</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80 text-slate-300 bg-slate-950/40">
                {filteredLoloTariffs.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-800/50 transition">
                    <td className="py-3.5 px-4 font-mono font-bold text-cyan-400 whitespace-nowrap">
                      {item.tariffCode}
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-white">{item.nameVi}</div>
                      <div className="text-[11px] text-slate-400">{item.nameEn}</div>
                      {item.applicableShift === 'NIGHT_SURCHARGE' && (
                        <span className="inline-block mt-1 px-2 py-0.5 bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded text-[10px] font-bold">
                          Ca đêm 22h-06h &amp; Lễ
                        </span>
                      )}
                    </td>
                    <td className="py-3.5 px-3 whitespace-nowrap">
                      <span className="px-2 py-1 bg-slate-800 text-slate-300 rounded text-[11px] font-medium">
                        {item.serviceCategory === 'LIFT_EMPTY' && 'Nâng Hạ Vỏ Rỗng'}
                        {item.serviceCategory === 'SHIFTING' && 'Đảo Vỏ Rỗng'}
                        {item.serviceCategory === 'NIGHT_SURCHARGE' && 'Phụ Phí Đêm'}
                      </span>
                    </td>
                    <td className="py-3.5 px-3 text-slate-400 font-medium whitespace-nowrap">
                      {item.unit}
                    </td>
                    <td className="py-3.5 px-3 text-right font-mono font-bold text-cyan-300 bg-cyan-950/10 whitespace-nowrap">
                      {formatVND(item.price20GP)}
                    </td>
                    <td className="py-3.5 px-3 text-right font-mono font-bold text-blue-300 bg-blue-950/10 whitespace-nowrap">
                      {formatVND(item.price40GP_HC)}
                    </td>
                    <td className="py-3.5 px-3 text-right font-mono font-bold text-indigo-300 bg-indigo-950/10 whitespace-nowrap">
                      {formatVND(item.price45HC)}
                    </td>
                    <td className="py-3.5 px-3 text-right font-mono font-bold text-teal-300 bg-teal-950/10 whitespace-nowrap">
                      {formatVND(item.price20RF)}
                    </td>
                    <td className="py-3.5 px-3 text-right font-mono font-bold text-emerald-300 bg-emerald-950/10 whitespace-nowrap">
                      {formatVND(item.price40RH)}
                    </td>
                    <td className="py-3.5 px-3 text-right font-mono font-bold text-amber-300 bg-amber-950/10 whitespace-nowrap">
                      {formatVND(item.priceSpecial)}
                    </td>
                    <td className="py-3.5 px-3 text-center font-bold text-slate-300">
                      {item.vatPercent}%
                    </td>
                    <td className="py-3.5 px-3 text-center">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        item.status === 'ACTIVE'
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                          : 'bg-slate-800 text-slate-400'
                      }`}>
                        {item.status === 'ACTIVE' ? 'Hoạt Động' : 'Tạm Dừng'}
                      </span>
                    </td>
                    <td className="py-3.5 px-3 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() => handleOpenEditLolo(item)}
                          className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg transition"
                          title="Chỉnh sửa đơn giá"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeleteLolo(item.id)}
                          className="p-1.5 bg-rose-950/40 hover:bg-rose-900/60 text-rose-400 border border-rose-800/40 rounded-lg transition"
                          title="Xóa hạng mục"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: PROGRESSIVE STORAGE MATRIX */}
      {activeTab === 'STORAGE' && (
        <div className="space-y-6">
          <div className="p-6 bg-slate-900 border border-slate-800 rounded-3xl space-y-4 shadow-xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Layers className="w-5 h-5 text-indigo-400" />
                  <span>Biểu Phí Lưu Bãi Lũy Tiến &amp; Chính Sách Free Time Hãng Tàu</span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Quy tắc tính lũy tiến theo số ngày lưu bãi thực tế (Free Time &rarr; Bậc 1 &rarr; Bậc 2 &rarr; Bậc 3).
                </p>
              </div>

              <div className="flex items-center gap-2">
                <select
                  value={shippingLineFilter}
                  onChange={(e) => setShippingLineFilter(e.target.value)}
                  className="px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-300 font-medium focus:outline-none focus:border-indigo-500"
                >
                  <option value="ALL">Tất cả hãng tàu</option>
                  <option value="MSK">Maersk Line (MSK)</option>
                  <option value="CMA">CMA CGM</option>
                  <option value="MSC">MSC</option>
                  <option value="ONE">ONE</option>
                </select>

                <button
                  onClick={() => alert('Mở form tạo mới quy tắc lưu bãi hãng tàu')}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow-lg shadow-indigo-600/30 whitespace-nowrap"
                >
                  <Plus className="w-4 h-4" />
                  <span>+ Thêm Quy Tắc Lưu Bãi</span>
                </button>
              </div>
            </div>

            {/* Storage Rules Cards */}
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
              {filteredStorageRules.map((rule) => (
                <div
                  key={rule.id}
                  className="p-5 bg-slate-950 border border-slate-800 rounded-2xl space-y-4 hover:border-slate-700 transition"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="px-2.5 py-0.5 bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-mono font-bold text-xs rounded-lg">
                          {rule.ruleCode}
                        </span>
                        <h4 className="font-bold text-white text-sm">
                          {rule.shippingLineName}
                        </h4>
                      </div>
                      <p className="text-xs text-slate-400 mt-1">{rule.notes}</p>
                    </div>

                    <span className="px-2.5 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold text-xs rounded-xl whitespace-nowrap">
                      {rule.defaultFreeDays} Ngày Free Time
                    </span>
                  </div>

                  {/* Tiers Table */}
                  <div className="overflow-x-auto rounded-xl border border-slate-800/80">
                    <table className="w-full text-left text-xs">
                      <thead>
                        <tr className="border-b border-slate-800 bg-slate-900 text-slate-400 font-bold">
                          <th className="py-2.5 px-3">Khung Thời Gian</th>
                          <th className="py-2.5 px-3 text-right">20' Dry (VND)</th>
                          <th className="py-2.5 px-3 text-right">40' Dry/HC (VND)</th>
                          <th className="py-2.5 px-3 text-right">45' HC (VND)</th>
                          <th className="py-2.5 px-3 text-right text-teal-300">20' Reefer</th>
                          <th className="py-2.5 px-3 text-right text-emerald-300">40' Reefer</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/60 text-slate-300">
                        {rule.tiers.map((tier, tIdx) => (
                          <tr key={tIdx} className="hover:bg-slate-900/50">
                            <td className="py-2.5 px-3 font-medium">
                              <div className="text-white font-bold">{tier.tierName}</div>
                              <div className="text-[10px] text-slate-400">
                                {tier.toDay ? `Ngày ${tier.fromDay} - ${tier.toDay}` : `Từ ngày ${tier.fromDay} trở đi`}
                              </div>
                            </td>
                            <td className="py-2.5 px-3 text-right font-mono font-bold">
                              {tier.price20Dry === 0 ? <span className="text-emerald-400">Miễn Phí</span> : formatVND(tier.price20Dry)}
                            </td>
                            <td className="py-2.5 px-3 text-right font-mono font-bold">
                              {tier.price40Dry === 0 ? <span className="text-emerald-400">Miễn Phí</span> : formatVND(tier.price40Dry)}
                            </td>
                            <td className="py-2.5 px-3 text-right font-mono font-bold">
                              {tier.price45Dry === 0 ? <span className="text-emerald-400">Miễn Phí</span> : formatVND(tier.price45Dry)}
                            </td>
                            <td className="py-2.5 px-3 text-right font-mono font-bold text-teal-300">
                              {tier.price20Reefer === 0 ? <span className="text-emerald-400">Miễn Phí</span> : formatVND(tier.price20Reefer)}
                            </td>
                            <td className="py-2.5 px-3 text-right font-mono font-bold text-emerald-300">
                              {tier.price40Reefer === 0 ? <span className="text-emerald-400">Miễn Phí</span> : formatVND(tier.price40Reefer)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  <div className="flex items-center justify-between text-[11px] pt-2 text-slate-400 border-t border-slate-800/80">
                    <span>Cập nhật ngày: {rule.updatedAt}</span>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => alert(`Chỉnh sửa quy tắc ${rule.ruleCode}`)}
                        className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded font-bold transition"
                      >
                        Sửa Biểu Phí
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: INTERACTIVE LIVE CALCULATOR */}
      {activeTab === 'CALCULATOR' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Inputs Section */}
          <div className="lg:col-span-5 p-6 bg-slate-900 border border-slate-800 rounded-3xl space-y-5 shadow-xl">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Calculator className="w-5 h-5 text-emerald-400" />
                <span>Nhập Thông Số Tính Toán Chi Phí</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Mô phỏng tự động tính toán tổng số tiền Nâng Hạ + Lưu Bãi lũy tiến + Cắm điện lạnh + Thuế VAT.
              </p>
            </div>

            <div className="space-y-4">
              {/* Cont size */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  1. Kích Cỡ &amp; Quy Cách Container:
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: '20GP', label: "20' GP / DC" },
                    { id: '40GP_HC', label: "40' GP / HC" },
                    { id: '45HC', label: "45' HC" },
                    { id: '20RF', label: "20' RF (Lạnh)" },
                    { id: '40RH', label: "40' RH (Lạnh)" },
                    { id: 'SPECIAL', label: 'OOG / FlatRack' }
                  ].map((sz) => (
                    <button
                      key={sz.id}
                      type="button"
                      onClick={() => setCalcContSize(sz.id as any)}
                      className={`p-2 rounded-xl text-xs font-bold transition border cursor-pointer ${
                        calcContSize === sz.id
                          ? 'bg-emerald-600/20 text-emerald-300 border-emerald-500/50 shadow'
                          : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                      }`}
                    >
                      {sz.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* LoLo Service Action */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  2. Nghiệp Vụ Nâng / Hạ (LoLo):
                </label>
                <select
                  value={calcLoloAction}
                  onChange={(e) => setCalcLoloAction(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500 font-medium"
                >
                  {loloTariffs.map((t) => (
                    <option key={t.tariffCode} value={t.tariffCode}>
                      {t.nameVi} ({t.tariffCode})
                    </option>
                  ))}
                </select>
              </div>

              {/* Storage Rule selection */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  3. Chính Sách Lưu Bãi Áp Dụng:
                </label>
                <select
                  value={calcStorageRule}
                  onChange={(e) => setCalcStorageRule(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500 font-medium"
                >
                  {storageRules.map((r) => (
                    <option key={r.ruleCode} value={r.ruleCode}>
                      {r.shippingLineName} ({r.defaultFreeDays} ngày Free)
                    </option>
                  ))}
                </select>
              </div>

              {/* Days input slider */}
              <div>
                <div className="flex items-center justify-between text-xs font-bold text-slate-300 mb-1.5">
                  <span>4. Tổng Số Ngày Lưu Bãi Thực Tế:</span>
                  <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 font-mono text-sm rounded-lg">
                    {calcStorageDays} Ngày
                  </span>
                </div>
                <input
                  type="range"
                  min={1}
                  max={60}
                  value={calcStorageDays}
                  onChange={(e) => setCalcStorageDays(Number(e.target.value))}
                  className="w-full accent-emerald-500 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-1">
                  <span>1 ngày</span>
                  <span>15 ngày</span>
                  <span>30 ngày</span>
                  <span>60 ngày</span>
                </div>
              </div>

              {/* Night Shift Toggle */}
              <label className="flex items-center gap-3 p-3 bg-slate-950 border border-slate-800 rounded-xl cursor-pointer hover:border-slate-700 transition">
                <input
                  type="checkbox"
                  checked={calcNightShift}
                  onChange={(e) => setCalcNightShift(e.target.checked)}
                  className="w-4 h-4 rounded text-emerald-500 focus:ring-emerald-500 accent-emerald-500"
                />
                <div>
                  <div className="text-xs font-bold text-white">Nâng hạ ca đêm / Ngày Lễ</div>
                  <div className="text-[11px] text-slate-400">Cộng phụ phí ngoài giờ quy định</div>
                </div>
              </label>
            </div>
          </div>

          {/* Detailed Invoice Breakdown Section */}
          <div className="lg:col-span-7 p-6 bg-slate-900 border border-slate-800 rounded-3xl space-y-5 shadow-xl flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div>
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <Receipt className="w-5 h-5 text-cyan-400" />
                    <span>Dự Toán Hóa Đơn Chi Tiết (Estimated Tariff Invoice)</span>
                  </h3>
                  <span className="text-xs text-slate-400">
                    Quy chuẩn Cont: {calcContSize} &bull; Lưu bãi {calcStorageDays} ngày &bull; {calculationResult.selectedStorage.shippingLineName}
                  </span>
                </div>
                <button
                  onClick={() => window.print()}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-bold flex items-center gap-1.5 transition"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>In Phiếu</span>
                </button>
              </div>

              {/* Breakdown List */}
              <div className="space-y-2.5 text-xs">
                {/* 1. Lift On/Off */}
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80 space-y-1.5">
                  <div className="flex items-center justify-between font-bold text-white">
                    <span className="flex items-center gap-1.5">
                      <Truck className="w-4 h-4 text-cyan-400" />
                      1. Cước Nâng / Hạ (LoLo)
                    </span>
                    <span className="font-mono text-cyan-300 font-bold">{formatVND(calculationResult.loloBasePrice)}</span>
                  </div>
                  <div className="text-[11px] text-slate-400 pl-5">
                    {calculationResult.selectedLolo.nameVi}
                  </div>
                  {calculationResult.nightSurcharge > 0 && (
                    <div className="flex items-center justify-between text-[11px] pl-5 text-amber-300 font-medium">
                      <span>&bull; Phụ phí nâng hạ ca đêm / lễ:</span>
                      <span className="font-mono">+{formatVND(calculationResult.nightSurcharge)}</span>
                    </div>
                  )}
                </div>

                {/* 2. Storage Tiers */}
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80 space-y-2">
                  <div className="flex items-center justify-between font-bold text-white">
                    <span className="flex items-center gap-1.5">
                      <Layers className="w-4 h-4 text-indigo-400" />
                      2. Tiền Lưu Bãi Lũy Tiến ({calcStorageDays} ngày)
                    </span>
                    <span className="font-mono text-indigo-300 font-bold">
                      {formatVND(calculationResult.totalStorageCost)}
                    </span>
                  </div>

                  <div className="space-y-1 pl-5 border-l-2 border-slate-800">
                    {calculationResult.tierBreakdown.map((t, idx) => (
                      <div key={idx} className="flex items-center justify-between text-[11px] text-slate-300">
                        <span>&bull; {t.name} ({t.days} ngày x {formatVND(t.dailyRate)}):</span>
                        <span className="font-mono font-bold">{formatVND(t.subtotal)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Total Calculation Card */}
            <div className="p-5 bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950/50 border border-emerald-500/30 rounded-2xl space-y-2.5">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Cộng tiền trước thuế (Subtotal):</span>
                <span className="font-mono text-white font-bold">{formatVND(calculationResult.totalBeforeVat)}</span>
              </div>
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Thuế giá trị gia tăng (VAT 8%):</span>
                <span className="font-mono text-emerald-400 font-bold">+{formatVND(calculationResult.vatAmount)}</span>
              </div>
              <div className="h-[1px] bg-slate-800 pt-1" />
              <div className="flex items-center justify-between text-sm sm:text-base font-bold text-white pt-1">
                <span>TỔNG TIỀN PHẢI THANH TOÁN:</span>
                <span className="font-mono text-2xl text-emerald-400 font-black">
                  {formatVND(calculationResult.grandTotal)}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CREATE / EDIT LOLO MODAL */}
      {isLoloModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl my-8">
            <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950">
              <div className="flex items-center gap-2">
                <Truck className="w-5 h-5 text-cyan-400" />
                <h3 className="font-bold text-white text-base">
                  {editingLolo ? 'Cập Nhật Biểu Cước Nâng Hạ (LoLo)' : 'Thêm Mới Hạng Mục Cước Nâng Hạ'}
                </h3>
              </div>
              <button
                onClick={() => setIsLoloModalOpen(false)}
                className="p-2 hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveLolo} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Mã Biểu Cước (Tariff Code) *</label>
                  <input
                    type="text"
                    required
                    value={loloForm.tariffCode || ''}
                    onChange={(e) => setLoloForm({ ...loloForm, tariffCode: e.target.value.toUpperCase() })}
                    placeholder="VD: LOLO_MT_NORMAL"
                    className="w-full px-3.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white font-mono focus:outline-none focus:border-cyan-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Phân Loại Dịch Vụ Vỏ Rỗng *</label>
                  <select
                    value={loloForm.serviceCategory || 'LIFT_EMPTY'}
                    onChange={(e) => setLoloForm({ ...loloForm, serviceCategory: e.target.value as any })}
                    className="w-full px-3.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500"
                  >
                    <option value="LIFT_EMPTY">Nâng hạ vỏ container rỗng (Empty Lift-On / Off)</option>
                    <option value="SHIFTING">Đảo chuyển vỏ rỗng nội bộ bãi (Empty Shifting)</option>
                    <option value="NIGHT_SURCHARGE">Phụ phí ca đêm nâng hạ vỏ rỗng</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Tên Dịch Vụ (Tiếng Việt) *</label>
                <input
                  type="text"
                  required
                  value={loloForm.nameVi || ''}
                  onChange={(e) => setLoloForm({ ...loloForm, nameVi: e.target.value })}
                  placeholder="VD: Cước nâng container rỗng lên xe đầu kéo"
                  className="w-full px-3.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Tên Dịch Vụ (Tiếng Anh)</label>
                <input
                  type="text"
                  value={loloForm.nameEn || ''}
                  onChange={(e) => setLoloForm({ ...loloForm, nameEn: e.target.value })}
                  placeholder="VD: Empty Container Lift-On to Truck"
                  className="w-full px-3.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500"
                />
              </div>

              {/* Price Matrix */}
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-3">
                <h4 className="text-xs font-bold text-cyan-400 uppercase tracking-wider">
                  Đơn Giá Theo Kích Cỡ Container (VNĐ)
                </h4>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-400 mb-1">20' GP / DC</label>
                    <input
                      type="number"
                      value={loloForm.price20GP || 0}
                      onChange={(e) => setLoloForm({ ...loloForm, price20GP: Number(e.target.value) })}
                      className="w-full px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs font-mono text-cyan-300 font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-400 mb-1">40' GP / HC</label>
                    <input
                      type="number"
                      value={loloForm.price40GP_HC || 0}
                      onChange={(e) => setLoloForm({ ...loloForm, price40GP_HC: Number(e.target.value) })}
                      className="w-full px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs font-mono text-blue-300 font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-400 mb-1">45' HC</label>
                    <input
                      type="number"
                      value={loloForm.price45HC || 0}
                      onChange={(e) => setLoloForm({ ...loloForm, price45HC: Number(e.target.value) })}
                      className="w-full px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs font-mono text-indigo-300 font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-400 mb-1">20' RF (Lạnh)</label>
                    <input
                      type="number"
                      value={loloForm.price20RF || 0}
                      onChange={(e) => setLoloForm({ ...loloForm, price20RF: Number(e.target.value) })}
                      className="w-full px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs font-mono text-teal-300 font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-400 mb-1">40' RH (Lạnh)</label>
                    <input
                      type="number"
                      value={loloForm.price40RH || 0}
                      onChange={(e) => setLoloForm({ ...loloForm, price40RH: Number(e.target.value) })}
                      className="w-full px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs font-mono text-emerald-300 font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-400 mb-1">OOG / Tank / Flat</label>
                    <input
                      type="number"
                      value={loloForm.priceSpecial || 0}
                      onChange={(e) => setLoloForm({ ...loloForm, priceSpecial: Number(e.target.value) })}
                      className="w-full px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs font-mono text-amber-300 font-bold"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Thuế VAT (%)</label>
                  <input
                    type="number"
                    value={loloForm.vatPercent || 8}
                    onChange={(e) => setLoloForm({ ...loloForm, vatPercent: Number(e.target.value) })}
                    className="w-full px-3.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Trạng Thái</label>
                  <select
                    value={loloForm.status || 'ACTIVE'}
                    onChange={(e) => setLoloForm({ ...loloForm, status: e.target.value as any })}
                    className="w-full px-3.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white"
                  >
                    <option value="ACTIVE">Hoạt Động</option>
                    <option value="INACTIVE">Tạm Ngưng</option>
                  </select>
                </div>
              </div>

              <div className="p-4 border-t border-slate-800 flex items-center justify-end gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setIsLoloModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold transition"
                >
                  Hủy Bỏ
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-bold transition shadow-lg shadow-cyan-600/30"
                >
                  Lưu Biểu Cước LoLo
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* BULK ADJUST MODAL */}
      {isBulkAdjustOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-md overflow-hidden shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-white text-base flex items-center gap-2">
                <Percent className="w-5 h-5 text-amber-400" />
                <span>Điều Chỉnh Tỷ Lệ Biểu Giá Đồng Loạt</span>
              </h3>
              <button onClick={() => setIsBulkAdjustOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Áp Dụng Cho:</label>
                <select
                  value={bulkTarget}
                  onChange={(e) => setBulkTarget(e.target.value as any)}
                  className="w-full px-3.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white"
                >
                  <option value="LOLO">Toàn bộ Cước Nâng Hạ (LoLo)</option>
                  <option value="STORAGE">Toàn bộ Cước Lưu Bãi (Storage)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Mức % Tăng / Giảm (+ / -)
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    value={bulkPercent}
                    onChange={(e) => setBulkPercent(Number(e.target.value))}
                    placeholder="VD: 5 hoặc -5"
                    className="w-full px-3.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs font-mono text-amber-300 font-bold"
                  />
                  <span className="text-sm font-bold text-slate-400">%</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-1">
                  (Nhập số dương để tăng giá cước, số âm để giảm giá cước. Giá sẽ tự động làm tròn về hàng nghìn VNĐ).
                </p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
              <button
                onClick={() => setIsBulkAdjustOpen(false)}
                className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl text-xs font-bold"
              >
                Hủy
              </button>
              <button
                onClick={handleApplyBulkAdjust}
                className="px-5 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-amber-600/30"
              >
                Áp Dụng Cập Nhật
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
