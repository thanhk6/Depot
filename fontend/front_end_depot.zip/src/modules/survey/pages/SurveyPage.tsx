import React from 'react';
import { SurveyModulePage } from './SurveyModulePage';
import { ContainerRecord } from '../../../services/mockDataStore';

interface SurveyPageProps {
  initialSubTab?: string;
  containers?: ContainerRecord[];
  onSaveSurvey?: (
    containerId: string,
    condition: 'AV' | 'CL' | 'DM',
    damages: any[],
    containerData?: any
  ) => void;
  onNavigateTab?: (tabId: string) => void;
}

export const SurveyPage: React.FC<SurveyPageProps> = ({
  initialSubTab = 'queue',
  containers,
  onSaveSurvey,
  onNavigateTab
}) => {
  return (
    <SurveyModulePage
      initialSubTab={initialSubTab}
      onNavigateTab={onNavigateTab}
      onSyncContainer={onSaveSurvey}
    />
  );
};
