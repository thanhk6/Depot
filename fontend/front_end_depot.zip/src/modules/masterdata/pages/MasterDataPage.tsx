import React, { useState } from 'react';
import {
  DamageLocationMasterItem,
  DamageCodeMasterItem,
  RepairCodeMasterItem,
  GradeMasterItem,
  InspectionStandardMasterItem,
  ContainerTypeMasterItem,
  CleaningTariffMasterItem
} from '../../survey/types';
import {
  INITIAL_DAMAGE_LOCATIONS,
  INITIAL_DAMAGE_CODES,
  INITIAL_REPAIR_CODES,
  INITIAL_GRADE_MASTERS,
  INITIAL_INSPECTION_STANDARDS,
  INITIAL_CONTAINER_TYPES,
  INITIAL_CLEANING_TARIFFS
} from '../../survey/mockData';
import { DamageLocationMaster } from '../../survey/components/DamageLocationMaster';
import { DamageCodeMaster } from '../../survey/components/DamageCodeMaster';
import { RepairCodeMaster } from '../../survey/components/RepairCodeMaster';
import { GradeMaster } from '../../survey/components/GradeMaster';
import { InspectionStandardMaster } from '../../survey/components/InspectionStandardMaster';
import { ContainerTypeMaster } from '../components/ContainerTypeMaster';
import { CleaningMaster } from '../components/CleaningMaster';
import { LiftOnLiftOffAndStorageMaster } from '../components/LiftOnLiftOffAndStorageMaster';
import { CustomerClassificationMaster } from '../../customer/components/CustomerClassificationMaster';
import { DepartmentMaster } from '../components/DepartmentMaster';
import { INITIAL_DEPARTMENTS } from '../data/departmentMockData';
import { DepartmentItem } from '../types/department';

import {
  Database,
  MapPin,
  FileCode,
  Hammer,
  Sparkles,
  ShieldCheck,
  Container,
  Building2,
  Receipt,
  Layers,
  FileSpreadsheet,
  Download,
  Upload,
  CheckCircle2,
  RefreshCw,
  Search,
  Plus,
  Droplets,
  Tag,
  Truck
} from 'lucide-react';

export interface MasterDataPageProps {
  initialTab?: string;
  onNavigateTab?: (tabId: string) => void;
}

export const MasterDataPage: React.FC<MasterDataPageProps> = ({
  initialTab = 'cleaning_tariffs',
  onNavigateTab
}) => {
  const [activeMasterTab, setActiveMasterTab] = useState<string>(initialTab);

  // Master Data collections state
  const [locations, setLocations] = useState<DamageLocationMasterItem[]>(INITIAL_DAMAGE_LOCATIONS);
  const [damageCodes, setDamageCodes] = useState<DamageCodeMasterItem[]>(INITIAL_DAMAGE_CODES);
  const [repairCodes, setRepairCodes] = useState<RepairCodeMasterItem[]>(INITIAL_REPAIR_CODES);
  const [grades, setGrades] = useState<GradeMasterItem[]>(INITIAL_GRADE_MASTERS);
  const [standards, setStandards] = useState<InspectionStandardMasterItem[]>(INITIAL_INSPECTION_STANDARDS);
  const [containerTypes, setContainerTypes] = useState<ContainerTypeMasterItem[]>(INITIAL_CONTAINER_TYPES);
  const [cleaningTariffs, setCleaningTariffs] = useState<CleaningTariffMasterItem[]>(INITIAL_CLEANING_TARIFFS);
  const [departments, setDepartments] = useState<DepartmentItem[]>(INITIAL_DEPARTMENTS);

  React.useEffect(() => {
    if (initialTab) {
      setActiveMasterTab(initialTab);
    }
  }, [initialTab]);

  // Master Data Groups Definition
  const masterGroups = [
    {
      groupTitle: 'DANH MỤC KHAI THÁC & KỸ THUẬT VỎ',
      items: [
        {
          id: 'container_types',
          label: 'Loại Container (ISO 6346)',
          desc: `${containerTypes.length} quy cách chuẩn: 20ft (1.0 TEU), 40ft, 45ft, Reefer, OT, FR, Tank, Special...`,
          icon: Container,
          count: containerTypes.length,
          color: 'text-sky-400',
          bg: 'bg-sky-500/10'
        },
        {
          id: 'damage_locations',
          label: 'Vị Trí Cấu Kiện (Locations)',
          desc: '18 vị trí cấu kiện container tiêu chuẩn',
          icon: MapPin,
          count: locations.length,
          color: 'text-amber-400',
          bg: 'bg-amber-500/10'
        },
        {
          id: 'damage_codes',
          label: 'Mã Hư Hỏng (Damage Codes)',
          desc: 'Mã tổn thất chuẩn IICL-6 & CEDEX',
          icon: FileCode,
          count: damageCodes.length,
          color: 'text-rose-400',
          bg: 'bg-rose-500/10'
        },
        {
          id: 'repair_codes',
          label: 'Mã Sửa Chữa (Repair Codes)',
          desc: 'Phương án kỹ thuật STS & Đơn vị tính',
          icon: Hammer,
          count: repairCodes.length,
          color: 'text-blue-400',
          bg: 'bg-blue-500/10'
        },
        {
          id: 'grades',
          label: 'Phân Hạng Vỏ (Quality Grades)',
          desc: 'Grade A, Food Grade, General, Scrap',
          icon: Sparkles,
          count: grades.length,
          color: 'text-emerald-400',
          bg: 'bg-emerald-500/10'
        },
        {
          id: 'standards',
          label: 'Tiêu Chuẩn Giám Định (Standards)',
          desc: 'IICL-6, MCIC, MRIC, Carrier Rules',
          icon: ShieldCheck,
          count: standards.length,
          color: 'text-purple-400',
          bg: 'bg-purple-500/10'
        }
      ]
    },
    {
      groupTitle: 'DANH MỤC TỔ CHỨC, ĐỐI TÁC & BIỂU PHÍ DỊCH VỤ',
      items: [
        {
          id: 'departments',
          label: 'DM Phòng Ban & Cơ Cấu Tổ Chức',
          desc: `${departments.length} phòng ban nghiệp vụ Depot: Ban Giám Đốc, Cổng Gate, Giám Định, Sửa Chữa M&R, Kế Toán...`,
          icon: Building2,
          count: departments.length,
          color: 'text-indigo-400',
          bg: 'bg-indigo-500/10'
        },
        {
          id: 'cleaning_tariffs',
          label: 'Biểu Phí Vệ Sinh Container (Cleaning)',
          desc: '10 phương pháp xịt rửa, hóa chất, khử mùi & bảng giá',
          icon: Droplets,
          count: cleaningTariffs.length,
          color: 'text-cyan-400',
          bg: 'bg-cyan-500/10'
        },
        {
          id: 'shipping_lines',
          label: 'Hãng Tàu (Maersk Line)',
          desc: 'Maersk Line (MAEU / A.P. Moller – Maersk) – Hãng tàu duy nhất',
          icon: Building2,
          count: 1,
          color: 'text-sky-400',
          bg: 'bg-sky-500/10'
        },
        {
          id: 'tariff_services',
          label: 'Biểu Cước Nâng Hạ & Lưu Bãi',
          desc: 'Phí nâng hạ vỏ rỗng, đảo chuyển, lưu bãi lũy tiến',
          icon: Receipt,
          count: 24,
          color: 'text-indigo-400',
          bg: 'bg-indigo-500/10'
        },
        {
          id: 'customer_classifications',
          label: 'Phân Loại Khách Hàng',
          desc: 'Danh mục nhóm phân loại khách hàng, nhà xe, forwarder và mô tả chi tiết',
          icon: Tag,
          count: 5,
          color: 'text-pink-400',
          bg: 'bg-pink-500/10'
        }
      ]
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="p-6 bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-slate-800 rounded-3xl flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-2xl">
        <div className="flex items-center gap-4">
          <div className="p-3.5 bg-indigo-600/20 border border-indigo-500/30 text-indigo-400 rounded-2xl shadow-lg">
            <Database className="w-8 h-8" />
          </div>
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <h1 className="text-xl font-bold text-white tracking-tight">
                DANH MỤC HỆ THỐNG &amp; MASTER DATA
              </h1>
              <span className="px-2.5 py-0.5 bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-[11px] font-bold rounded-full">
                IICL-6 / ISO-6346 / CEDEX
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Quản trị tập trung danh mục cấu kiện, bảng mã hư hỏng, quy trình sửa chữa, cấp phân hạng và quy chuẩn kỹ thuật toàn Depot.
            </p>
          </div>
        </div>

        {/* Quick Action Tools */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              const exportData = {
                departments,
                containerTypes,
                locations,
                damageCodes,
                repairCodes,
                grades,
                standards,
                exportedAt: new Date().toISOString()
              };
              const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = `DEPOT-MASTER-DATA-${new Date().toISOString().substring(0, 10)}.json`;
              a.click();
            }}
            className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow"
          >
            <Download className="w-4 h-4 text-emerald-400" />
            <span>Xuất JSON Master</span>
          </button>

          <button
            onClick={() => alert('Dữ liệu Master Data đã được đồng bộ chuẩn IICL-6 mới nhất!')}
            className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-lg shadow-indigo-600/30"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Đồng Bộ IICL Chuẩn</span>
          </button>
        </div>
      </div>

      {/* Main Tabs Navigation */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-2 shadow-xl">
        <div className="flex items-center gap-1 overflow-x-auto pb-1">
          {masterGroups.flatMap((g) => g.items).map((item) => {
            const Icon = item.icon;
            const isActive = activeMasterTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveMasterTab(item.id)}
                className={`px-4 py-2.5 rounded-2xl text-xs font-bold whitespace-nowrap transition flex items-center gap-2 cursor-pointer ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30 ring-1 ring-indigo-400/50'
                    : 'bg-slate-950/60 text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : item.color}`} />
                <span>{item.label}</span>
                <span
                  className={`px-1.5 py-0.5 rounded-full text-[10px] font-mono font-bold ${
                    isActive ? 'bg-indigo-950 text-indigo-200' : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {item.count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Content Rendering By Tab */}
      <div className="min-h-[480px]">
        {/* Container Types Master (ISO 6346) */}
        {(activeMasterTab === 'container_types' || activeMasterTab === 'iso_types') && (
          <ContainerTypeMaster
            containerTypes={containerTypes}
            onUpdateContainerTypes={(updated) => setContainerTypes(updated)}
          />
        )}

        {activeMasterTab === 'damage_locations' && (
          <DamageLocationMaster
            locations={locations}
            onUpdateLocations={(updated) => setLocations(updated)}
          />
        )}

        {activeMasterTab === 'damage_codes' && (
          <DamageCodeMaster
            damageCodes={damageCodes}
            onUpdateDamageCodes={(updated) => setDamageCodes(updated)}
          />
        )}

        {activeMasterTab === 'repair_codes' && (
          <RepairCodeMaster
            repairCodes={repairCodes}
            onUpdateRepairCodes={(updated) => setRepairCodes(updated)}
          />
        )}

        {activeMasterTab === 'grades' && (
          <GradeMaster
            grades={grades}
            onUpdateGrades={(updated) => setGrades(updated)}
          />
        )}

        {activeMasterTab === 'standards' && (
          <InspectionStandardMaster
            standards={standards}
            onUpdateStandards={(updated) => setStandards(updated)}
          />
        )}

        {/* Cleaning Tariff Master */}
        {activeMasterTab === 'cleaning_tariffs' && (
          <CleaningMaster
            cleaningTariffs={cleaningTariffs}
            onUpdateCleaningTariffs={setCleaningTariffs}
            containerTypes={containerTypes}
          />
        )}

        {/* Shipping Lines Master */}
        {activeMasterTab === 'shipping_lines' && (
          <div className="p-6 bg-slate-900 border border-slate-800 rounded-3xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Building2 className="w-5 h-5 text-sky-400" />
                  <span>Danh Mục Hãng Tàu Khai Thác: MAERSK LINE (MAEU)</span>
                </h3>
                <p className="text-xs text-slate-400">
                  Cấu hình chuẩn kiểm định IICL-6, hạn mức duyệt báo giá tự động qua API (Auto-Approval Limit) và định dạng EDI/CEDEX với Hãng tàu Maersk.
                </p>
              </div>
            </div>

            <div className="p-5 bg-slate-950/80 border border-sky-500/40 rounded-2xl space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
                <div className="flex items-center gap-3">
                  <span className="px-3 py-1 bg-sky-950 text-sky-300 font-mono font-black text-sm border border-sky-800 rounded-lg">
                    MAEU
                  </span>
                  <div>
                    <h4 className="text-sm font-bold text-white">MAERSK LINE (A.P. Moller – Maersk)</h4>
                    <span className="text-xs text-slate-400">Hãng tàu duy nhất tại Depot | Trụ sở: Copenhagen, Đan Mạch 🇩🇰</span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="px-3 py-1 bg-emerald-950 text-emerald-300 border border-emerald-800 text-xs font-bold rounded-lg flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> 100% API &amp; EDI CONNECTED
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl">
                  <span className="text-slate-500 block text-[11px]">Tiêu Chuẩn Giám Định</span>
                  <span className="font-bold text-indigo-300 font-mono text-sm">IICL-6 / Maersk STD</span>
                </div>
                <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl">
                  <span className="text-slate-500 block text-[11px]">Hạn Mức Auto-Approve</span>
                  <span className="font-bold text-emerald-400 font-mono text-sm">$150 USD (~3.8 tr)</span>
                </div>
                <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl">
                  <span className="text-slate-500 block text-[11px]">Miễn Phí Lưu Bãi (Free Time)</span>
                  <span className="font-bold text-white font-mono text-sm">5 Ngày</span>
                </div>
                <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl">
                  <span className="text-slate-500 block text-[11px]">Giao Thức Trao Đổi</span>
                  <span className="font-bold text-sky-300 font-mono text-[11px]">REST API / WESTIM v2.1</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tariff Services: Lift-On/Lift-Off & Storage Master */}
        {(activeMasterTab === 'tariff_services' || activeMasterTab === 'lolo_storage' || activeMasterTab === 'master_tariffs') && (
          <LiftOnLiftOffAndStorageMaster />
        )}

        {/* Customer Classifications Master */}
        {(activeMasterTab === 'customer_classifications' || activeMasterTab === 'master_customers') && (
          <CustomerClassificationMaster />
        )}

        {/* Departments Master Data */}
        {(activeMasterTab === 'departments' || activeMasterTab === 'master_departments') && (
          <DepartmentMaster
            departments={departments}
            onUpdateDepartments={(updated) => setDepartments(updated)}
          />
        )}
      </div>
    </div>
  );
};
