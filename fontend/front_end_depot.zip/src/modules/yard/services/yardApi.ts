import axios from 'axios';
import {
  YardZone,
  YardBlock,
  YardContainer,
  YardLocationEntity,
  Forklift,
  ForkliftDispatch,
  YardMoveHistory,
  YardStatistics,
  YardGateLane
} from '../types/yardTypes';

const API_BASE = '/api/yard';

export interface YardFullResponse {
  zones: YardZone[];
  blocks: YardBlock[];
  containers: YardContainer[];
  locations: YardLocationEntity[];
  forklifts: Forklift[];
  dispatches: ForkliftDispatch[];
  gateLanes: YardGateLane[];
  statistics: YardStatistics;
}

export const initialZones: YardZone[] = [
  {
    id: 'ZONE_GATE_IN',
    yardId: 'YARD_HN_01',
    zoneCode: 'GATE_IN',
    zoneName: 'CỔNG VÀO CONTAINER (GATE-IN)',
    zoneType: 'GATE_IN',
    positionX: 50,
    positionY: 50,
    width: 320,
    height: 180,
    description: '3 Làn OCR/RFID - Cân điện tử 80T - Camera giám sát'
  },
  {
    id: 'ZONE_INSPECTION',
    yardId: 'YARD_HN_01',
    zoneCode: 'INSPECTION',
    zoneName: 'KHU VỰC KHẢO SÁT & GIÁM ĐỊNH (IICL SURVEY)',
    zoneType: 'INSPECTION',
    positionX: 420,
    positionY: 50,
    width: 380,
    height: 180,
    description: 'Bệ giám định gầm, vách, nóc & máy lạnh PTI'
  },
  {
    id: 'ZONE_GATE_OUT',
    yardId: 'YARD_HN_01',
    zoneCode: 'GATE_OUT',
    zoneName: 'CỔNG XUẤT CONTAINER (GATE-OUT)',
    zoneType: 'GATE_OUT',
    positionX: 1600,
    positionY: 50,
    width: 320,
    height: 180,
    description: '2 Làn xuất bãi - Đối soát EDO & Seal Hải quan'
  },
  {
    id: 'ZONE_STORAGE_A',
    yardId: 'YARD_HN_01',
    zoneCode: 'STORAGE_A',
    zoneName: 'KHU BÃI BLOCK A (CONTAINER KHÔ TIÊU CHUẨN)',
    zoneType: 'STORAGE',
    positionX: 50,
    positionY: 420,
    width: 520,
    height: 380,
    description: 'Khu bãi chính - 8 Bays x 4 Rows - 4 Tiers'
  },
  {
    id: 'ZONE_STORAGE_B',
    yardId: 'YARD_HN_01',
    zoneCode: 'STORAGE_B',
    zoneName: 'KHU BÃI BLOCK B (CONTAINER LẠNH REEFER / MAERSK & MSC)',
    zoneType: 'STORAGE',
    positionX: 620,
    positionY: 420,
    width: 520,
    height: 380,
    description: 'Trạm cắm điện 380V - 8 Bays x 4 Rows - 4 Tiers'
  },
  {
    id: 'ZONE_STORAGE_C',
    yardId: 'YARD_HN_01',
    zoneCode: 'STORAGE_C',
    zoneName: 'KHU BÃI BLOCK C (CONTAINER RỖNG KHAI THÁC ONE / CMA)',
    zoneType: 'STORAGE',
    positionX: 1190,
    positionY: 420,
    width: 520,
    height: 380,
    description: 'Khu vỏ sạch xuất khẩu - 8 Bays x 4 Rows - 4 Tiers'
  },
  {
    id: 'ZONE_STORAGE_D',
    yardId: 'YARD_HN_01',
    zoneCode: 'STORAGE_D',
    zoneName: 'KHU BÃI BLOCK D (CONTAINER 45HC & ĐẶC BIỆT OT/FR)',
    zoneType: 'STORAGE',
    positionX: 50,
    positionY: 860,
    width: 520,
    height: 380,
    description: 'Bãi hạ container ngoại cỡ & 45 High Cube'
  },
  {
    id: 'ZONE_STORAGE_E',
    yardId: 'YARD_HN_01',
    zoneCode: 'STORAGE_E',
    zoneName: 'KHU BÃI BLOCK E (DỰ PHÒNG & CHUYỂN TẢI CẢNG)',
    zoneType: 'STORAGE',
    positionX: 620,
    positionY: 860,
    width: 520,
    height: 380,
    description: 'Khu bãi chuyển tải nhanh & trung chuyển sà lan'
  },
  {
    id: 'ZONE_REPAIR',
    yardId: 'YARD_HN_01',
    zoneCode: 'REPAIR',
    zoneName: 'KHU VỰC XƯỞNG SỬA CHỮA EMR (REPAIR AREA)',
    zoneType: 'REPAIR',
    positionX: 1760,
    positionY: 340,
    width: 380,
    height: 250,
    description: 'Xưởng hàn cắt, nắn xà, thay vách, vá sàn & sơn'
  },
  {
    id: 'ZONE_CLEANING',
    yardId: 'YARD_HN_01',
    zoneCode: 'CLEANING',
    zoneName: 'BÃI RỬA & VỆ SINH CONTAINER (CLEANING PAD)',
    zoneType: 'CLEANING',
    positionX: 1760,
    positionY: 630,
    width: 380,
    height: 250,
    description: 'Trạm rửa áp lực cao, xịt hóa chất & sấy khô'
  },
  {
    id: 'ZONE_HOLD',
    yardId: 'YARD_HN_01',
    zoneCode: 'HOLD',
    zoneName: 'KHU VỰC NIÊM PHONG TẠM GIỮ (HOLD AREA)',
    zoneType: 'HOLD',
    positionX: 1760,
    positionY: 920,
    width: 380,
    height: 250,
    description: 'Cách ly: Hải quan niêm phong, thiếu chứng từ, tranh chấp'
  },
  {
    id: 'ZONE_STAGING',
    yardId: 'YARD_HN_01',
    zoneCode: 'STAGING',
    zoneName: 'KHU VỰC CHỜ CẤP VỎ / STAGING (PRE GATE-OUT)',
    zoneType: 'STAGING',
    positionX: 1190,
    positionY: 860,
    width: 520,
    height: 200,
    description: 'Khu tập kết container đã kiểm tra AV sẵn sàng nâng lên xe'
  },
  {
    id: 'ZONE_FORKLIFT',
    yardId: 'YARD_HN_01',
    zoneCode: 'FORKLIFT_AREA',
    zoneName: 'BÃI ĐẬU XE NÂNG & BẢO TRÌ (FORKLIFT AREA)',
    zoneType: 'FORKLIFT_AREA',
    positionX: 1190,
    positionY: 1090,
    width: 520,
    height: 150,
    description: 'Trạm bảo dưỡng xe nâng Kalmar/Konecranes & sạc điện'
  }
];

export const initialBlocks: YardBlock[] = [
  {
    id: 'BLOCK_A',
    yardId: 'YARD_HN_01',
    zoneId: 'ZONE_STORAGE_A',
    blockCode: 'A',
    blockName: 'BLOCK A - DRY STANDARD',
    bayCount: 8,
    rowCount: 4,
    maxTier: 4,
    positionX: 65,
    positionY: 455,
    width: 480,
    height: 310,
    status: 'ACTIVE',
    description: 'Block chính chứa vỏ Dry 20GP và 40HC hãng tàu MSK & MSC',
    totalCapacity: 128,
    occupiedCount: 96,
    availableCount: 32,
    repairCount: 8,
    cleaningCount: 4,
    holdCount: 2
  },
  {
    id: 'BLOCK_B',
    yardId: 'YARD_HN_01',
    zoneId: 'ZONE_STORAGE_B',
    blockCode: 'B',
    blockName: 'BLOCK B - REEFER COLD CHAIN',
    bayCount: 8,
    rowCount: 4,
    maxTier: 4,
    positionX: 635,
    positionY: 455,
    width: 480,
    height: 310,
    status: 'ACTIVE',
    description: 'Block chuyên dụng container lạnh có ổ cắm PTI và giám sát nhiệt độ',
    totalCapacity: 128,
    occupiedCount: 84,
    availableCount: 44,
    repairCount: 5,
    cleaningCount: 6,
    holdCount: 3
  },
  {
    id: 'BLOCK_C',
    yardId: 'YARD_HN_01',
    zoneId: 'ZONE_STORAGE_C',
    blockCode: 'C',
    blockName: 'BLOCK C - EXPORT EMPTY',
    bayCount: 8,
    rowCount: 4,
    maxTier: 4,
    positionX: 1205,
    positionY: 455,
    width: 480,
    height: 310,
    status: 'ACTIVE',
    description: 'Block vỏ sạch xuất khẩu cho hãng ONE, CMA CGM và COSCO',
    totalCapacity: 128,
    occupiedCount: 110,
    availableCount: 18,
    repairCount: 2,
    cleaningCount: 3,
    holdCount: 1
  },
  {
    id: 'BLOCK_D',
    yardId: 'YARD_HN_01',
    zoneId: 'ZONE_STORAGE_D',
    blockCode: 'D',
    blockName: 'BLOCK D - 45HC & SPECIALS',
    bayCount: 8,
    rowCount: 4,
    maxTier: 4,
    positionX: 65,
    positionY: 895,
    width: 480,
    height: 310,
    status: 'ACTIVE',
    description: 'Block container 45HC, Open Top và Flat Rack chuyển tải cảng',
    totalCapacity: 128,
    occupiedCount: 62,
    availableCount: 66,
    repairCount: 4,
    cleaningCount: 2,
    holdCount: 4
  },
  {
    id: 'BLOCK_E',
    yardId: 'YARD_HN_01',
    zoneId: 'ZONE_STORAGE_E',
    blockCode: 'E',
    blockName: 'BLOCK E - BUFFER & FEEDER',
    bayCount: 8,
    rowCount: 4,
    maxTier: 4,
    positionX: 635,
    positionY: 895,
    width: 480,
    height: 310,
    status: 'ACTIVE',
    description: 'Block đệm chuyển tải sà lan sông và xe đầu kéo liên vùng',
    totalCapacity: 128,
    occupiedCount: 45,
    availableCount: 83,
    repairCount: 1,
    cleaningCount: 1,
    holdCount: 0
  }
];

export const initialContainers: YardContainer[] = [
  {
    id: 'CONT-01',
    containerNo: 'MSKU1234567',
    isoType: '40HC',
    size: '40',
    type: 'DRY',
    shippingLine: 'Maersk Line (MSK)',
    condition: 'DM',
    status: 'REPAIR',
    locationCode: 'A-05-03-02',
    blockId: 'BLOCK_A',
    bayNo: 5,
    rowNo: 3,
    tierNo: 2,
    tareWeightKg: 3820,
    maxPayloadKg: 28680,
    grossWeightKg: 32500,
    sealNo: 'ML-VN-9921',
    gateInDate: '2026-08-18 08:30',
    inspectionDate: '2026-08-18 08:45',
    repairDate: '2026-08-18 10:00',
    notes: 'Móp xà nóc & thủng vách phải - Đang chờ hàn đắp'
  },
  {
    id: 'CONT-02',
    containerNo: 'MSKU5555666',
    isoType: '40HC',
    size: '40',
    type: 'DRY',
    shippingLine: 'Maersk Line (MSK)',
    condition: 'AV',
    status: 'IN_YARD',
    locationCode: 'A-05-03-01',
    blockId: 'BLOCK_A',
    bayNo: 5,
    rowNo: 3,
    tierNo: 1,
    tareWeightKg: 3800,
    maxPayloadKg: 28700,
    gateInDate: '2026-08-17 14:15',
    inspectionDate: '2026-08-17 14:30',
    notes: 'Đã nghiệm thu AV Grade - Sẵn sàng bốc'
  },
  {
    id: 'CONT-03',
    containerNo: 'MSKU8888999',
    isoType: '40HC',
    size: '40',
    type: 'DRY',
    shippingLine: 'Maersk Line (MSK)',
    condition: 'CL',
    status: 'CLEANING',
    locationCode: 'A-05-03-03',
    blockId: 'BLOCK_A',
    bayNo: 5,
    rowNo: 3,
    tierNo: 3,
    tareWeightKg: 3850,
    maxPayloadKg: 28650,
    gateInDate: '2026-08-18 09:10',
    notes: 'Bám bẩn sàn dầu nhớt - Chờ rửa xà phòng'
  },
  {
    id: 'CONT-04',
    containerNo: 'MSCU7728192',
    isoType: '40RH',
    size: '40',
    type: 'REEFER',
    shippingLine: 'MSC',
    condition: 'AV',
    status: 'AVAILABLE',
    locationCode: 'B-03-02-01',
    blockId: 'BLOCK_B',
    bayNo: 3,
    rowNo: 2,
    tierNo: 1,
    tareWeightKg: 4200,
    maxPayloadKg: 28300,
    gateInDate: '2026-08-16 11:20',
    inspectionDate: '2026-08-16 11:40',
    notes: 'Container lạnh PTI Pass - Set temp -20°C'
  },
  {
    id: 'CONT-05',
    containerNo: 'MSCU9938120',
    isoType: '40RH',
    size: '40',
    type: 'REEFER',
    shippingLine: 'MSC',
    condition: 'DM',
    status: 'HOLD',
    holdReason: 'DAMAGE_HOLD',
    holdNotes: 'Hỏng máy nén lạnh Carrier & rò gas R134a - Nghiêm cấm cấp cho khách hàng đóng hoa quả',
    locationCode: 'B-03-02-02',
    blockId: 'BLOCK_B',
    bayNo: 3,
    rowNo: 2,
    tierNo: 2,
    tareWeightKg: 4220,
    maxPayloadKg: 28280,
    gateInDate: '2026-08-17 07:45',
    inspectionDate: '2026-08-17 08:00'
  },
  {
    id: 'CONT-06',
    containerNo: 'ONEY1928374',
    isoType: '20GP',
    size: '20',
    type: 'DRY',
    shippingLine: 'ONE (Ocean Network Express)',
    condition: 'AV',
    status: 'AVAILABLE',
    locationCode: 'C-01-01-01',
    blockId: 'BLOCK_C',
    bayNo: 1,
    rowNo: 1,
    tierNo: 1,
    tareWeightKg: 2200,
    maxPayloadKg: 28280,
    gateInDate: '2026-08-15 16:00'
  },
  {
    id: 'CONT-07',
    containerNo: 'ONEY5849201',
    isoType: '40HC',
    size: '40',
    type: 'DRY',
    shippingLine: 'ONE (Ocean Network Express)',
    condition: 'AV',
    status: 'RESERVED',
    locationCode: 'C-01-01-02',
    blockId: 'BLOCK_C',
    bayNo: 1,
    rowNo: 1,
    tierNo: 2,
    tareWeightKg: 3800,
    maxPayloadKg: 28700,
    destinationLocation: 'STAGING-01',
    gateInDate: '2026-08-16 10:00',
    notes: 'Booking EXP-ONE-88392 - Đã chỉ định bốc đóng hàng may mặc'
  },
  {
    id: 'CONT-08',
    containerNo: 'CMAU9918234',
    isoType: '40HC',
    size: '40',
    type: 'DRY',
    shippingLine: 'CMA CGM',
    condition: 'DM',
    status: 'REPAIR',
    locationCode: 'A-02-04-01',
    blockId: 'BLOCK_A',
    bayNo: 2,
    rowNo: 4,
    tierNo: 1,
    tareWeightKg: 3820,
    maxPayloadKg: 28680,
    gateInDate: '2026-08-17 10:20',
    repairDate: '2026-08-18 08:00',
    notes: 'Hỏng gioăng cửa & rách vách trái'
  },
  {
    id: 'CONT-09',
    containerNo: 'COSU6629102',
    isoType: '20GP',
    size: '20',
    type: 'DRY',
    shippingLine: 'COSCO Shipping',
    condition: 'DM',
    status: 'HOLD',
    holdReason: 'CUSTOMS_HOLD',
    holdNotes: 'Chi cục Hải quan Depot yêu cầu niêm phong phục vụ chuyên án soi chiếu',
    locationCode: 'D-04-02-01',
    blockId: 'BLOCK_D',
    bayNo: 4,
    rowNo: 2,
    tierNo: 1,
    tareWeightKg: 2240,
    maxPayloadKg: 28240,
    gateInDate: '2026-08-14 09:00'
  },
  {
    id: 'CONT-10',
    containerNo: 'EMCU4459201',
    isoType: '40HC',
    size: '40',
    type: 'DRY',
    shippingLine: 'Evergreen Marine (EMC)',
    condition: 'AV',
    status: 'AVAILABLE',
    locationCode: 'C-04-03-01',
    blockId: 'BLOCK_C',
    bayNo: 4,
    rowNo: 3,
    tierNo: 1,
    tareWeightKg: 3810,
    maxPayloadKg: 28690,
    gateInDate: '2026-08-17 15:30'
  },
  {
    id: 'CONT-11',
    containerNo: 'HMMU3391820',
    isoType: '45HC',
    size: '45',
    type: 'DRY',
    shippingLine: 'HMM (Hyundai Merchant Marine)',
    condition: 'AV',
    status: 'IN_YARD',
    locationCode: 'D-01-01-01',
    blockId: 'BLOCK_D',
    bayNo: 1,
    rowNo: 1,
    tierNo: 1,
    tareWeightKg: 4500,
    maxPayloadKg: 28000,
    gateInDate: '2026-08-16 08:00'
  },
  {
    id: 'CONT-12',
    containerNo: 'HLXU8829104',
    isoType: '40HC',
    size: '40',
    type: 'DRY',
    shippingLine: 'Hapag-Lloyd',
    condition: 'AV',
    status: 'WAITING_GATE_OUT',
    locationCode: 'STAGING-02',
    blockId: 'STAGING',
    bayNo: 1,
    rowNo: 2,
    tierNo: 1,
    tareWeightKg: 3820,
    maxPayloadKg: 28680,
    gateInDate: '2026-08-15 10:00',
    notes: 'Tài xế xe đầu kéo 29H-88392 đang qua trạm cân'
  },
  {
    id: 'CONT-13',
    containerNo: 'MSKU9948201',
    isoType: '40HC',
    size: '40',
    type: 'DRY',
    shippingLine: 'Maersk Line (MSK)',
    condition: 'DM',
    status: 'HOLD',
    holdReason: 'PAYMENT_HOLD',
    holdNotes: 'Chưa thanh toán phí nâng hạ và lưu bãi 12 ngày (Nợ 1.850.000 VNĐ)',
    locationCode: 'A-01-02-01',
    blockId: 'BLOCK_A',
    bayNo: 1,
    rowNo: 2,
    tierNo: 1,
    tareWeightKg: 3800,
    maxPayloadKg: 28700,
    gateInDate: '2026-08-05 14:00'
  }
];

export const initialForklifts: Forklift[] = [
  {
    id: 'FL-01',
    code: 'FL-001',
    name: 'Xe Nâng Kalmar 45T (#01)',
    status: 'AVAILABLE',
    currentLocation: 'A-03-02',
    positionX: 380,
    positionY: 340,
    driverName: 'Nguyễn Văn Hùng',
    driverPhone: '0912.345.678',
    batteryPercent: 88,
    maxCapacityTons: 45,
    currentTask: 'Sẵn sàng điều độ bốc hạ vỏ'
  },
  {
    id: 'FL-02',
    code: 'FL-002',
    name: 'Xe Nâng Konecranes 42T (#02)',
    status: 'MOVING',
    currentLocation: 'B-05-01',
    positionX: 950,
    positionY: 340,
    targetPositionX: 1350,
    targetPositionY: 340,
    driverName: 'Trần Đình Nam',
    driverPhone: '0988.765.432',
    batteryPercent: 72,
    maxCapacityTons: 42,
    currentTask: 'Đang chuyển vỏ MSCU7728192 sang Block C'
  },
  {
    id: 'FL-03',
    code: 'FL-003',
    name: 'Xe Nâng Chụp Rỗng Hyster 10T (#03)',
    status: 'AVAILABLE',
    currentLocation: 'FORKLIFT_PAD',
    positionX: 1350,
    positionY: 1140,
    driverName: 'Lê Hoàng Anh',
    driverPhone: '0903.112.233',
    batteryPercent: 95,
    maxCapacityTons: 10,
    currentTask: 'Đậu tại xưởng bảo trì xe nâng'
  }
];

export const initialDispatches: ForkliftDispatch[] = [
  {
    id: 'DISP-01',
    dispatchNo: 'DISP-2026-001',
    forkliftId: 'FL-02',
    forkliftCode: 'FL-002',
    containerId: 'CONT-01',
    containerNo: 'MSKU1234567',
    fromLocation: 'A-01-02-01',
    toLocation: 'A-05-03-02',
    dispatchedAt: '2026-08-18 09:30',
    status: 'COMPLETED',
    driverName: 'Trần Đình Nam',
    priority: 'NORMAL'
  },
  {
    id: 'DISP-02',
    dispatchNo: 'DISP-2026-002',
    forkliftId: 'FL-01',
    forkliftCode: 'FL-001',
    containerId: 'CONT-07',
    containerNo: 'ONEY5849201',
    fromLocation: 'C-01-01-02',
    toLocation: 'STAGING-01',
    dispatchedAt: '2026-08-18 10:15',
    status: 'MOVING',
    driverName: 'Nguyễn Văn Hùng',
    priority: 'URGENT'
  }
];

export const initialMoveHistories: YardMoveHistory[] = [
  {
    id: 'HIST-01',
    containerId: 'CONT-01',
    containerNo: 'MSKU1234567',
    fromLocation: 'INSPECTION-PAD',
    toLocation: 'A-01-02-01',
    moveDate: '2026-08-18 08:50',
    forkliftId: 'FL-01',
    forkliftCode: 'FL-001',
    userId: 'USR-001',
    userName: 'Nguyễn Văn Hùng',
    reason: 'Hạ bãi sau khi hoàn tất giám định IICL'
  },
  {
    id: 'HIST-02',
    containerId: 'CONT-01',
    containerNo: 'MSKU1234567',
    fromLocation: 'A-01-02-01',
    toLocation: 'A-05-03-02',
    moveDate: '2026-08-18 09:30',
    forkliftId: 'FL-02',
    forkliftCode: 'FL-002',
    userId: 'USR-003',
    userName: 'Lê Hoàng Nam',
    reason: 'Đảo chuyển sang khu vực chờ sửa chữa Block A Bay 05'
  },
  {
    id: 'HIST-03',
    containerId: 'CONT-04',
    containerNo: 'MSCU7728192',
    fromLocation: 'GATE-IN-LANE1',
    toLocation: 'B-03-02-01',
    moveDate: '2026-08-16 11:35',
    forkliftId: 'FL-01',
    forkliftCode: 'FL-001',
    userId: 'USR-001',
    userName: 'Nguyễn Văn Hùng',
    reason: 'Hạ bãi cắm điện trạm lạnh Reefer Block B'
  }
];

export const initialGateLanes: YardGateLane[] = [
  {
    id: 'LANE-IN-01',
    laneNo: 1,
    gateType: 'IN',
    laneName: 'Làn Vào 01 (Xe Tải Nặng / Cân Điện Tử)',
    hasOcr: true,
    hasRfid: true,
    hasWeighbridge: true,
    status: 'BUSY',
    currentTruckPlate: '51D-892.12',
    currentContainerNo: 'MSKU9938120'
  },
  {
    id: 'LANE-IN-02',
    laneNo: 2,
    gateType: 'IN',
    laneName: 'Làn Vào 02 (Tự Động Smart OCR)',
    hasOcr: true,
    hasRfid: true,
    hasWeighbridge: false,
    status: 'OPEN'
  },
  {
    id: 'LANE-IN-03',
    laneNo: 3,
    gateType: 'IN',
    laneName: 'Làn Vào 03 (Ưu Tiên Cont Rỗng)',
    hasOcr: true,
    hasRfid: true,
    hasWeighbridge: false,
    status: 'OPEN'
  },
  {
    id: 'LANE-OUT-01',
    laneNo: 1,
    gateType: 'OUT',
    laneName: 'Làn Xuất 01 (Kiểm Soát Seal & EDO)',
    hasOcr: true,
    hasRfid: true,
    hasWeighbridge: true,
    status: 'BUSY',
    currentTruckPlate: '29H-883.92',
    currentContainerNo: 'HLXU8829104'
  },
  {
    id: 'LANE-OUT-02',
    laneNo: 2,
    gateType: 'OUT',
    laneName: 'Làn Xuất 02 (Cấp Vỏ Nhanh)',
    hasOcr: true,
    hasRfid: true,
    hasWeighbridge: false,
    status: 'OPEN'
  }
];

// Fallback in-memory state store in client
let localState = {
  zones: [...initialZones],
  blocks: [...initialBlocks],
  containers: [...initialContainers],
  locations: [] as YardLocationEntity[],
  forklifts: [...initialForklifts],
  dispatches: [...initialDispatches],
  histories: [...initialMoveHistories],
  gateLanes: [...initialGateLanes]
};

// Generate initial locations for all blocks
initialBlocks.forEach((block) => {
  for (let bay = 1; bay <= block.bayCount; bay++) {
    for (let row = 1; row <= block.rowCount; row++) {
      for (let tier = 1; tier <= block.maxTier; tier++) {
        const bCode = block.blockCode;
        const posCode = `${bCode}-${String(bay).padStart(2, '0')}-${String(row).padStart(2, '0')}-${String(tier).padStart(2, '0')}`;
        const cont = localState.containers.find((c) => c.locationCode === posCode);
        localState.locations.push({
          id: `LOC-${posCode}`,
          yardId: block.yardId,
          zoneId: block.zoneId,
          blockId: block.id,
          bayNo: bay,
          rowNo: row,
          tierNo: tier,
          positionCode: posCode,
          containerId: cont?.id || null,
          containerNo: cont?.containerNo || null,
          status: cont ? 'OCCUPIED' : 'AVAILABLE',
          isOccupied: Boolean(cont),
          isReserved: cont?.status === 'RESERVED',
          createdAt: '2026-08-17 00:00',
          updatedAt: '2026-08-17 00:00'
        });
      }
    }
  }
});

export const yardApi = {
  async getYardOverview(): Promise<YardFullResponse> {
    try {
      const res = await axios.get(`${API_BASE}`);
      if (
        res.data?.data &&
        Array.isArray(res.data.data.zones) &&
        Array.isArray(res.data.data.blocks) &&
        Array.isArray(res.data.data.containers)
      ) {
        return {
          zones: res.data.data.zones || localState.zones,
          blocks: res.data.data.blocks || localState.blocks,
          containers: res.data.data.containers || localState.containers,
          locations: res.data.data.locations || localState.locations,
          forklifts: res.data.data.forklifts || localState.forklifts,
          dispatches: res.data.data.dispatches || localState.dispatches,
          gateLanes: res.data.data.gateLanes || localState.gateLanes,
          statistics: res.data.data.statistics || {
            totalCapacity: localState.blocks.reduce((sum, b) => sum + b.totalCapacity, 0),
            totalContainers: localState.containers.length,
            availableSlots: localState.blocks.reduce((sum, b) => sum + b.totalCapacity, 0) - localState.containers.length,
            occupancyRate: 2.0,
            repairCount: 2,
            cleaningCount: 1,
            holdCount: 3,
            waitingGateInCount: 1,
            waitingGateOutCount: 1,
            activeForklifts: 3
          }
        };
      }
    } catch {
      // Use local state
    }

    const totalContainers = (localState.containers || []).filter(
      (c) => c.status !== 'GATE_OUT_COMPLETED' && c.status !== 'WAITING_GATE_IN'
    ).length;
    const totalCapacity = (localState.blocks || []).reduce((sum, b) => sum + b.totalCapacity, 0);
    const availableSlots = Math.max(0, totalCapacity - totalContainers);
    const occupancyRate = totalCapacity > 0 ? Number(((totalContainers / totalCapacity) * 100).toFixed(1)) : 0;

    const repairCount = (localState.containers || []).filter((c) => c.status === 'REPAIR').length;
    const cleaningCount = (localState.containers || []).filter((c) => c.status === 'CLEANING').length;
    const holdCount = (localState.containers || []).filter((c) => c.status === 'HOLD').length;
    const waitingGateInCount = (localState.containers || []).filter((c) => c.status === 'WAITING_GATE_IN').length;
    const waitingGateOutCount = (localState.containers || []).filter((c) => c.status === 'WAITING_GATE_OUT').length;
    const activeForklifts = (localState.forklifts || []).filter((f) => f.status === 'AVAILABLE' || f.status === 'MOVING').length;

    return {
      zones: localState.zones || [],
      blocks: localState.blocks || [],
      containers: localState.containers || [],
      locations: localState.locations || [],
      forklifts: localState.forklifts || [],
      dispatches: localState.dispatches || [],
      gateLanes: localState.gateLanes || [],
      statistics: {
        totalCapacity,
        totalContainers,
        availableSlots,
        occupancyRate,
        repairCount,
        cleaningCount,
        holdCount,
        waitingGateInCount,
        waitingGateOutCount,
        activeForklifts
      }
    };
  },

  async searchContainers(query: string): Promise<YardContainer[]> {
    try {
      const res = await axios.get(`${API_BASE}/containers/search`, {
        params: { containerNo: query }
      });
      if (res.data?.data) {
        return res.data.data;
      }
    } catch {
      // Fallback local search
    }
    const q = query.trim().toUpperCase();
    if (!q) return [];
    return localState.containers.filter(
      (c) =>
        c.containerNo.toUpperCase().includes(q) ||
        c.locationCode.toUpperCase().includes(q) ||
        c.shippingLine.toUpperCase().includes(q)
    );
  },

  async getContainerById(id: string): Promise<YardContainer | null> {
    try {
      const res = await axios.get(`${API_BASE}/containers/${id}`);
      if (res.data?.data) return res.data.data;
    } catch {
      // Fallback
    }
    return localState.containers.find((c) => c.id === id || c.containerNo === id) || null;
  },

  async getMoveHistories(containerId?: string): Promise<YardMoveHistory[]> {
    try {
      const res = await axios.get(`${API_BASE}/history`, {
        params: { containerId }
      });
      if (res.data?.data) return res.data.data;
    } catch {
      // Fallback
    }
    if (containerId) {
      return localState.histories.filter((h) => h.containerId === containerId || h.containerNo === containerId);
    }
    return localState.histories;
  },

  async moveContainer(payload: {
    containerId: string;
    targetLocation: string; // e.g. "A-02-03-01"
    forkliftId?: string;
    reason: string;
    operatorName?: string;
  }): Promise<{ success: boolean; message: string; container?: YardContainer }> {
    try {
      const res = await axios.post(`${API_BASE}/container/move`, payload);
      if (res.data?.data) return { success: true, message: res.data.message || 'Di chuyển thành công', container: res.data.data };
    } catch (err: any) {
      if (err?.response?.data?.message) {
        return { success: false, message: err.response.data.message };
      }
    }

    // Local execution with full validation
    const container = localState.containers.find(
      (c) => c.id === payload.containerId || c.containerNo === payload.containerId
    );
    if (!container) {
      return { success: false, message: 'Không tìm thấy Container trong hệ thống' };
    }

    if (container.status === 'HOLD') {
      return {
        success: false,
        message: `Container đang ở trạng thái HOLD (${container.holdReason || 'Tạm giữ'}). Nghiêm cấm điều chuyển khi chưa giải tỏa!`
      };
    }

    // Check target location format
    const parts = payload.targetLocation.toUpperCase().split('-');
    if (parts.length < 4) {
      return { success: false, message: 'Định dạng mã vị trí không hợp lệ (Chuẩn: BLOCK-BAY-ROW-TIER)' };
    }

    const blockCode = parts[0];
    const bayNo = parseInt(parts[1], 10);
    const rowNo = parseInt(parts[2], 10);
    const tierNo = parseInt(parts[3], 10);

    const block = localState.blocks.find((b) => b.blockCode === blockCode);
    if (!block) {
      return { success: false, message: `Block ${blockCode} không tồn tại trong sơ đồ bãi` };
    }

    if (tierNo > block.maxTier) {
      return { success: false, message: `Vị trí vượt quá giới hạn tầng cao nhất của Block (Max: ${block.maxTier} Tiers)` };
    }

    // Check if slot already occupied
    const existingCont = localState.containers.find(
      (c) => c.locationCode === payload.targetLocation && c.id !== container.id
    );
    if (existingCont) {
      return {
        success: false,
        message: `Vị trí ${payload.targetLocation} đã có container ${existingCont.containerNo} chiếm giữ!`
      };
    }

    const fromLoc = container.locationCode;
    const forklift = localState.forklifts.find((f) => f.id === payload.forkliftId) || localState.forklifts[0];

    // Update container
    container.locationCode = payload.targetLocation;
    container.blockId = block.id;
    container.bayNo = bayNo;
    container.rowNo = rowNo;
    container.tierNo = tierNo;

    // Record history
    const newHist: YardMoveHistory = {
      id: `HIST-${Date.now()}`,
      containerId: container.id,
      containerNo: container.containerNo,
      fromLocation: fromLoc,
      toLocation: payload.targetLocation,
      moveDate: new Date().toISOString().replace('T', ' ').substring(0, 16),
      forkliftId: forklift.id,
      forkliftCode: forklift.code,
      userId: 'USR-001',
      userName: payload.operatorName || 'Nguyễn Văn Hùng (Điều Độ Bãi)',
      reason: payload.reason || 'Điều chuyển vị trí theo kế hoạch xếp bãi'
    };
    localState.histories.unshift(newHist);

    // Update location occupancy
    localState.locations.forEach((loc) => {
      if (loc.positionCode === fromLoc) {
        loc.containerId = null;
        loc.containerNo = null;
        loc.status = 'AVAILABLE';
        loc.isOccupied = false;
      }
      if (loc.positionCode === payload.targetLocation) {
        loc.containerId = container.id;
        loc.containerNo = container.containerNo;
        loc.status = 'OCCUPIED';
        loc.isOccupied = true;
      }
    });

    return {
      success: true,
      message: `Đã di chuyển Container ${container.containerNo} từ ${fromLoc} tới ${payload.targetLocation} thành công!`,
      container
    };
  },

  async dispatchForklift(payload: {
    forkliftId: string;
    containerId: string;
    targetLocation: string;
    priority?: 'NORMAL' | 'URGENT' | 'HIGH';
  }): Promise<{ success: boolean; message: string; dispatch?: ForkliftDispatch }> {
    try {
      const res = await axios.post(`${API_BASE}/forklift/dispatch`, payload);
      if (res.data?.data) return { success: true, message: res.data.message || 'Phát lệnh điều xe nâng thành công', dispatch: res.data.data };
    } catch {
      // Local fallback
    }

    const fl = localState.forklifts.find((f) => f.id === payload.forkliftId);
    const cont = localState.containers.find((c) => c.id === payload.containerId || c.containerNo === payload.containerId);

    if (!fl || !cont) {
      return { success: false, message: 'Xe nâng hoặc Container không hợp lệ' };
    }

    if (cont.status === 'HOLD') {
      return { success: false, message: `Container ${cont.containerNo} đang bị HOLD (${cont.holdReason}). Không thể phát lệnh di chuyển!` };
    }

    const newDisp: ForkliftDispatch = {
      id: `DISP-${Date.now()}`,
      dispatchNo: `DISP-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`,
      forkliftId: fl.id,
      forkliftCode: fl.code,
      containerId: cont.id,
      containerNo: cont.containerNo,
      fromLocation: cont.locationCode,
      toLocation: payload.targetLocation,
      dispatchedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
      status: 'MOVING',
      driverName: fl.driverName,
      priority: payload.priority || 'NORMAL'
    };

    localState.dispatches.unshift(newDisp);
    fl.status = 'MOVING';
    fl.currentTask = `Đang chuyển Cont ${cont.containerNo} từ ${cont.locationCode} sang ${payload.targetLocation}`;

    return {
      success: true,
      message: `Đã phát lệnh điều xe nâng ${fl.code} (${fl.driverName}) di chuyển Container ${cont.containerNo}!`,
      dispatch: newDisp
    };
  }
};
