export const API_BASE_URL = (import.meta as any).env?.VITE_API_BASE_URL || '/api';

export const API_ENDPOINTS = {
  AUTH: {
    LOGIN: '/Users/authenticate',
    REFRESH_TOKEN: '/auth/refresh-token',
    ME: '/auth/me',
  },
  DEPOT_JOBS: {
    BASE: '/DepotJobs',
    STATS: '/DepotJobs/stats',
    GET_BY_ID: (id: string) => `/DepotJobs/${id}`,
    GATE_IN: '/DepotJobs/gate-in',
    SURVEY: (id: string) => `/DepotJobs/${id}/survey`,
    ESTIMATE: (id: string) => `/DepotJobs/${id}/estimate`,
    APPROVE_ESTIMATE: (id: string, approverName = "Hãng Tàu Phê Duyệt") =>
      `/DepotJobs/${id}/approve-estimate?approverName=${encodeURIComponent(approverName)}`,
    QC_COMPLETE: (id: string) => `/DepotJobs/${id}/qc-complete`,
    FORKLIFT_MOVE: '/DepotJobs/forklift-move',
    REPAIR_ASSIGN: (id: string) => `/depot/jobs/${id}/repair/assign`,
    REPAIR_COMPLETE: (id: string) => `/depot/jobs/${id}/repair/complete`,
  },
  MASTER_DATA: {
    SHIPPING_LINES: '/MasterData/shipping-lines',
    MATERIALS: '/MasterData/materials',
  },
  WEBHOOKS: {
    BANK_VIETQR: '/Webhooks/bank-vietqr',
    PAYMENT: '/Webhooks/payment',
  },
  SYSTEM: {
    USERS: '/system/users',
    USER_BY_ID: (id: string) => `/system/users/${id}`,
    ROLES: '/system/roles',
    PERMISSIONS: '/system/permissions',
    MENUS: '/system/menus',
  },
  REPORTS: {
    KPI: '/reports/kpi',
    EXPORT_EXCEL: '/reports/export-excel',
    DASHBOARD_OVERVIEW: '/dashboard/overview',
  },
};
