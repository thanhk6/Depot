import apiClient from './axios';
import { API_ENDPOINTS } from './endpoints';
import { ApiResponse } from '../types/common';
import { SurveyRecord } from '../types/container';

export const surveyApi = {
  submitSurvey: async (jobId: string, survey: SurveyRecord) => {
    const res = await apiClient.post<ApiResponse<SurveyRecord>>(API_ENDPOINTS.DEPOT_JOBS.SURVEY(jobId), survey);
    return res.data;
  },
};

