import { authApi } from '../api/auth.api';
import { tokenService } from './token.service';
import { User } from '../types/auth';

export const authService = {
  login: async (username: string, passwordHash: string) => {
    const response = await authApi.login({ username, password: passwordHash, passwordHash });
    if (response.data) {
      tokenService.setAccessToken(`token_${Date.now()}`);
      tokenService.setRefreshToken(`refresh_${Date.now()}`);
      return response.data as User;
    }
    throw new Error(response.message || 'Login failed');
  },
  logout: () => {
    tokenService.clearTokens();
  },
  getCurrentUser: async (): Promise<User | null> => {
    try {
      const response = await authApi.getProfile();
      return (response.data as User) || null;
    } catch {
      return null;
    }
  },
};
