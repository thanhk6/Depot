import React, { useState, useEffect } from 'react';
import { ContainerRecord } from '../../../services/mockDataStore';
import { WorkOrderRecord } from '../types/repair';
import { generateWorkOrdersFromContainers } from '../data/initialWorkOrders';
import { WorkOrderList } from '../components/WorkOrderList';
import { WorkOrderDetailView } from '../components/WorkOrderDetailView';

interface RepairPageProps {
  containers: ContainerRecord[];
  onCompleteRepair: (containerId: string) => void;
  onNavigateTab: (tabId: string) => void;
}

export const RepairPage: React.FC<RepairPageProps> = ({
  containers,
  onCompleteRepair,
  onNavigateTab
}) => {
  // Initialize Work Orders from containers
  const [workOrders, setWorkOrders] = useState<WorkOrderRecord[]>(() =>
    generateWorkOrdersFromContainers(containers)
  );

  const [selectedWorkOrderId, setSelectedWorkOrderId] = useState<string | null>(null);

  // Sync when containers update (e.g. when an estimate gets approved)
  useEffect(() => {
    setWorkOrders((prev) => {
      const regenerated = generateWorkOrdersFromContainers(containers);
      // Merge with existing local edits if any
      return regenerated.map((rg) => {
        const existing = prev.find((p) => p.id === rg.id || p.containerNo === rg.containerNo);
        if (existing) {
          // Keep existing items progress if user worked on it
          return {
            ...rg,
            status: existing.status !== 'WAITING' ? existing.status : rg.status,
            items: existing.items,
            additionalReports: existing.additionalReports
          };
        }
        return rg;
      });
    });
  }, [containers]);

  const selectedWorkOrder = workOrders.find((w) => w.id === selectedWorkOrderId);

  // Handler to update a work order locally
  const handleUpdateWorkOrder = (updated: WorkOrderRecord) => {
    setWorkOrders((prev) => prev.map((w) => (w.id === updated.id ? updated : w)));
  };

  // Handler when Work Order is finished and sent to QC
  const handleCompleteWorkOrder = (workOrderId: string, containerId: string) => {
    onCompleteRepair(containerId);
  };

  return (
    <div className="space-y-6">
      {selectedWorkOrder ? (
        <WorkOrderDetailView
          workOrder={selectedWorkOrder}
          onBack={() => setSelectedWorkOrderId(null)}
          onUpdateWorkOrder={handleUpdateWorkOrder}
          onCompleteWorkOrder={handleCompleteWorkOrder}
          onNavigateTab={onNavigateTab}
        />
      ) : (
        <WorkOrderList
          workOrders={workOrders}
          onSelectWorkOrder={(wo) => setSelectedWorkOrderId(wo.id)}
          onNavigateTab={onNavigateTab}
        />
      )}
    </div>
  );
};
