import React, { useState, useMemo } from 'react';
import {
  X,
  Droplets,
  Container as ContainerIcon,
  Sparkles,
  Building,
  User,
  Plus,
  Clock,
  ShieldCheck,
  Box,
  Layers,
  ThermometerSnowflake,
  Info
} from 'lucide-react';
import { CleaningExecutionRecord, CleaningWorkItem } from '../types';
import { ContainerTypeMasterItem } from '../../survey/types';
import { INITIAL_CONTAINER_TYPES } from '../../survey/mockData';

interface NewCleaningIntakeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddCleaningOrder: (order: CleaningExecutionRecord) => void;
  containerTypes?: ContainerTypeMasterItem[];
}

export const NewCleaningIntakeModal: React.FC<NewCleaningIntakeModalProps> = ({
  isOpen,
  onClose,
  onAddCleaningOrder,
  containerTypes = INITIAL_CONTAINER_TYPES
}) => {
  const [containerNo, setContainerNo] = useState('');
  const [selectedTypeCode, setSelectedTypeCode] = useState<string>('40HC');
  const [shippingLine, setShippingLine] = useState('MAERSK');
  const [cleaningBay, setCleaningBay] = useState('CLEANING-BAY-01 (Trạm Xịt Rửa Áp Lực Cao)');
  const [cleaningStaff, setCleaningStaff] = useState('Nguyễn Văn Hùng (Tổ Vệ Sinh)');
  const [targetGrade, setTargetGrade] = useState<'GRADE_A' | 'FOOD_GRADE' | 'GENERAL_CARGO' | 'SCRAP_GRADE'>('GRADE_A');
  const [selectedPresetServices, setSelectedPresetServices] = useState<string[]>([
    'SW',
    'WW'
  ]);
  const [notes, setNotes] = useState('');

  // Selected container item from Master Data Catalog
  const selectedContainerType = useMemo(() => {
    return (
      containerTypes.find((ct) => ct.typeCode === selectedTypeCode) ||
      containerTypes[0] || {
        id: 'cnt_40hc',
        typeCode: '40HC',
        isoCode: '45G1',
        name: '40ft High Cube Dry Container',
        vietnameseName: 'Container Khô 40 Feet Cao (40HC)',
        size: '40' as const,
        category: 'DRY' as const,
        isReefer: false,
        lengthMm: 12192,
        widthMm: 2438,
        heightMm: 2896,
        internalLengthMm: 12032,
        internalWidthMm: 2352,
        internalHeightMm: 2698,
        doorWidthMm: 2340,
        doorHeightMm: 2585,
        cbm: 76.4,
        tareWeightKg: 3900,
        maxPayloadKg: 28600,
        maxGrossWeightKg: 32500,
        teuRatio: 2,
        material: 'CORTEN_STEEL' as const,
        floorType: 'WOOD_PLYWOOD' as const,
        description: '40ft HC',
        status: 'ACTIVE' as const,
        sortOrder: 3
      }
    );
  }, [containerTypes, selectedTypeCode]);

  // Group container types by category for the select dropdown
  const groupedContainerTypes = useMemo(() => {
    const dry = containerTypes.filter((t) => t.category === 'DRY');
    const reefer = containerTypes.filter((t) => t.category === 'REEFER' || t.isReefer);
    const openTop = containerTypes.filter((t) => t.category === 'OPEN_TOP');
    const flatRack = containerTypes.filter((t) => t.category === 'FLAT_RACK');
    const tank = containerTypes.filter((t) => t.category === 'TANK');
    const other = containerTypes.filter(
      (t) => !['DRY', 'REEFER', 'OPEN_TOP', 'FLAT_RACK', 'TANK'].includes(t.category) && !t.isReefer
    );

    return { dry, reefer, openTop, flatRack, tank, other };
  }, [containerTypes]);

  if (!isOpen) return null;

  const handleToggleService = (code: string) => {
    setSelectedPresetServices((prev) =>
      prev.includes(code) ? prev.filter((c) => c !== code) : [...prev, code]
    );
  };

  const servicePresets: { code: string; name: string; price: number; chem: boolean }[] = [
    { code: 'SW', name: 'Quét dọn rác dunnage & bao bì cũ (Sweeping)', price: 100000, chem: false },
    { code: 'WW', name: 'Xịt rửa nước áp lực cao 200 Bar (Water Wash)', price: 200000, chem: false },
    { code: 'CW', name: 'Rửa hóa chất kiềm D-30 tẩy dầu mỡ sàn & vách', price: 350000, chem: true },
    { code: 'DO', name: 'Xông nhiệt & xử lý khử mùi Ozone thực phẩm (Deodorize)', price: 300000, chem: true },
    { code: 'WF', name: 'Đánh chà sàn gỗ & sấy quạt khô tiêu chuẩn xuất khẩu', price: 280000, chem: false },
    { code: 'SR', name: 'Cạo bóc tem nhãn IMO & tẩy keo dính vách (Sticker Removal)', price: 180000, chem: true }
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!containerNo.trim()) return;

    const timestamp = new Date().toISOString().substring(0, 16).replace('T', ' ');
    const items: CleaningWorkItem[] = selectedPresetServices.map((code) => {
      const p = servicePresets.find((s) => s.code === code);
      return {
        id: 'CIT-' + Math.random().toString(36).substring(2, 7).toUpperCase(),
        cleaningCode: code,
        cleaningName: p ? p.name : code,
        chemicalRequired: p ? p.chem : false,
        chemicalName: p?.chem ? 'Alkaline D-30' : undefined,
        estimatedDurationMin: 25,
        unitPrice: p ? p.price : 200000,
        totalPrice: p ? p.price : 200000,
        responsibleParty: 'U',
        isCompleted: false
      };
    });

    const totalCost = items.reduce((acc, curr) => acc + curr.totalPrice, 0);

    const newOrder: CleaningExecutionRecord = {
      id: 'CLN-2026-' + Math.random().toString(36).substring(2, 6).toUpperCase(),
      containerId: 'CONT-' + Math.random().toString(36).substring(2, 6).toUpperCase(),
      containerNo: containerNo.trim().toUpperCase(),
      isoCode: selectedContainerType.isoCode,
      size: `${selectedContainerType.typeCode}`,
      type: selectedContainerType.vietnameseName || selectedContainerType.name,
      shippingLine,
      owner: shippingLine,
      surveyNo: 'SRV-INTAKE-' + Math.random().toString(36).substring(2, 6).toUpperCase(),
      eeirNo: 'EIR-' + containerNo.trim().toUpperCase().substring(0, 4) + '-' + Math.floor(1000 + Math.random() * 9000),
      cleaningBay,
      status: 'PENDING_CLEANING',
      surveyCondition: 'CL',
      cleaningStaff,
      waterPressureBar: 200,
      chemicalUsed: 'Alkaline D-30 & Dung dịch chuyên dụng',
      chemicalVolumeLiters: 2.0,
      temperatureCelsius: 60,
      targetQualityGrade: targetGrade,
      beforeCleaningPhoto: 'https://images.unsplash.com/photo-1541888946425-d0fbb186a5b3?auto=format&fit=crop&w=800&q=80',
      beforePhotoTimestamp: timestamp,
      afterCleaningPhoto: 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&w=800&q=80',
      afterPhotoTimestamp: '',
      items,
      totalCost,
      cleaningNotes: notes || `Tiếp nhận vỏ ${selectedContainerType.typeCode} [${selectedContainerType.isoCode}] vào bệ rửa theo danh mục loại container.`
    };

    onAddCleaningOrder(newOrder);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-2xl w-full space-y-6 shadow-2xl animate-scale-up max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 rounded-xl">
              <Droplets className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-white">Tiếp Nhận Container Vào Bệ Rửa (Cleaning Intake)</h3>
              <p className="text-xs text-slate-400">Tạo lệnh vệ sinh vỏ mới đồng bộ với Danh Mục Loại Container (ISO 6346)</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block font-bold text-slate-300 mb-1">Số Container No (11 ký tự ISO)*</label>
              <input
                type="text"
                required
                value={containerNo}
                onChange={(e) => setContainerNo(e.target.value.toUpperCase())}
                placeholder="VD: TCLU1234567"
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl font-mono text-white text-xs focus:outline-none focus:border-cyan-500 uppercase"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-300 mb-1">Hãng Tàu / Chủ Vỏ</label>
              <select
                value={shippingLine}
                onChange={(e) => setShippingLine(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white text-xs focus:outline-none focus:border-cyan-500"
              >
                <option value="MAERSK">MAERSK LINE</option>
                <option value="CMA CGM">CMA CGM</option>
                <option value="COSCO">COSCO SHIPPING</option>
                <option value="ONE">ONE (Ocean Network Express)</option>
                <option value="EVERGREEN">EVERGREEN MARINE</option>
                <option value="HAPAG-LLOYD">HAPAG-LLOYD</option>
                <option value="MSC">MSC (Mediterranean Shipping)</option>
                <option value="YANG MING">YANG MING</option>
                <option value="WAN HAI">WAN HAI LINES</option>
              </select>
            </div>

            {/* Container Type Select directly from Master Data Catalog */}
            <div className="sm:col-span-2 space-y-2">
              <div className="flex items-center justify-between">
                <label className="block font-bold text-cyan-300 text-xs flex items-center gap-1.5">
                  <ContainerIcon className="w-4 h-4 text-cyan-400" />
                  <span>Loại Container (Lấy từ Danh mục ISO-6346)*</span>
                </label>
                <span className="text-[11px] text-slate-400">
                  {containerTypes.length} loại quy cách chuẩn
                </span>
              </div>

              <select
                value={selectedTypeCode}
                onChange={(e) => setSelectedTypeCode(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-950 border border-cyan-500/50 rounded-xl text-white font-bold text-xs focus:outline-none focus:border-cyan-400 ring-1 ring-cyan-500/30"
              >
                {groupedContainerTypes.dry.length > 0 && (
                  <optgroup label="📦 CONTAINER KHÔ (DRY GENERAL / HIGH CUBE)">
                    {groupedContainerTypes.dry.map((ct) => (
                      <option key={ct.id || ct.typeCode} value={ct.typeCode}>
                        {ct.typeCode} - {ct.vietnameseName} [Mã ISO: {ct.isoCode}]
                      </option>
                    ))}
                  </optgroup>
                )}

                {groupedContainerTypes.reefer.length > 0 && (
                  <optgroup label="❄️ CONTAINER LẠNH (REEFER / CONTROLLED TEMP)">
                    {groupedContainerTypes.reefer.map((ct) => (
                      <option key={ct.id || ct.typeCode} value={ct.typeCode}>
                        {ct.typeCode} - {ct.vietnameseName} [Mã ISO: {ct.isoCode}]
                      </option>
                    ))}
                  </optgroup>
                )}

                {groupedContainerTypes.openTop.length > 0 && (
                  <optgroup label="🏗️ CONTAINER MỞ NÓC (OPEN TOP)">
                    {groupedContainerTypes.openTop.map((ct) => (
                      <option key={ct.id || ct.typeCode} value={ct.typeCode}>
                        {ct.typeCode} - {ct.vietnameseName} [Mã ISO: {ct.isoCode}]
                      </option>
                    ))}
                  </optgroup>
                )}

                {groupedContainerTypes.flatRack.length > 0 && (
                  <optgroup label="🔲 CONTAINER MẶT BẰNG (FLAT RACK / OOG)">
                    {groupedContainerTypes.flatRack.map((ct) => (
                      <option key={ct.id || ct.typeCode} value={ct.typeCode}>
                        {ct.typeCode} - {ct.vietnameseName} [Mã ISO: {ct.isoCode}]
                      </option>
                    ))}
                  </optgroup>
                )}

                {groupedContainerTypes.tank.length > 0 && (
                  <optgroup label="🛢️ CONTAINER BỒN XI TEC (ISO TANK)">
                    {groupedContainerTypes.tank.map((ct) => (
                      <option key={ct.id || ct.typeCode} value={ct.typeCode}>
                        {ct.typeCode} - {ct.vietnameseName} [Mã ISO: {ct.isoCode}]
                      </option>
                    ))}
                  </optgroup>
                )}

                {groupedContainerTypes.other.length > 0 && (
                  <optgroup label="🚪 CÁC LOẠI CONTAINER ĐẶC CHỦNG KHÁC">
                    {groupedContainerTypes.other.map((ct) => (
                      <option key={ct.id || ct.typeCode} value={ct.typeCode}>
                        {ct.typeCode} - {ct.vietnameseName} [Mã ISO: {ct.isoCode}]
                      </option>
                    ))}
                  </optgroup>
                )}
              </select>

              {/* Master Data Container Specs Preview Card */}
              {selectedContainerType && (
                <div className="p-3 bg-slate-950/90 border border-slate-800 rounded-2xl grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-[11px]">
                  <div>
                    <span className="text-slate-500 block">Mã ISO &amp; Quy Cách:</span>
                    <div className="flex items-center gap-1.5 mt-0.5">
                      <span className="font-mono font-black text-cyan-400 text-xs">
                        {selectedContainerType.typeCode}
                      </span>
                      <span className="px-1.5 py-0.2 bg-slate-800 text-slate-300 font-mono text-[10px] rounded border border-slate-700">
                        {selectedContainerType.isoCode}
                      </span>
                    </div>
                  </div>

                  <div>
                    <span className="text-slate-500 block">Kích Thước Dài x Cao:</span>
                    <span className="font-bold text-white mt-0.5 block">
                      {selectedContainerType.size}' ({selectedContainerType.lengthMm ? Math.round(selectedContainerType.lengthMm / 1000) : selectedContainerType.size}m) - {selectedContainerType.heightMm || 2591}mm
                    </span>
                  </div>

                  <div>
                    <span className="text-slate-500 block">Dung Tích Khối (CBM):</span>
                    <span className="font-mono font-bold text-amber-400 mt-0.5 block">
                      {selectedContainerType.cbm || 33.2} m³
                    </span>
                  </div>

                  <div>
                    <span className="text-slate-500 block">Tải Trọng Tối Đa:</span>
                    <span className="font-mono font-bold text-emerald-400 mt-0.5 block">
                      {selectedContainerType.maxPayloadKg ? `${(selectedContainerType.maxPayloadKg / 1000).toFixed(1)} Tấn` : '28.2 Tấn'}
                    </span>
                  </div>
                </div>
              )}
            </div>

            <div>
              <label className="block font-bold text-slate-300 mb-1">Chỉ Định Bệ Rửa (Cleaning Bay)</label>
              <select
                value={cleaningBay}
                onChange={(e) => setCleaningBay(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-cyan-300 font-bold text-xs focus:outline-none focus:border-cyan-500"
              >
                <option value="CLEANING-BAY-01 (Trạm Xịt Rửa Áp Lực Cao)">Cleaning Bay 01 - Áp lực cao 200 Bar / Reefer</option>
                <option value="CLEANING-BAY-02 (Khu Quét Dọn & Rửa Nước)">Cleaning Bay 02 - Quét dọn & Rửa nước khô</option>
                <option value="CLEANING-BAY-03 (Trạm Sấy Khô Sàn & Bóc Nhãn)">Cleaning Bay 03 - Sấy sàn gỗ & Cạo sticker IMO</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-300 mb-1">Mục Tiêu Nghiệm Thu Grade</label>
              <select
                value={targetGrade}
                onChange={(e) => setTargetGrade(e.target.value as any)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-emerald-300 font-bold text-xs focus:outline-none focus:border-cyan-500"
              >
                <option value="GRADE_A">Grade A (Xuất Khẩu Cao Cấp / Điện Tử)</option>
                <option value="FOOD_GRADE">Food Grade (Nông Sản / Thực Phẩm)</option>
                <option value="GENERAL_CARGO">General Cargo (Bách Hóa)</option>
                <option value="SCRAP_GRADE">Scrap Grade (Phế Liệu / Vật Liệu Nặng)</option>
              </select>
            </div>
          </div>

          {/* Preset Services */}
          <div>
            <label className="block font-bold text-slate-300 mb-2 text-xs">
              Chọn Danh Mục Dịch Vụ Vệ Sinh Yêu Cầu ({selectedPresetServices.length} đã chọn):
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {servicePresets.map((sp) => {
                const isChecked = selectedPresetServices.includes(sp.code);
                return (
                  <div
                    key={sp.code}
                    onClick={() => handleToggleService(sp.code)}
                    className={`p-2.5 rounded-xl border transition cursor-pointer flex items-center justify-between text-xs ${
                      isChecked
                        ? 'bg-cyan-950/40 border-cyan-500/60 text-white'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-cyan-400">[{sp.code}]</span>
                      <span className="font-semibold text-[11px] truncate max-w-[180px]">{sp.name}</span>
                    </div>
                    <span className="font-mono font-bold text-amber-400 text-[10px]">
                      {sp.price.toLocaleString('vi-VN')} đ
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block font-bold text-slate-300 mb-1 text-xs">Ghi chú giám định / Yêu cầu đặc biệt</label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Yêu cầu kiểm tra mùi đáy, xịt sạch rãnh sàn T-Floor hoặc sấy khô sàn gỗ..."
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white text-xs placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Action buttons */}
          <div className="pt-3 border-t border-slate-800 flex justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-xl transition cursor-pointer"
            >
              Hủy
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-black rounded-xl shadow-lg transition flex items-center gap-1.5 cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>Tiếp Nhận &amp; Đưa Vào Hàng Đợi</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
