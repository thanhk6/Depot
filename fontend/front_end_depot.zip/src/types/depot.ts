export type RoleType =
  | 'SURVEYOR'       // Giám định
  | 'OPERATOR'       // Khai thác
  | 'ACCOUNTANT'     // Kế toán / Thanh toán
  | 'ESTIMATOR'      // Báo giá
  | 'REPAIR_TECH'    // Sửa chữa
  | 'QC_INSPECTOR'   // Kiểm tra chất lượng (QC)
  | 'CLEANING_STAFF' // Tổ vệ sinh vỏ bãi
  | 'FORKLIFT_DRIVER'// Xe nâng
  | 'SHIPPING_LINE'  // Hãng tàu (Phê duyệt báo giá)
  | 'DEPOT_MANAGER'  // Quản lý Depot
  | 'ADMIN';          // Quản trị hệ thống

export type ContainerSize = '20GP' | '40GP' | '40HC' | '45HC' | '20RF' | '40RH';

export type JobStatus =
  | 'GATE_IN'                   // Mới tiếp nhận
  | 'SURVEYING'                 // Đang giám định
  | 'SURVEYED'                  // Đã giám định
  | 'OPERATION_PENDING'         // Khai thác lập phiếu
  | 'PAYMENT_PENDING'           // Chờ thanh toán dịch vụ
  | 'PAID'                      // Đã thanh toán dịch vụ
  | 'ESTIMATE_PENDING_APPROVAL' // Chờ Hãng tàu duyệt báo giá
  | 'ESTIMATE_APPROVED'         // Hãng tàu đã duyệt báo giá
  | 'ESTIMATE_REJECTED'         // Hãng tàu từ chối báo giá
  | 'REPAIRING'                 // Đang sửa chữa
  | 'QC_PENDING'                // Chờ kiểm tra QC
  | 'QC_PASSED'                 // QC Đạt
  | 'QC_FAILED'                 // QC Không đạt (Sửa lại)
  | 'YARD_STORED'               // Đã lưu bãi
  | 'GATE_OUT';                 // Đã xuất bãi

export interface DamageItem {
  id: string;
  component: string;      // Bộ phận: Vách trái, Vách phải, Mái, Cửa, Sàn, Khung, Cụm máy lạnh...
  damageCode: string;     // Mã hư hỏng: DENT, HOLE, BENT, RUST, CUT, BROKEN, DIRTY
  damageNameVi: string;   // Móp, Thủng, Cong, Rỉ sét, Rách, Vỡ, Bẩn...
  locationCode: string;   // Vị trí: L1, R2, F1, T3, D1...
  repairCode: string;     // Mã sửa chữa: WELD, PATCH, STRAIGHTEN, CLEAN, REPLACE, PAINT
  repairNameVi: string;   // Hàn, Vá, Nắn, Vệ sinh, Thay thế, Sơn...
  quantity: number;       // Số lượng / Kích thước (cm / cái / m2)
  unit: string;           // cm, m2, cái, giờ
  laborHours: number;     // Giờ công
  laborRate: number;      // Đơn giá nhân công (VND/giờ)
  materialCost: number;   // Chi phí vật tư (VND)
  totalCost: number;      // Thành tiền (VND)
  severity: 'LIGHT' | 'MEDIUM' | 'HEAVY';
  notes?: string;
  photoUrl?: string;
}

export interface SurveyPhoto {
  id: string;
  angle: 'FRONT' | 'BACK' | 'LEFT' | 'RIGHT' | 'INSIDE' | 'ROOF' | 'REEFER';
  angleVi: string;
  url: string;
  timestamp: string;
}

export interface SurveyInfo {
  surveyorId: string;
  surveyorName: string;
  surveyDate: string;
  conditionRating: 'A' | 'B' | 'C' | 'D'; // Phân loại chất lượng vỏ container
  damages: DamageItem[];
  photos: SurveyPhoto[];
  generalNotes: string;
  isCompleted: boolean;
}

export interface DepotServiceItem {
  id: string;
  code: string;
  nameVi: string;
  unitPrice: number;
  quantity: number;
  totalPrice: number;
}

export interface CustomerInfo {
  customerName: string;
  taxCode: string;
  phone: string;
  driverName?: string;
  licensePlate?: string;  // Biển số xe đầu kéo
  trailerPlate?: string;  // Biển số rơ moóc
  bookingNo?: string;
  blNo?: string;
}

export interface OperationInfo {
  operatorId: string;
  operatorName: string;
  createdDate: string;
  customer: CustomerInfo;
  services: DepotServiceItem[];
  subtotal: number;
  vatAmount: number;
  totalAmount: number;
  serviceTicketNo: string; // Số phiếu dịch vụ (VD: PDV-2026-0089)
}

export interface PaymentInfo {
  paymentTicketNo: string; // Số phiếu thu (VD: PT-2026-0089)
  method: 'BANK_TRANSFER' | 'CASH' | 'VIETQR';
  status: 'PENDING' | 'PAID' | 'MISMATCHED';
  amount: number;
  transactionRef?: string; // Mã giao dịch ngân hàng
  bankName?: string;
  qrCodeUrl?: string;
  paidDate?: string;
  cashierName?: string;
  reconciliationNotes?: string;
}

export interface RepairEstimate {
  estimateNo: string;      // Số báo giá (VD: EST-2026-0089)
  estimatorName: string;
  createdDate: string;
  damages: DamageItem[];
  totalLaborCost: number;
  totalMaterialCost: number;
  subtotal: number;
  vatAmount: number;
  grandTotal: number;
  approvalStatus: 'PENDING' | 'APPROVED' | 'REJECTED';
  approvalDate?: string;
  approvedBy?: string;     // Đại diện Hãng tàu
  rejectionReason?: string;
}

export interface RepairWorkOrder {
  workOrderNo: string;     // Lệnh sửa chữa (VD: WO-2026-0089)
  repairTeam: string;      // Tổ sửa chữa A, B, C
  assignedWorkers: string[];
  issuedMaterials: {
    itemCode: string;
    itemName: string;
    quantity: number;
    unit: string;
  }[];
  startDate?: string;
  completedDate?: string;
  preRepairPhotos: string[];
  postRepairPhotos: string[];
  status: 'NOT_STARTED' | 'IN_PROGRESS' | 'COMPLETED';
}

export interface QCInspection {
  inspectorName: string;
  inspectionDate?: string;
  result: 'PENDING' | 'PASSED' | 'FAILED';
  checklist: {
    item: string;
    passed: boolean;
    note?: string;
  }[];
  comments?: string;
}

export interface YardLocation {
  block: 'BLOCK_A' | 'BLOCK_B' | 'BLOCK_C' | 'BLOCK_R' | 'BLOCK_Q'; // A: 20ft, B: 40ft, C: Reefer, R: Sửa chữa, Q: Khu QC
  bay: number;   // Dãy (1 - 10)
  row: number;   // Hàng (1 - 6)
  tier: number;  // Tầng (1 - 4)
}

export interface ForkliftMoveOrder {
  id: string;
  jobId: string;
  containerNo: string;
  fromLocation: YardLocation;
  toLocation: YardLocation;
  forkliftId: string;      // Xe nâng 01, Xe nâng 02...
  driverName: string;
  requestedBy: string;
  requestedAt: string;
  completedAt?: string;
  status: 'PENDING' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED';
  purpose: 'SURVEY' | 'REPAIR' | 'QC' | 'YARD_STORAGE' | 'GATE_OUT';
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  role: RoleType;
  userName: string;
  action: string;
  details: string;
}

export interface DepotJob {
  id: string;              // Job ID (VD: JOB-2026-001)
  containerNo: string;     // Số Container (VD: MSKU1234567)
  isoSize: ContainerSize;  // Kích thước ISO
  shippingLine: string;    // Hãng tàu (Maersk, MSC, COSCO...)
  tareWeightKg: number;    // Trọng lượng vỏ (kg)
  maxPayloadKg: number;    // Tải trọng tối đa (kg)
  gateInDate: string;      // Thời gian vào depot
  gateOutDate?: string;    // Thời gian ra depot
  status: JobStatus;
  currentLocation: YardLocation;
  
  survey?: SurveyInfo;
  operation?: OperationInfo;
  payment?: PaymentInfo;
  estimate?: RepairEstimate;
  repairOrder?: RepairWorkOrder;
  qcInspection?: QCInspection;
  
  moveHistory: ForkliftMoveOrder[];
  auditLogs: AuditLogEntry[];
}
