import React, { useState, useMemo } from 'react';
import { useAuth } from '../../../app/providers/AuthProvider';
import { ROLES, PERMISSIONS, RoleDefinition } from '../../../constants/permissions';
import {
  Users,
  ShieldCheck,
  Lock,
  Key,
  ShieldAlert,
  Search,
  Filter,
  Plus,
  Edit2,
  Trash2,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  UserCheck,
  Smartphone,
  Building2,
  Mail,
  Phone,
  Clock,
  Laptop,
  Copy,
  Check,
  Sparkles,
  Zap,
  Globe,
  Settings,
  Download,
  Shield,
  UserX,
  FileText
} from 'lucide-react';
import {
  UserAccount,
  UserStatus,
  AuditLogEntry,
  SecurityPolicyConfig
} from '../types/rbac';
import {
  INITIAL_USERS,
  INITIAL_AUDIT_LOGS,
  INITIAL_SECURITY_POLICY
} from '../data/rbacMockData';
import { UserModal } from '../components/UserModal';
import { ResetPasswordModal } from '../components/ResetPasswordModal';
import { PermissionMatrixTable } from '../components/PermissionMatrixTable';
import { AuditLogViewer } from '../components/AuditLogViewer';
import { SecurityPolicyConfigView } from '../components/SecurityPolicyConfig';

export const SystemPage: React.FC = () => {
  const { currentRole, currentUser, switchRole } = useAuth();

  const [activeSubTab, setActiveSubTab] = useState<'USERS' | 'MATRIX' | 'AUDIT' | 'SECURITY'>('USERS');
  const [users, setUsers] = useState<UserAccount[]>(INITIAL_USERS);
  const [roles, setRoles] = useState<RoleDefinition[]>(ROLES);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>(INITIAL_AUDIT_LOGS);
  const [securityPolicy, setSecurityPolicy] = useState<SecurityPolicyConfig>(INITIAL_SECURITY_POLICY);

  // Filters for Tab 1 (Users)
  const [searchUser, setSearchUser] = useState('');
  const [roleFilter, setRoleFilter] = useState('ALL');
  const [departmentFilter, setDepartmentFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL');

  // Modals
  const [isUserModalOpen, setIsUserModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<UserAccount | null>(null);
  const [resettingUser, setResettingUser] = useState<UserAccount | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Stats calculation
  const totalUsers = users.length;
  const activeUsers = users.filter((u) => u.status === 'ACTIVE').length;
  const twoFactorCount = users.filter((u) => u.is2FAEnabled).length;
  const lockedUsers = users.filter((u) => u.status === 'LOCKED').length;

  // Filtered Users
  const filteredUsers = useMemo(() => {
    return users.filter((u) => {
      const matchSearch =
        searchUser.trim() === '' ||
        u.fullName.toLowerCase().includes(searchUser.toLowerCase()) ||
        u.username.toLowerCase().includes(searchUser.toLowerCase()) ||
        u.email.toLowerCase().includes(searchUser.toLowerCase()) ||
        u.employeeCode.toLowerCase().includes(searchUser.toLowerCase()) ||
        u.phone.includes(searchUser);

      const matchRole = roleFilter === 'ALL' || u.roleId === roleFilter;
      const matchDept = departmentFilter === 'ALL' || u.department === departmentFilter;
      const matchStatus = statusFilter === 'ALL' || u.status === statusFilter;

      return matchSearch && matchRole && matchDept && matchStatus;
    });
  }, [users, searchUser, roleFilter, departmentFilter, statusFilter]);

  // Unique departments for filter
  const departments = useMemo(() => {
    return Array.from(new Set(users.map((u) => u.department)));
  }, [users]);

  // Handle Save User (Create / Edit)
  const handleSaveUser = (userData: Omit<UserAccount, 'id' | 'createdAt'> & { id?: string }) => {
    if (userData.id) {
      // Edit
      setUsers((prev) =>
        prev.map((u) => (u.id === userData.id ? { ...u, ...userData } : u))
      );
      setToastMessage(`🎉 Đã cập nhật thông tin tài khoản "${userData.fullName}" thành công!`);

      // Log audit
      addAuditLog('UPDATE_USER', 'Cập Nhật Người Dùng', `Tài khoản ${userData.username} (${userData.roleName})`, 'Cập nhật phân quyền/thông tin');
    } else {
      // Create
      const newUser: UserAccount = {
        ...userData,
        id: `USR-${Date.now().toString().slice(-4)}`,
        createdAt: new Date().toISOString().slice(0, 10),
        lastLoginAt: 'Chưa đăng nhập',
        lastLoginIp: 'N/A'
      };
      setUsers((prev) => [newUser, ...prev]);
      setToastMessage(`🎉 Đã tạo mới tài khoản "${userData.fullName}" (${userData.username}) thành công!`);

      addAuditLog('CREATE_USER', 'Tạo Mới Tài Khoản', `Tài khoản ${userData.username}`, `Gán vai trò ${userData.roleName}`);
    }

    setIsUserModalOpen(false);
    setEditingUser(null);
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Toggle Lock/Unlock User
  const handleToggleLockUser = (user: UserAccount) => {
    const newStatus: UserStatus = user.status === 'LOCKED' ? 'ACTIVE' : 'LOCKED';
    setUsers((prev) =>
      prev.map((u) => (u.id === user.id ? { ...u, status: newStatus } : u))
    );
    const msg = newStatus === 'LOCKED' ? `🔴 Đã khóa tài khoản ${user.username}` : `🟢 Đã mở khóa tài khoản ${user.username}`;
    setToastMessage(msg);

    addAuditLog('UPDATE_USER', newStatus === 'LOCKED' ? 'Khóa Tài Khoản' : 'Mở Khóa Tài Khoản', `Tài khoản ${user.username}`, `Đổi trạng thái sang ${newStatus}`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Delete User
  const handleDeleteUser = (user: UserAccount) => {
    if (window.confirm(`Bạn có chắc chắn muốn xóa tài khoản "${user.fullName}" (${user.username}) khỏi hệ thống?`)) {
      setUsers((prev) => prev.filter((u) => u.id !== user.id));
      setToastMessage(`🗑️ Đã xóa tài khoản "${user.username}" khỏi hệ thống.`);

      addAuditLog('DELETE_USER', 'Xóa Tài Khoản', `Tài khoản ${user.username}`, 'Xóa vĩnh viễn khỏi danh sách');
      setTimeout(() => setToastMessage(null), 3000);
    }
  };

  // Reset Password Confirm
  const handleConfirmResetPassword = (userId: string, newPass: string, forceChange: boolean) => {
    const user = users.find((u) => u.id === userId);
    setResettingUser(null);
    setToastMessage(`🔑 Đã đặt lại mật khẩu mới cho ${user?.fullName}. Mật khẩu tạm: ${newPass}`);

    addAuditLog('RESET_PASSWORD', 'Đặt Lại Mật Khẩu', `Tài khoản ${user?.username}`, `Yêu cầu đổi mật khẩu lần tới: ${forceChange ? 'CÓ' : 'KHÔNG'}`);
    setTimeout(() => setToastMessage(null), 6000);
  };

  // Switch role to preview UI from user perspective
  const handleImpersonateUserRole = (user: UserAccount) => {
    switchRole(user.roleId);
    setToastMessage(`🔄 Đang chuyển góc nhìn hệ thống sang vai trò: "${user.roleName}"`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Update Role Permissions
  const handleUpdateRolePermissions = (roleId: string, newPermissions: string[]) => {
    setRoles((prev) =>
      prev.map((r) => (r.id === roleId ? { ...r, permissions: newPermissions } : r))
    );
    const targetRole = roles.find((r) => r.id === roleId);
    addAuditLog('CHANGE_PERMISSIONS', 'Cập Nhật Quyền Hạn', `Vai trò ${targetRole?.name}`, `Cập nhật ${newPermissions.length} quyền hạn`);
  };

  // Save Security Policy
  const handleSaveSecurityPolicy = (newPolicy: SecurityPolicyConfig) => {
    setSecurityPolicy(newPolicy);
    addAuditLog('UPDATE_USER', 'Cập Nhật Chính Sách Bảo Mật', 'Security Policy Settings', 'Cập nhật password expire, session timeout & IP whitelist');
  };

  const addAuditLog = (
    action: AuditLogEntry['action'],
    actionLabel: string,
    targetResource: string,
    details: string
  ) => {
    const nowStr = new Date().toISOString().replace('T', ' ').slice(0, 19);
    const newLog: AuditLogEntry = {
      id: `AUD-${Math.floor(100 + Math.random() * 900)}`,
      timestamp: nowStr,
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentRole.name,
      action,
      actionLabel,
      targetResource,
      ipAddress: '113.161.44.12',
      deviceInfo: 'Chrome / Web Applet',
      status: 'SUCCESS',
      details
    };
    setAuditLogs((prev) => [newLog, ...prev]);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto animate-fade-in pb-16">
      {/* Top Banner */}
      <div className="p-6 bg-slate-900 border border-slate-800 rounded-3xl flex items-center justify-between flex-wrap gap-4 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="p-3.5 bg-purple-600/20 border border-purple-500/30 text-purple-400 rounded-2xl">
            <Lock className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold text-white tracking-wide">
                PHÂN QUYỀN RBAC &amp; QUẢN LÝ NGƯỜI DÙNG (ROLE-BASED ACCESS CONTROL)
              </h2>
              <span className="px-2.5 py-0.5 bg-purple-950 border border-purple-800 text-purple-300 text-xs font-mono font-bold rounded-lg flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-purple-400" />
                <span>Enterprise Core</span>
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5 max-w-3xl leading-relaxed">
              Kiểm soát phân quyền truy cập đa cấp theo 10 Vai trò nghiệp vụ Depot &bull; Quản lý tài khoản nhân viên, ma trận quyền hạn chi tiết, chính sách mật khẩu và nhật ký truy vết Audit Trail.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setEditingUser(null);
              setIsUserModalOpen(true);
            }}
            className="px-4 py-2.5 bg-purple-600 hover:bg-purple-500 text-white rounded-2xl text-xs font-bold transition flex items-center gap-2 cursor-pointer shadow-lg shadow-purple-950"
          >
            <Plus className="w-4 h-4" />
            <span>Thêm Mới Người Dùng</span>
          </button>
        </div>
      </div>

      {/* Toast message */}
      {toastMessage && (
        <div className="p-4 bg-slate-900 border-2 border-purple-500 rounded-2xl flex items-center justify-between text-xs text-purple-200 shadow-2xl animate-fade-in">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <span className="font-bold">{toastMessage}</span>
          </div>
          <button onClick={() => setToastMessage(null)} className="text-slate-400 hover:text-white p-1">
            &times;
          </button>
        </div>
      )}

      {/* KPI Stats Overview */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl space-y-1">
          <div className="flex items-center justify-between text-xs font-bold text-slate-400">
            <span>Tổng Số Tài Khoản</span>
            <Users className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl font-black text-white font-mono">{totalUsers}</div>
          <span className="text-[10px] text-slate-500">{departments.length} phòng ban nghiệp vụ</span>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl space-y-1">
          <div className="flex items-center justify-between text-xs font-bold text-slate-400">
            <span>Đang Hoạt Động (Active)</span>
            <UserCheck className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-black text-emerald-400 font-mono">{activeUsers}</div>
          <span className="text-[10px] text-slate-500">Tỷ lệ khả dụng: {Math.round((activeUsers / totalUsers) * 100)}%</span>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl space-y-1">
          <div className="flex items-center justify-between text-xs font-bold text-slate-400">
            <span>Đã Bật Bảo Mật 2FA</span>
            <Smartphone className="w-4 h-4 text-sky-400" />
          </div>
          <div className="text-2xl font-black text-sky-400 font-mono">{twoFactorCount}</div>
          <span className="text-[10px] text-slate-500">Google Authenticator OTP</span>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl space-y-1">
          <div className="flex items-center justify-between text-xs font-bold text-slate-400">
            <span>Tài Khoản Tạm Khóa</span>
            <UserX className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-2xl font-black text-rose-400 font-mono">{lockedUsers}</div>
          <span className="text-[10px] text-slate-500">Bị vô hiệu hóa truy cập</span>
        </div>
      </div>

      {/* Main Tab Controls */}
      <div className="p-4 bg-slate-900 border border-slate-800 rounded-3xl space-y-4">
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          <button
            onClick={() => setActiveSubTab('USERS')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer flex items-center gap-2 ${
              activeSubTab === 'USERS'
                ? 'bg-purple-600 text-white shadow-md shadow-purple-950'
                : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>1. Danh Sách Người Dùng &amp; Tài Khoản ({users.length})</span>
          </button>

          <button
            onClick={() => setActiveSubTab('MATRIX')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer flex items-center gap-2 ${
              activeSubTab === 'MATRIX'
                ? 'bg-purple-600 text-white shadow-md shadow-purple-950'
                : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            <span>2. Ma Trận Phân Quyền Vai Trò (RBAC Matrix)</span>
          </button>

          <button
            onClick={() => setActiveSubTab('AUDIT')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer flex items-center gap-2 ${
              activeSubTab === 'AUDIT'
                ? 'bg-purple-600 text-white shadow-md shadow-purple-950'
                : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <ShieldAlert className="w-4 h-4" />
            <span>3. Nhật Ký Hoạt Động &amp; Bảo Mật ({auditLogs.length})</span>
          </button>

          <button
            onClick={() => setActiveSubTab('SECURITY')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer flex items-center gap-2 ${
              activeSubTab === 'SECURITY'
                ? 'bg-purple-600 text-white shadow-md shadow-purple-950'
                : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <Key className="w-4 h-4" />
            <span>4. Chính Sách Bảo Mật &amp; IP Whitelist</span>
          </button>
        </div>

        {/* Filters on Tab 1 (USERS) */}
        {activeSubTab === 'USERS' && (
          <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 text-xs pt-2">
            <div className="sm:col-span-4 relative">
              <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchUser}
                onChange={(e) => setSearchUser(e.target.value)}
                placeholder="Tìm theo tên, username, email, mã NV..."
                className="w-full pl-10 pr-4 py-2.5 bg-slate-950 border border-slate-800 text-white text-xs rounded-xl focus:outline-none focus:border-purple-500"
              />
            </div>

            <div className="sm:col-span-3">
              <select
                value={roleFilter}
                onChange={(e) => setRoleFilter(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 text-white text-xs rounded-xl focus:outline-none"
              >
                <option value="ALL">Tất cả 10 Vai Trò</option>
                {roles.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="sm:col-span-3">
              <select
                value={departmentFilter}
                onChange={(e) => setDepartmentFilter(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 text-white text-xs rounded-xl focus:outline-none"
              >
                <option value="ALL">Tất cả Phòng Ban</option>
                {departments.map((dept) => (
                  <option key={dept} value={dept}>
                    {dept}
                  </option>
                ))}
              </select>
            </div>

            <div className="sm:col-span-2">
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 text-white text-xs rounded-xl focus:outline-none"
              >
                <option value="ALL">Tất cả Trạng Thái</option>
                <option value="ACTIVE">🟢 Đang hoạt động</option>
                <option value="LOCKED">🔴 Đang bị khóa</option>
                <option value="INACTIVE">⚪ Tạm dừng</option>
              </select>
            </div>
          </div>
        )}
      </div>

      {/* TAB 1: USERS DIRECTORY TABLE */}
      {activeSubTab === 'USERS' && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-950/80 border-b border-slate-800 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                  <th className="p-4">Nhân Viên &amp; Tài Khoản</th>
                  <th className="p-4">Vai Trò (Role)</th>
                  <th className="p-4">Phòng Ban Trực Thuộc</th>
                  <th className="p-4">Bảo Mật 2FA</th>
                  <th className="p-4">Đăng Nhập Gần Nhất</th>
                  <th className="p-4">Trạng Thái</th>
                  <th className="p-4 text-right">Thao Tác</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80">
                {filteredUsers.map((user) => {
                  const isCurrent = user.id === currentUser.id;

                  return (
                    <tr key={user.id} className="hover:bg-slate-850 transition duration-150">
                      <td className="p-4">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-xl bg-purple-600/20 text-purple-300 border border-purple-500/30 flex items-center justify-center font-bold font-mono text-sm shrink-0">
                            {user.fullName.slice(0, 2).toUpperCase()}
                          </div>
                          <div>
                            <div className="font-bold text-white text-sm flex items-center gap-1.5">
                              <span>{user.fullName}</span>
                              {isCurrent && (
                                <span className="px-1.5 py-0.2 bg-emerald-950 text-emerald-400 border border-emerald-800 text-[9px] font-mono rounded">
                                  BẠN
                                </span>
                              )}
                            </div>
                            <div className="text-[11px] text-slate-400 font-mono flex items-center gap-2 mt-0.5">
                              <span className="text-purple-400">@{user.username}</span>
                              <span>&bull;</span>
                              <span>{user.email}</span>
                            </div>
                          </div>
                        </div>
                      </td>

                      <td className="p-4">
                        <span className="px-2.5 py-1 bg-purple-950/80 border border-purple-800 text-purple-300 rounded-lg font-mono font-bold text-[11px]">
                          {user.roleName}
                        </span>
                      </td>

                      <td className="p-4 text-slate-300">
                        <div className="font-medium">{user.department}</div>
                        <div className="text-[10px] text-slate-500 font-mono">{user.employeeCode}</div>
                      </td>

                      <td className="p-4">
                        {user.is2FAEnabled ? (
                          <span className="px-2 py-0.5 bg-emerald-950 text-emerald-300 border border-emerald-800 rounded text-[10px] font-mono font-bold inline-flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                            <span>BẬT (2FA)</span>
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 bg-slate-950 text-slate-500 border border-slate-800 rounded text-[10px] font-mono">
                            Tắt
                          </span>
                        )}
                      </td>

                      <td className="p-4 font-mono text-[11px] text-slate-400">
                        <div>{user.lastLoginAt || 'Chưa đăng nhập'}</div>
                        <div className="text-[10px] text-slate-500">{user.lastLoginIp}</div>
                      </td>

                      <td className="p-4">
                        {user.status === 'ACTIVE' && (
                          <span className="px-2.5 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 rounded-lg text-[11px] font-bold inline-flex items-center gap-1 font-mono">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                            <span>Hoạt Động</span>
                          </span>
                        )}
                        {user.status === 'LOCKED' && (
                          <span className="px-2.5 py-1 bg-rose-500/20 text-rose-300 border border-rose-500/40 rounded-lg text-[11px] font-bold inline-flex items-center gap-1 font-mono">
                            <span className="w-1.5 h-1.5 rounded-full bg-rose-400" />
                            <span>Đang Khóa</span>
                          </span>
                        )}
                        {user.status === 'INACTIVE' && (
                          <span className="px-2.5 py-1 bg-slate-800 text-slate-400 border border-slate-700 rounded-lg text-[11px] font-bold inline-flex items-center gap-1 font-mono">
                            <span>Tạm Dừng</span>
                          </span>
                        )}
                      </td>

                      <td className="p-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => handleImpersonateUserRole(user)}
                            title="Chuyển sang góc nhìn vai trò này"
                            className="p-1.5 bg-slate-800 hover:bg-purple-900/60 text-slate-300 hover:text-purple-300 rounded-xl transition cursor-pointer"
                          >
                            <Zap className="w-3.5 h-3.5" />
                          </button>

                          <button
                            onClick={() => setResettingUser(user)}
                            title="Đặt lại mật khẩu"
                            className="p-1.5 bg-slate-800 hover:bg-amber-900/60 text-slate-300 hover:text-amber-300 rounded-xl transition cursor-pointer"
                          >
                            <Key className="w-3.5 h-3.5" />
                          </button>

                          <button
                            onClick={() => {
                              setEditingUser(user);
                              setIsUserModalOpen(true);
                            }}
                            title="Chỉnh sửa tài khoản"
                            className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl transition cursor-pointer"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>

                          <button
                            onClick={() => handleToggleLockUser(user)}
                            title={user.status === 'LOCKED' ? 'Mở khóa tài khoản' : 'Khóa tài khoản'}
                            className={`p-1.5 rounded-xl transition cursor-pointer ${
                              user.status === 'LOCKED'
                                ? 'bg-emerald-950 hover:bg-emerald-900 text-emerald-400'
                                : 'bg-slate-800 hover:bg-rose-900/60 text-slate-300 hover:text-rose-400'
                            }`}
                          >
                            {user.status === 'LOCKED' ? <UserCheck className="w-3.5 h-3.5" /> : <UserX className="w-3.5 h-3.5" />}
                          </button>

                          {!isCurrent && (
                            <button
                              onClick={() => handleDeleteUser(user)}
                              title="Xóa tài khoản"
                              className="p-1.5 bg-slate-800 hover:bg-rose-950 text-slate-400 hover:text-rose-400 rounded-xl transition cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: GRANULAR PERMISSION MATRIX TABLE */}
      {activeSubTab === 'MATRIX' && (
        <PermissionMatrixTable
          roles={roles}
          onUpdateRolePermissions={handleUpdateRolePermissions}
        />
      )}

      {/* TAB 3: AUDIT LOGS VIEWER */}
      {activeSubTab === 'AUDIT' && (
        <AuditLogViewer logs={auditLogs} />
      )}

      {/* TAB 4: SECURITY POLICY CONFIG */}
      {activeSubTab === 'SECURITY' && (
        <SecurityPolicyConfigView
          initialPolicy={securityPolicy}
          onSavePolicy={handleSaveSecurityPolicy}
        />
      )}

      {/* Modal: Create/Edit User */}
      {isUserModalOpen && (
        <UserModal
          user={editingUser}
          onClose={() => {
            setIsUserModalOpen(false);
            setEditingUser(null);
          }}
          onSaveUser={handleSaveUser}
        />
      )}

      {/* Modal: Reset Password */}
      {resettingUser && (
        <ResetPasswordModal
          user={resettingUser}
          onClose={() => setResettingUser(null)}
          onConfirmReset={handleConfirmResetPassword}
        />
      )}
    </div>
  );
};
