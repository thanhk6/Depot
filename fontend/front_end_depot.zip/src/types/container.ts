import { JobStatus, ContainerGrade, ISOSize } from '../constants/enums';

export type { JobStatus, ContainerGrade, ISOSize };

export interface YardLocation {
  block: string;
  bay: number;
  row: number;
  tier: number;
}

export interface DamageItem {
  id: string;
  componentCode: string;
  componentNameVi: string;
  damageTypeCode: string;
  damageTypeNameVi: string;
  locationCode: string;
  lengthCm: number;
  widthCm: number;
  quantity: number;
  unit: string;
  responsibility: 'SHIPPING_LINE' | 'CONSIGNEE' | 'DEPOT';
  estimatedHours: number;
  materialCostVnd: number;
  laborCostVnd: number;
  totalCostVnd: number;
  photoUrl?: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED' | 'REPAIRED';
}

export interface PhotoRecord {
  id: string;
  url: string;
  description: string;
  timestamp: string;
  angleVi: string;
}

export interface SurveyRecord {
  surveyorName: string;
  surveyDate: string;
  conditionRating: ContainerGrade;
  structureClean: boolean;
  odorClean: boolean;
  floorCondition: 'GOOD' | 'OIL_STAINED' | 'BROKEN' | 'DELAMINATED';
  damages: DamageItem[];
  photos: PhotoRecord[];
  generalNotes?: string;
}

export interface OperationTicket {
  ticketNo: string;
  createdDate: string;
  operatorName: string;
  truckNo: string;
  driverName: string;
  driverPhone: string;
  bookingOrEirNo: string;
  feeAmount: number;
  forkliftDriverName: string;
  assignedLocation: YardLocation;
  notes?: string;
}

export interface PaymentRecord {
  receiptNo: string;
  paymentDate: string;
  amount: number;
  method: string;
  transactionRef: string;
  isPaid: boolean;
  cashierName: string;
}

export interface EstimateSheet {
  estimateNo: string;
  createdDate: string;
  estimatorName: string;
  items: DamageItem[];
  totalLaborVnd: number;
  totalMaterialVnd: number;
  taxVnd: number;
  grandTotalVnd: number;
  status: 'DRAFT' | 'SENT' | 'APPROVED' | 'REJECTED';
  approvedBy?: string;
  approvedDate?: string;
  rejectedReason?: string;
}

export interface RepairWorkOrder {
  workOrderNo: string;
  assignedTeam: string;
  assignedWorkers: string[];
  issuedMaterials: { name: string; quantity: number; unit: string }[];
  startDate?: string;
  completedDate?: string;
  qcPassedDate?: string;
  qcInspectorName?: string;
  qcChecklist?: { code: string; label: string; passed: boolean }[];
  postRepairPhotos?: PhotoRecord[];
  qcComments?: string;
}

export interface DepotJob {
  id: string;
  containerNo: string;
  isoSize: ISOSize;
  ownerType: string;
  shippingLine: string;
  tareWeightKg: number;
  maxPayloadKg: number;
  manufactureYear: number;
  gateInDate: string;
  gateOutDate?: string;
  truckNo: string;
  driverName: string;
  driverPhone: string;
  driverIdCard?: string;
  status: JobStatus;
  currentLocation: YardLocation;
  survey?: SurveyRecord;
  operationTicket?: OperationTicket;
  payment?: PaymentRecord;
  estimate?: EstimateSheet;
  repairWorkOrder?: RepairWorkOrder;
}
