import React from 'react';
import { SurveyItemRecord } from '../types';
import {
  ClipboardCheck,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  Wrench,
  Boxes,
  Ship,
  TrendingUp,
  ShieldCheck,
  FileCheck,
  Eye,
  Plus
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
  CartesianGrid,
  LineChart,
  Line
} from 'recharts';

interface SurveyDashboardProps {
  surveys: SurveyItemRecord[];
  onNavigateToTab: (tabId: string) => void;
  onSelectSurvey: (survey: SurveyItemRecord) => void;
  onCreateNewSurvey?: () => void;
}

export const SurveyDashboard: React.FC<SurveyDashboardProps> = ({
  surveys,
  onNavigateToTab,
  onSelectSurvey,
  onCreateNewSurvey
}) => {
  // Compute KPIs
  const totalWaiting = surveys.filter((s) => s.status === 'NEW' || s.status === 'ASSIGNED').length;
  const totalInProgress = surveys.filter((s) => s.status === 'IN_PROGRESS').length;
  const totalCompleted = surveys.filter((s) => s.status === 'COMPLETED' || s.status === 'CONFIRMED' || s.status === 'EEIR_ISSUED').length;
  
  const countAV = surveys.filter((s) => s.condition === 'AV').length;
  const countCL = surveys.filter((s) => s.condition === 'CL').length;
  const countDM = surveys.filter((s) => s.condition === 'DM').length;

  const totalDamages = surveys.reduce((acc, s) => acc + (s.damages ? s.damages.length : 0), 0);
  const totalNeedRepair = countDM;
  const totalNeedCleaning = countCL;

  // Chart 1: Grading Breakdown Data
  const gradingData = [
    { name: 'AV (Đạt chuẩn - Available)', value: countAV, color: '#10b981' },
    { name: 'CL (Cần vệ sinh - Cleaning)', value: countCL, color: '#f59e0b' },
    { name: 'DM (Hư hỏng - Damaged)', value: countDM, color: '#ef4444' }
  ];

  // Chart 2: Volume by Shipping Line
  const lineCounts: Record<string, { total: number; AV: number; CL: number; DM: number }> = {};
  surveys.forEach((s) => {
    const line = s.shippingLine || 'OTHER';
    if (!lineCounts[line]) {
      lineCounts[line] = { total: 0, AV: 0, CL: 0, DM: 0 };
    }
    lineCounts[line].total += 1;
    if (s.condition === 'AV') lineCounts[line].AV += 1;
    else if (s.condition === 'CL') lineCounts[line].CL += 1;
    else if (s.condition === 'DM') lineCounts[line].DM += 1;
  });

  const carrierChartData = Object.keys(lineCounts).map((k) => ({
    name: k,
    AV: lineCounts[k].AV,
    CL: lineCounts[k].CL,
    DM: lineCounts[k].DM,
    total: lineCounts[k].total
  }));

  // Chart 3: Damage count by type
  const damageTypeCounts: Record<string, number> = {
    'Rách / Thủng (Cut/Hole)': 5,
    'Móp lõm (Dent)': 8,
    'Cong vênh (Bent)': 3,
    'Ron cao su rách (Gasket)': 4,
    'Sàn bong tróc (Floor)': 3,
    'Rỉ sét (Rust)': 2
  };
  const damageBarData = Object.keys(damageTypeCounts).map((key) => ({
    damageType: key,
    count: damageTypeCounts[key]
  }));

  // Chart 4: Survey Trends (Last 7 days)
  const trendData = [
    { date: '04/08', count: 24, avRate: 68 },
    { date: '05/08', count: 31, avRate: 72 },
    { date: '06/08', count: 28, avRate: 65 },
    { date: '07/08', count: 35, avRate: 75 },
    { date: '08/08', count: 42, avRate: 70 },
    { date: '09/08', count: 38, avRate: 64 },
    { date: '10/08 (Hôm nay)', count: surveys.length * 5, avRate: Math.round((countAV / (surveys.length || 1)) * 100) }
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="p-6 bg-slate-900 border border-slate-800 rounded-3xl flex flex-col lg:flex-row lg:items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center gap-4">
          <div className="p-3.5 bg-amber-500/20 border border-amber-500/30 text-amber-400 rounded-2xl">
            <ClipboardCheck className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold text-white tracking-wide">
                Trung Tâm Điều Hành Giám Định (Survey &amp; Grading Dashboard)
              </h2>
              <span className="px-2.5 py-0.5 bg-blue-500/20 border border-blue-500/30 text-blue-300 text-[11px] font-mono font-bold rounded-full">
                IICL-6 / MCIC
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Giám sát trực quan năng suất kiểm tra vỏ container, phân loại tình trạng AV / CL / DM, ghi nhận tổn thất và phát hành e-EIR.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          {onCreateNewSurvey && (
            <button
              onClick={onCreateNewSurvey}
              className="px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow-lg shadow-amber-500/20 transition flex items-center gap-2 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>+ Thêm Mới Giám Định</span>
            </button>
          )}
          <button
            onClick={() => onNavigateToTab('queue')}
            className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs rounded-xl border border-slate-700 transition flex items-center gap-2 cursor-pointer"
          >
            <Clock className="w-4 h-4 text-amber-400" />
            <span>Danh Sách Chờ ({totalWaiting})</span>
          </button>
          <button
            onClick={() => onNavigateToTab('search')}
            className="px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs rounded-xl border border-slate-700 transition flex items-center gap-1.5 cursor-pointer"
          >
            <Eye className="w-4 h-4 text-blue-400" />
            <span>Tra Cứu Nhanh</span>
          </button>
        </div>
      </div>

      {/* KPI Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3.5">
        {/* Waiting */}
        <div
          onClick={() => onNavigateToTab('queue')}
          className="p-4 bg-slate-900/90 border border-slate-800 rounded-2xl space-y-2 hover:border-amber-500/50 transition cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-semibold">Chờ Giám Định</span>
            <Clock className="w-4 h-4 text-amber-400 group-hover:scale-110 transition" />
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black font-mono text-amber-400">{totalWaiting}</span>
            <span className="text-[10px] text-amber-400/80 font-medium">Cần xử lý</span>
          </div>
        </div>

        {/* In Progress */}
        <div
          onClick={() => onNavigateToTab('in_progress')}
          className="p-4 bg-slate-900/90 border border-slate-800 rounded-2xl space-y-2 hover:border-blue-500/50 transition cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-semibold">Đang Giám Định</span>
            <ClipboardCheck className="w-4 h-4 text-blue-400 group-hover:scale-110 transition" />
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black font-mono text-blue-400">{totalInProgress}</span>
            <span className="text-[10px] text-blue-400/80 font-medium">Tại bãi check</span>
          </div>
        </div>

        {/* Completed */}
        <div
          onClick={() => onNavigateToTab('completed')}
          className="p-4 bg-slate-900/90 border border-slate-800 rounded-2xl space-y-2 hover:border-emerald-500/50 transition cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-semibold">Đã Hoàn Tất Hôm Nay</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400 group-hover:scale-110 transition" />
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black font-mono text-emerald-400">{totalCompleted}</span>
            <span className="text-[10px] text-emerald-400/80 font-medium">Đã phát e-EIR</span>
          </div>
        </div>

        {/* AV Available */}
        <div className="p-4 bg-emerald-950/30 border border-emerald-800/40 rounded-2xl space-y-2">
          <div className="flex items-center justify-between text-emerald-400">
            <span className="text-[11px] font-bold">AV - Sẵn Sàng Cấp</span>
            <Sparkles className="w-4 h-4" />
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black font-mono text-emerald-400">{countAV}</span>
            <span className="text-[10px] font-mono text-emerald-300">
              {Math.round((countAV / (surveys.length || 1)) * 100)}%
            </span>
          </div>
        </div>

        {/* CL Cleaning */}
        <div className="p-4 bg-amber-950/30 border border-amber-800/40 rounded-2xl space-y-2">
          <div className="flex items-center justify-between text-amber-400">
            <span className="text-[11px] font-bold">CL - Cần Vệ Sinh</span>
            <AlertTriangle className="w-4 h-4" />
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black font-mono text-amber-400">{countCL}</span>
            <span className="text-[10px] font-mono text-amber-300">
              {Math.round((countCL / (surveys.length || 1)) * 100)}%
            </span>
          </div>
        </div>

        {/* DM Damaged */}
        <div className="p-4 bg-rose-950/30 border border-rose-800/40 rounded-2xl space-y-2">
          <div className="flex items-center justify-between text-rose-400">
            <span className="text-[11px] font-bold">DM - Cần Sửa Chữa</span>
            <Wrench className="w-4 h-4" />
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black font-mono text-rose-400">{countDM}</span>
            <span className="text-[10px] font-mono text-rose-300">{totalDamages} lỗi</span>
          </div>
        </div>
      </div>

      {/* Analytics Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Chart 1: Donut breakdown AV / CL / DM (4 cols) */}
        <div className="lg:col-span-4 p-5 bg-slate-900 border border-slate-800 rounded-3xl space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Tỷ Lệ Phân Loại (Grading Breakdown)</span>
            </h3>
            <span className="text-[10px] text-slate-400 font-mono">Hôm nay</span>
          </div>

          <div className="h-56 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={gradingData}
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {gradingData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} stroke="#0f172a" strokeWidth={2} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', fontSize: '12px' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="space-y-2 pt-2 border-t border-slate-800">
            {gradingData.map((item, idx) => (
              <div key={idx} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-slate-300 font-medium text-[11px]">{item.name}</span>
                </div>
                <span className="font-mono font-bold text-white">{item.value} Cont</span>
              </div>
            ))}
          </div>
        </div>

        {/* Chart 2: Carrier Distribution (8 cols) */}
        <div className="lg:col-span-8 p-5 bg-slate-900 border border-slate-800 rounded-3xl space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Ship className="w-4 h-4 text-blue-400" />
              <span>Sản Lượng &amp; Chất Lượng Vỏ Theo Hãng Tàu (Shipping Line)</span>
            </h3>
            <span className="text-[10px] text-slate-400 font-mono">AV vs CL vs DM</span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={carrierChartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="name" stroke="#64748b" fontSize={11} />
                <YAxis stroke="#64748b" fontSize={11} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', fontSize: '12px' }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                <Bar dataKey="AV" name="AV (Đạt chuẩn)" fill="#10b981" radius={[4, 4, 0, 0]} />
                <Bar dataKey="CL" name="CL (Cần vệ sinh)" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                <Bar dataKey="DM" name="DM (Hư hỏng)" fill="#ef4444" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Lower Analytics Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Chart 3: Survey Trend over 7 days (6 cols) */}
        <div className="lg:col-span-6 p-5 bg-slate-900 border border-slate-800 rounded-3xl space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-amber-400" />
              <span>Xu Hướng Giám Định 7 Ngày Gần Nhất (Survey Trends)</span>
            </h3>
            <span className="text-[10px] text-slate-400 font-mono">Sản lượng cont / ngày</span>
          </div>

          <div className="h-56 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={trendData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="date" stroke="#64748b" fontSize={11} />
                <YAxis stroke="#64748b" fontSize={11} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', fontSize: '12px' }}
                />
                <Line type="monotone" dataKey="count" name="Số lượng Survey" stroke="#f59e0b" strokeWidth={3} dot={{ r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 4: Damage distribution by Category (6 cols) */}
        <div className="lg:col-span-6 p-5 bg-slate-900 border border-slate-800 rounded-3xl space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Wrench className="w-4 h-4 text-rose-400" />
              <span>Phân Loại Tổn Thất Phổ Biến (Common Damage Types)</span>
            </h3>
            <span className="text-[10px] text-slate-400 font-mono">Tần suất xuất hiện</span>
          </div>

          <div className="h-56 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart layout="vertical" data={damageBarData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis type="number" stroke="#64748b" fontSize={11} />
                <YAxis dataKey="damageType" type="category" stroke="#94a3b8" fontSize={10} width={130} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', fontSize: '12px' }}
                />
                <Bar dataKey="count" name="Số vụ tổn thất" fill="#ef4444" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Quick Action Activity Queue Preview */}
      <div className="p-5 bg-slate-900 border border-slate-800 rounded-3xl space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Boxes className="w-4 h-4 text-amber-400" />
            <h3 className="text-sm font-bold text-white">Container Cần Surveyor Xử Lý Khẩn Cấp</h3>
          </div>
          <button
            onClick={() => onNavigateToTab('queue')}
            className="text-xs text-amber-400 hover:text-amber-300 font-semibold"
          >
            Xem tất cả ({surveys.length}) &rarr;
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {surveys.slice(0, 3).map((survey) => (
            <div
              key={survey.id}
              onClick={() => onSelectSurvey(survey)}
              className="p-3.5 bg-slate-950/70 border border-slate-800/80 rounded-2xl hover:border-amber-500/40 transition cursor-pointer space-y-2 group"
            >
              <div className="flex items-center justify-between">
                <span className="text-sm font-black font-mono text-amber-400 group-hover:text-amber-300">
                  {survey.containerNo}
                </span>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${
                  survey.condition === 'AV' ? 'bg-emerald-950 text-emerald-300 border-emerald-800' :
                  survey.condition === 'CL' ? 'bg-amber-950 text-amber-300 border-amber-800' :
                  'bg-rose-950 text-rose-300 border-rose-800'
                }`}>
                  {survey.condition}
                </span>
              </div>
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>{survey.shippingLine} &bull; {survey.size} {survey.type}</span>
                <span className="font-mono text-[11px] text-slate-300">{survey.surveyor?.split(' ')?.[0] || survey.surveyor || ''}</span>
              </div>
              <div className="text-[11px] text-slate-400 truncate pt-1 border-t border-slate-800">
                {survey.remarks || 'Chờ giám định tiêu chuẩn IICL'}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
