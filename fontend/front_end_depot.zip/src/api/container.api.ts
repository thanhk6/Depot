import apiClient from './axios';
import { API_ENDPOINTS } from './endpoints';
import { ApiResponse } from '../types/common';
import { DepotJob } from '../types/container';

export const containerApi = {
  getAll: async (params?: { searchKeyword?: string; shippingLine?: string; status?: string }) => {
    const res = await apiClient.get<ApiResponse<DepotJob[]>>(API_ENDPOINTS.DEPOT_JOBS.BASE, { params });
    return res.data;
  },
  getById: async (id: string) => {
    const res = await apiClient.get<ApiResponse<DepotJob>>(API_ENDPOINTS.DEPOT_JOBS.GET_BY_ID(id));
    return res.data;
  },
  createGateIn: async (data: Partial<DepotJob>) => {
    const res = await apiClient.post<ApiResponse<DepotJob>>(API_ENDPOINTS.DEPOT_JOBS.GATE_IN, data);
    return res.data;
  },
  getStats: async () => {
    const res = await apiClient.get<ApiResponse<any>>(API_ENDPOINTS.DEPOT_JOBS.STATS);
    return res.data;
  },
};

