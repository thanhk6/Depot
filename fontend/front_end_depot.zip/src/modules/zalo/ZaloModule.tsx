import React, { useState, useEffect } from 'react';
import { ZaloHeader, ZaloSubTab } from './components/ZaloHeader';
import { ZaloOverviewPage } from './pages/ZaloOverviewPage';
import { ZaloTemplatesPage } from './pages/ZaloTemplatesPage';
import { ZaloLogsPage } from './pages/ZaloLogsPage';
import { ZaloSettings } from '../notifications/pages/ZaloSettings';
import { ZaloSimulatorPage } from '../notifications/pages/ZaloSimulatorPage';

interface ZaloModuleProps {
  initialSubTab?: ZaloSubTab;
  onNavigateTab?: (tab: string) => void;
}

export const ZaloModule: React.FC<ZaloModuleProps> = ({
  initialSubTab = 'overview',
  onNavigateTab
}) => {
  const [currentSubTab, setCurrentSubTab] = useState<ZaloSubTab>(initialSubTab);

  useEffect(() => {
    if (initialSubTab) {
      setCurrentSubTab(initialSubTab);
    }
  }, [initialSubTab]);

  return (
    <div className="space-y-6">
      {/* Sub-Header Navigation */}
      <ZaloHeader
        currentTab={currentSubTab}
        onSelectTab={(tab) => setCurrentSubTab(tab)}
      />

      {/* Sub-Views */}
      <div className="animate-fade-in">
        {currentSubTab === 'overview' && (
          <ZaloOverviewPage
            onNavigateSubTab={(tab) => setCurrentSubTab(tab)}
            onNavigateTab={onNavigateTab}
          />
        )}

        {currentSubTab === 'simulator' && (
          <ZaloSimulatorPage onNavigateTab={onNavigateTab} />
        )}

        {currentSubTab === 'templates' && (
          <ZaloTemplatesPage
            onSelectSend={(tmplId) => {
              if (onNavigateTab) {
                onNavigateTab('notifications_send');
              }
            }}
          />
        )}

        {currentSubTab === 'settings' && <ZaloSettings />}

        {currentSubTab === 'logs' && <ZaloLogsPage />}
      </div>
    </div>
  );
};
