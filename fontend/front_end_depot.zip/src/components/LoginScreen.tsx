import React, { useState } from 'react';
import { useDepot } from '../context/DepotContext';
import { USER_ACCOUNT_PROFILES, authenticateUser, UserAccountProfile } from '../data/roleMenuConfig';
import {
  Container,
  Lock,
  User,
  KeyRound,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Eye,
  EyeOff,
  Sparkles,
  Layers,
  Terminal,
  Building2
} from 'lucide-react';

interface LoginScreenProps {
  onLoginSuccess: (user: UserAccountProfile) => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLoginSuccess }) => {
  const { setActiveRole, showToast } = useDepot();

  const [usernameInput, setUsernameInput] = useState('admin');
  const [passwordInput, setPasswordInput] = useState('123456');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setIsLoading(true);

    setTimeout(() => {
      const user = authenticateUser(usernameInput, passwordInput);
      setIsLoading(false);

      if (user) {
        setActiveRole(user.role);
        if (rememberMe) {
          localStorage.setItem('depot_logged_user_id', user.id);
        }
        showToast(`Đăng nhập hệ thống thành công! Chào mừng ${user.fullName}`, 'success', 'Đăng Nhập Thành Công');
        onLoginSuccess(user);
      } else {
        const errorText = 'Tên đăng nhập hoặc mật khẩu không chính xác!';
        setErrorMsg('Tên đăng nhập hoặc mật khẩu không chính xác! Vui lòng thử lại (hoặc chọn 1 tài khoản mẫu bên dưới).');
        showToast(errorText, 'error', 'Đăng Nhập Thất Bại');
      }
    }, 400);
  };

  const handleQuickLogin = (user: UserAccountProfile) => {
    setUsernameInput(user.username);
    setPasswordInput(user.passwordHash);
    setErrorMsg(null);
    setIsLoading(true);

    setTimeout(() => {
      setActiveRole(user.role);
      if (rememberMe) {
        localStorage.setItem('depot_logged_user_id', user.id);
      }
      setIsLoading(false);
      showToast(`Đăng nhập thành công với tài khoản mẫu [${user.fullName}]`, 'success', 'Đăng Nhập Thành Công');
      onLoginSuccess(user);
    }, 300);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between selection:bg-blue-600 selection:text-white">
      {/* Top Notification Bar */}
      <div className="bg-gradient-to-r from-blue-900 via-slate-900 to-purple-900 border-b border-blue-800/40 py-2 px-4 text-center text-xs text-blue-200 flex items-center justify-center gap-2">
        <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
        <span>Hệ Thống SolutionDepot 2026 — Phân quyền Menu riêng theo từng chức danh vận hành.</span>
        <span className="hidden md:inline text-blue-400">• Mật khẩu mặc định: <code className="bg-slate-950/80 px-1.5 py-0.5 rounded text-amber-300 font-mono">123456</code></span>
      </div>

      {/* Main Container */}
      <div className="max-w-7xl mx-auto px-4 py-8 sm:py-12 w-full flex-1 flex flex-col justify-center">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Form & Brand */}
          <div className="lg:col-span-5 bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl backdrop-blur-xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-40 h-40 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute bottom-0 left-0 w-40 h-40 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />

            {/* Brand Logo */}
            <div className="flex items-center gap-3 mb-6">
              <div className="p-3 bg-blue-600 text-white rounded-2xl shadow-lg shadow-blue-600/30 ring-1 ring-white/20">
                <Container className="w-8 h-8" />
              </div>
              <div>
                <h1 className="text-2xl font-black text-white tracking-tight flex items-center gap-2">
                  SolutionDepot
                  <span className="text-[10px] bg-blue-500/20 text-blue-300 border border-blue-500/30 px-2 py-0.5 rounded-full uppercase tracking-wider font-semibold">
                    v2.6 Enterprise
                  </span>
                </h1>
                <p className="text-xs text-slate-400">Hệ Thống Quản Lý Bãi Container Chuyên Nghiệp</p>
              </div>
            </div>

            <div className="mb-6">
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Lock className="w-5 h-5 text-blue-400" />
                Đăng Nhập Tài Khoản
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Nhập tên đăng nhập/email nhân viên hoặc chọn nhanh tài khoản bộ phận ở danh sách bên phải.
              </p>
            </div>

            {/* Error Message Alert */}
            {errorMsg && (
              <div className="mb-5 p-3.5 bg-rose-950/80 border border-rose-800/80 text-rose-200 rounded-xl text-xs flex items-start gap-2.5 animate-in fade-in">
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* Login Form */}
            <form onSubmit={handleFormSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Tên đăng nhập hoặc Email
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                    <User className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    required
                    value={usernameInput}
                    onChange={(e) => setUsernameInput(e.target.value)}
                    placeholder="Ví dụ: admin, surveyor, accountant..."
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Mật khẩu hệ thống
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                    <KeyRound className="w-4 h-4" />
                  </div>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={passwordInput}
                    onChange={(e) => setPasswordInput(e.target.value)}
                    placeholder="Nhập mật khẩu..."
                    className="w-full pl-10 pr-10 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-500 hover:text-slate-300 cursor-pointer"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between text-xs pt-1">
                <label className="flex items-center gap-2 cursor-pointer text-slate-400 hover:text-slate-200">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="rounded bg-slate-950 border-slate-800 text-blue-600 focus:ring-blue-500 w-3.5 h-3.5"
                  />
                  <span>Ghi nhớ phiên làm việc</span>
                </label>
                <span className="text-slate-500 text-[11px]">Pass mặc định: <strong>123456</strong></span>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3 px-4 bg-blue-600 hover:bg-blue-500 disabled:bg-blue-800 text-white font-bold text-xs rounded-xl shadow-lg shadow-blue-600/30 transition duration-150 flex items-center justify-center gap-2 cursor-pointer mt-2"
              >
                {isLoading ? (
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <>
                    <span>Đăng Nhập Vào Hệ Thống</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>

            {/* Architecture Footer Note */}
            <div className="mt-6 pt-5 border-t border-slate-800/80 text-[11px] text-slate-400 space-y-2">
              <div className="flex items-center gap-2 text-slate-300 font-semibold">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Kiến trúc RBAC & .NET Core 8 Web API:</span>
              </div>
              <p className="leading-relaxed">
                Khi đăng nhập, hệ thống sẽ tự động cấp Menu riêng biệt & giới hạn tab truy cập phù hợp với đúng vai trò người dùng (Manager, Surveyor, Operator, Accountant...).
              </p>
            </div>
          </div>

          {/* Right Column: Interactive Quick Login Cards for all 9 Profiles */}
          <div className="lg:col-span-7 space-y-4">
            <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-5 backdrop-blur-md">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Building2 className="w-5 h-5 text-purple-400" />
                  <h3 className="font-bold text-white text-sm">Chọn Nhanh Tài Khoản Mẫu Theo Bộ Phận (9 Roles)</h3>
                </div>
                <span className="text-[11px] bg-purple-500/10 text-purple-300 border border-purple-500/30 px-2 py-0.5 rounded-full font-medium">
                  Click 1 phát là đăng nhập ngay
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Thử nghiệm phân quyền Menu cá nhân hóa cho từng phòng ban trong hệ thống Vận Hành Depot Container:
              </p>
            </div>

            {/* Profile Cards Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-[580px] overflow-y-auto pr-1 scrollbar-thin">
              {USER_ACCOUNT_PROFILES.map((usr) => (
                <div
                  key={usr.id}
                  onClick={() => handleQuickLogin(usr)}
                  className="bg-slate-900 border border-slate-800/80 hover:border-blue-500/60 hover:bg-slate-800/80 p-3.5 rounded-2xl transition-all cursor-pointer group relative overflow-hidden flex flex-col justify-between"
                >
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2.5">
                      <div className={`w-9 h-9 rounded-xl ${usr.avatarBg} text-white font-bold text-xs flex items-center justify-center ring-1 ring-white/20 group-hover:scale-105 transition-transform`}>
                        {usr.avatarText}
                      </div>
                      <div>
                        <h4 className="font-bold text-xs text-white group-hover:text-blue-300 transition-colors">
                          {usr.fullName}
                        </h4>
                        <p className="text-[11px] text-slate-400">{usr.jobTitle}</p>
                      </div>
                    </div>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold border shrink-0 ${usr.badgeBg}`}>
                      {(usr.badgeText || '').split(' ')?.[0] || ''}
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-400 mb-2.5 line-clamp-2">
                    {usr.roleDescription}
                  </p>

                  <div className="pt-2 border-t border-slate-800/60 flex items-center justify-between text-[10px] text-slate-400">
                    <span className="flex items-center gap-1">
                      <Layers className="w-3 h-3 text-blue-400" /> Menu: <strong className="text-slate-200">{usr.allowedTabs?.length || 0} chức năng</strong>
                    </span>
                    <span className="text-blue-400 group-hover:translate-x-1 transition-transform font-bold flex items-center gap-0.5">
                      Đăng nhập <ArrowRight className="w-3 h-3" />
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>

      {/* Footer copyright */}
      <div className="border-t border-slate-900 py-4 px-4 text-center text-xs text-slate-400">
        <p>© 2026 SolutionDepot Enterprise System • Cung cấp giải pháp Quản Lý Bãi Container chuẩn IICL cho Cảng & Depot Việt Nam</p>
      </div>
    </div>
  );
};
