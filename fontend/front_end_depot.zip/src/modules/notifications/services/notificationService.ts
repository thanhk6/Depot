import {
  NotificationEmployee,
  NotificationCustomer,
  NotificationTemplate,
  NotificationRecord,
  NotificationQueueItem,
  ZaloSettingsConfig,
  NotificationDashboardKPIs,
  SendNotificationRequest,
  CustomerNotificationPreference
} from '../models/notification.types';

import {
  MOCK_NOTIFICATION_EMPLOYEES,
  MOCK_NOTIFICATION_CUSTOMERS,
  MOCK_NOTIFICATION_TEMPLATES,
  MOCK_NOTIFICATION_HISTORY,
  MOCK_NOTIFICATION_QUEUE,
  MOCK_ZALO_SETTINGS,
  MOCK_DASHBOARD_KPIS
} from '../mock/notification.mock';

// In-memory state holding the mock data during session
let employeesState: NotificationEmployee[] = [...MOCK_NOTIFICATION_EMPLOYEES];
let customersState: NotificationCustomer[] = [...MOCK_NOTIFICATION_CUSTOMERS];
let templatesState: NotificationTemplate[] = [...MOCK_NOTIFICATION_TEMPLATES];
let historyState: NotificationRecord[] = [...MOCK_NOTIFICATION_HISTORY];
let queueState: NotificationQueueItem[] = [...MOCK_NOTIFICATION_QUEUE];
let zaloSettingsState: ZaloSettingsConfig = { ...MOCK_ZALO_SETTINGS };

/**
 * Notification Service Interface & Mock Implementation
 * Ready for future .NET 8 REST API integration without changing UI contracts.
 */
export const notificationService = {
  // ==========================================
  // DASHBOARD & STATS
  // ==========================================
  getDashboardMetrics: async (): Promise<NotificationDashboardKPIs> => {
    // Simulate async network latency
    await new Promise((res) => setTimeout(res, 80));

    const totalToday = historyState.filter((h) => h.createdAt.startsWith('2026-08-17')).length;
    const sentSuccess = historyState.filter(
      (h) => h.createdAt.startsWith('2026-08-17') && h.status === 'SENT'
    ).length;
    const failedCount = historyState.filter(
      (h) => h.createdAt.startsWith('2026-08-17') && h.status === 'FAILED'
    ).length;
    const pendingQueue = queueState.filter((q) => q.status === 'PENDING').length;
    const activeEmployeesZalo = employeesState.filter((e) => e.zaloConnected && e.isActive).length;
    const activeCustomersZalo = customersState.filter((c) => c.zaloConnected && c.isActive).length;
    const successRate = totalToday > 0 ? Number(((sentSuccess / totalToday) * 100).toFixed(1)) : 100;

    return {
      ...MOCK_DASHBOARD_KPIS,
      totalToday: totalToday || 128,
      sentSuccess: sentSuccess || 119,
      pendingQueue: pendingQueue || 5,
      failedCount: failedCount || 4,
      activeEmployeesZalo,
      activeCustomersZalo,
      successRate
    };
  },

  // ==========================================
  // EMPLOYEES
  // ==========================================
  getEmployees: async (filters?: {
    department?: string;
    search?: string;
    zaloStatus?: string;
  }): Promise<NotificationEmployee[]> => {
    await new Promise((res) => setTimeout(res, 60));
    let list = [...employeesState];
    if (filters?.department && filters.department !== 'ALL') {
      list = list.filter((e) => e.department.includes(filters.department!));
    }
    if (filters?.zaloStatus && filters.zaloStatus !== 'ALL') {
      list = list.filter((e) => e.zaloStatus === filters.zaloStatus);
    }
    if (filters?.search) {
      const q = filters.search.toLowerCase();
      list = list.filter(
        (e) =>
          e.name.toLowerCase().includes(q) ||
          e.phone.includes(q) ||
          e.department.toLowerCase().includes(q) ||
          e.role.toLowerCase().includes(q) ||
          e.zaloName.toLowerCase().includes(q)
      );
    }
    return list;
  },

  getEmployeeById: async (id: string): Promise<NotificationEmployee | undefined> => {
    return employeesState.find((e) => e.id === id);
  },

  updateEmployeeSubscribedEvents: async (
    id: string,
    events: NotificationEmployee['subscribedEvents']
  ): Promise<NotificationEmployee> => {
    employeesState = employeesState.map((e) => (e.id === id ? { ...e, subscribedEvents: events } : e));
    const updated = employeesState.find((e) => e.id === id)!;
    return updated;
  },

  // ==========================================
  // CUSTOMERS
  // ==========================================
  getCustomers: async (filters?: {
    customerType?: string;
    search?: string;
    zaloStatus?: string;
  }): Promise<NotificationCustomer[]> => {
    await new Promise((res) => setTimeout(res, 60));
    let list = [...customersState];
    if (filters?.customerType && filters.customerType !== 'ALL') {
      list = list.filter((c) => c.customerType === filters.customerType);
    }
    if (filters?.zaloStatus && filters.zaloStatus !== 'ALL') {
      list = list.filter((c) => c.zaloStatus === filters.zaloStatus);
    }
    if (filters?.search) {
      const q = filters.search.toLowerCase();
      list = list.filter(
        (c) =>
          c.name.toLowerCase().includes(q) ||
          c.code.toLowerCase().includes(q) ||
          c.contactPerson.toLowerCase().includes(q) ||
          c.phone.includes(q) ||
          c.email.toLowerCase().includes(q)
      );
    }
    return list;
  },

  getCustomerById: async (id: string): Promise<NotificationCustomer | undefined> => {
    await new Promise((res) => setTimeout(res, 40));
    return customersState.find((c) => c.id === id || c.code === id);
  },

  updateCustomerPreferences: async (
    id: string,
    preferences: Partial<CustomerNotificationPreference>
  ): Promise<NotificationCustomer> => {
    await new Promise((res) => setTimeout(res, 100));
    customersState = customersState.map((c) =>
      c.id === id ? { ...c, preferences: { ...c.preferences, ...preferences } } : c
    );
    const updated = customersState.find((c) => c.id === id)!;
    return updated;
  },

  // ==========================================
  // TEMPLATES
  // ==========================================
  getNotificationTemplates: async (search?: string): Promise<NotificationTemplate[]> => {
    await new Promise((res) => setTimeout(res, 50));
    let list = [...templatesState];
    if (search) {
      const q = search.toLowerCase();
      list = list.filter(
        (t) =>
          t.name.toLowerCase().includes(q) ||
          t.code.toLowerCase().includes(q) ||
          t.eventType.toLowerCase().includes(q)
      );
    }
    return list;
  },

  getTemplateByIdOrCode: async (idOrCode: string): Promise<NotificationTemplate | undefined> => {
    return templatesState.find((t) => t.id === idOrCode || t.code === idOrCode);
  },

  createNotificationTemplate: async (
    template: Omit<NotificationTemplate, 'id' | 'createdAt' | 'updatedAt'>
  ): Promise<NotificationTemplate> => {
    await new Promise((res) => setTimeout(res, 120));
    const newTemplate: NotificationTemplate = {
      ...template,
      id: `TMPL-${String(templatesState.length + 1).padStart(3, '0')}`,
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
      updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 19)
    };
    templatesState = [newTemplate, ...templatesState];
    return newTemplate;
  },

  updateNotificationTemplate: async (
    id: string,
    data: Partial<NotificationTemplate>
  ): Promise<NotificationTemplate> => {
    await new Promise((res) => setTimeout(res, 100));
    templatesState = templatesState.map((t) =>
      t.id === id
        ? {
            ...t,
            ...data,
            updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 19)
          }
        : t
    );
    const updated = templatesState.find((t) => t.id === id)!;
    return updated;
  },

  deleteNotificationTemplate: async (id: string): Promise<boolean> => {
    await new Promise((res) => setTimeout(res, 80));
    templatesState = templatesState.filter((t) => t.id !== id);
    return true;
  },

  // ==========================================
  // SEND NOTIFICATION
  // ==========================================
  sendNotification: async (
    req: SendNotificationRequest
  ): Promise<{ success: boolean; sentCount: number; records: NotificationRecord[] }> => {
    await new Promise((res) => setTimeout(res, 250));

    const createdRecords: NotificationRecord[] = [];
    const template = req.templateId ? templatesState.find((t) => t.id === req.templateId || t.code === req.templateId) : undefined;
    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);

    req.recipientIds.forEach((rId, idx) => {
      const emp = employeesState.find((e) => e.id === rId);
      const cust = customersState.find((c) => c.id === rId);
      const name = emp ? emp.name : cust ? cust.name : 'Người nhận';
      const phone = emp ? emp.phone : cust ? cust.phone : '0900000000';
      const zaloId = emp ? emp.zaloId : cust ? cust.zaloId : undefined;

      let title = req.customTitle || (template ? template.titleTemplate : 'Thông báo EMR Depot');
      let content = req.customContent || (template ? template.contentTemplate : 'Nội dung thông báo');

      // Replace placeholders if parameters provided
      if (req.parameters) {
        Object.entries(req.parameters).forEach(([k, v]) => {
          title = title.replaceAll(k, v);
          content = content.replaceAll(k, v);
        });
      }

      const newRecord: NotificationRecord = {
        id: `NOTIF-${Date.now()}-${idx}`,
        trackingCode: `ZALO-MSG-${Math.floor(10000 + Math.random() * 90000)}`,
        templateCode: template ? template.code : 'CUSTOM_DIRECT_MSG',
        templateName: template ? template.name : 'Thông Báo Trực Tiếp',
        eventType: template ? template.eventType : 'GATE_IN_COMPLETED',
        recipientType: req.targetAudience,
        recipientId: rId,
        recipientName: name,
        recipientPhone: phone,
        recipientZaloId: zaloId,
        channel: req.channel,
        title,
        content,
        status: 'SENT',
        priority: req.priority || 'NORMAL',
        entityType: req.entityType || 'Container',
        entityId: req.entityId || `CONT-${Date.now()}`,
        entityReference: req.entityReference || 'CONT1234567',
        retryCount: 0,
        maxRetries: 3,
        createdAt: now,
        sentAt: now,
        requestPayload: {
          to: zaloId || phone,
          channel: req.channel,
          title,
          content
        },
        responsePayload: {
          error: 0,
          message: 'Success',
          msg_id: `zmsg_${Math.floor(10000000 + Math.random() * 90000000)}`
        },
        isRead: false
      };

      createdRecords.push(newRecord);
    });

    historyState = [...createdRecords, ...historyState];
    return {
      success: true,
      sentCount: createdRecords.length,
      records: createdRecords
    };
  },

  // ==========================================
  // NOTIFICATION HISTORY
  // ==========================================
  getNotificationHistory: async (filters?: {
    status?: string;
    channel?: string;
    recipientType?: string;
    eventType?: string;
    search?: string;
    limit?: number;
    offset?: number;
  }): Promise<{ items: NotificationRecord[]; total: number }> => {
    await new Promise((res) => setTimeout(res, 70));
    let list = [...historyState];

    if (filters?.status && filters.status !== 'ALL') {
      list = list.filter((h) => h.status === filters.status);
    }
    if (filters?.channel && filters.channel !== 'ALL') {
      list = list.filter((h) => h.channel === filters.channel);
    }
    if (filters?.recipientType && filters.recipientType !== 'ALL') {
      list = list.filter((h) => h.recipientType === filters.recipientType);
    }
    if (filters?.eventType && filters.eventType !== 'ALL') {
      list = list.filter((h) => h.eventType === filters.eventType);
    }
    if (filters?.search) {
      const q = filters.search.toLowerCase();
      list = list.filter(
        (h) =>
          h.recipientName.toLowerCase().includes(q) ||
          h.recipientPhone.includes(q) ||
          h.trackingCode.toLowerCase().includes(q) ||
          h.title.toLowerCase().includes(q) ||
          (h.entityReference && h.entityReference.toLowerCase().includes(q))
      );
    }

    return {
      items: list,
      total: list.length
    };
  },

  getNotificationById: async (id: string): Promise<NotificationRecord | undefined> => {
    return historyState.find((h) => h.id === id);
  },

  resendNotification: async (id: string): Promise<NotificationRecord> => {
    await new Promise((res) => setTimeout(res, 200));
    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);
    historyState = historyState.map((h) =>
      h.id === id
        ? {
            ...h,
            status: 'SENT',
            retryCount: h.retryCount + 1,
            sentAt: now,
            errorMessage: undefined
          }
        : h
    );
    return historyState.find((h) => h.id === id)!;
  },

  // ==========================================
  // NOTIFICATION QUEUE
  // ==========================================
  getNotificationQueue: async (filters?: {
    priority?: string;
    status?: string;
    search?: string;
  }): Promise<NotificationQueueItem[]> => {
    await new Promise((res) => setTimeout(res, 60));
    let list = [...queueState];
    if (filters?.priority && filters.priority !== 'ALL') {
      list = list.filter((q) => q.priority === filters.priority);
    }
    if (filters?.status && filters.status !== 'ALL') {
      list = list.filter((q) => q.status === filters.status);
    }
    if (filters?.search) {
      const q = filters.search.toLowerCase();
      list = list.filter(
        (item) =>
          item.queueCode.toLowerCase().includes(q) ||
          item.recipientName.toLowerCase().includes(q) ||
          item.title.toLowerCase().includes(q) ||
          (item.entityReference && item.entityReference.toLowerCase().includes(q))
      );
    }
    return list;
  },

  retryQueueItem: async (id: string): Promise<NotificationQueueItem> => {
    await new Promise((res) => setTimeout(res, 150));
    queueState = queueState.map((q) => (q.id === id ? { ...q, retryCount: q.retryCount + 1 } : q));
    return queueState.find((q) => q.id === id)!;
  },

  cancelQueueItem: async (id: string): Promise<boolean> => {
    await new Promise((res) => setTimeout(res, 80));
    queueState = queueState.map((q) => (q.id === id ? { ...q, status: 'CANCELLED' } : q));
    return true;
  },

  processAllQueue: async (): Promise<{ processedCount: number }> => {
    await new Promise((res) => setTimeout(res, 350));
    const count = queueState.filter((q) => q.status === 'PENDING').length;
    queueState = queueState.map((q) => ({ ...q, status: 'SENT' }));
    return { processedCount: count };
  },

  // ==========================================
  // ZALO SETTINGS & CONNECTION
  // ==========================================
  getZaloSettings: async (): Promise<ZaloSettingsConfig> => {
    await new Promise((res) => setTimeout(res, 50));
    return { ...zaloSettingsState };
  },

  updateZaloSettings: async (settings: Partial<ZaloSettingsConfig>): Promise<ZaloSettingsConfig> => {
    await new Promise((res) => setTimeout(res, 120));
    zaloSettingsState = { ...zaloSettingsState, ...settings };
    return { ...zaloSettingsState };
  },

  testZaloConnection: async (): Promise<{
    success: boolean;
    oaName: string;
    oaId: string;
    followersCount: number;
    quotaRemaining: number;
    latencyMs: number;
    message: string;
  }> => {
    await new Promise((res) => setTimeout(res, 400));
    return {
      success: true,
      oaName: 'EMR DEPOT CONTAINER NOTIFICATION GATEWAY',
      oaId: zaloSettingsState.oaId || '38192847192837192',
      followersCount: 1485,
      quotaRemaining: 4872,
      latencyMs: 142,
      message: 'Kết nối Zalo Official Account & ZNS Gateway thành công 100%!'
    };
  }
};
