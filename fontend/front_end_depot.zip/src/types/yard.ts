import { YardLocation } from './container';

export interface YardBlockConfig {
  code: string;
  name: string;
  totalBays: number;
  rowsPerBay: number;
  maxTiers: number;
  allocatedShippingLines: string[];
  currentOccupancy: number;
  maxCapacity: number;
}

export interface ForkliftTask {
  id: string;
  jobId: string;
  containerNo: string;
  fromLocation: YardLocation;
  toLocation: YardLocation;
  forkliftDriverName: string;
  purpose: 'GATE_IN_LOWER' | 'REPAIR_MOVE' | 'GATE_OUT_LIFT' | 'YARD_SHUFFLE';
  assignedTime: string;
  completedTime?: string;
  isCompleted: boolean;
}
