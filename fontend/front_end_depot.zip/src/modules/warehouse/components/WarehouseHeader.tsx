import React from 'react';
import { Warehouse, Plus, ArrowDownToLine, ArrowUpFromLine, Receipt, BookOpen, Layers, Sparkles } from 'lucide-react';
import { WAREHOUSE_INFO } from '../types';

interface WarehouseHeaderProps {
  activeSubTab: string;
  onSelectSubTab: (tabId: string) => void;
  onOpenCreateReceipt: () => void;
  onOpenCreateIssue: () => void;
  onOpenCreateMaterial?: () => void;
}

export const WarehouseHeader: React.FC<WarehouseHeaderProps> = ({
  activeSubTab,
  onSelectSubTab,
  onOpenCreateReceipt,
  onOpenCreateIssue,
  onOpenCreateMaterial
}) => {
  const tabs = [
    { id: 'stock_balance', label: '1. Báo Cáo Nhập - Xuất - Tồn', icon: <Layers className="w-4 h-4 text-amber-400" /> },
    { id: 'receipts', label: '2. Phiếu Nhập Kho (PNK)', icon: <ArrowDownToLine className="w-4 h-4 text-emerald-400" /> },
    { id: 'issues', label: '3. Phiếu Xuất Kho (PXK)', icon: <ArrowUpFromLine className="w-4 h-4 text-rose-400" /> },
    { id: 'transactions', label: '4. Sổ Thẻ Kho & Lịch Sử', icon: <Receipt className="w-4 h-4 text-purple-400" /> },
    { id: 'catalog', label: '5. Danh Mục Vật Tư', icon: <BookOpen className="w-4 h-4 text-sky-400" /> }
  ];

  return (
    <div className="space-y-4">
      {/* Top Banner */}
      <div className="p-5 sm:p-6 bg-slate-900 border border-slate-800 rounded-3xl flex flex-col lg:flex-row lg:items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center gap-4">
          <div className="p-3.5 bg-amber-500/10 border border-amber-500/20 text-amber-400 rounded-2xl shrink-0">
            <Warehouse className="w-8 h-8" />
          </div>
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <h1 className="text-xl font-black text-white tracking-tight">
                QUẢN LÝ VẬT TƯ (NHẬP - XUẤT - TỒN KHO EMR)
              </h1>
              <span className="px-2.5 py-0.5 bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded-full font-mono text-[11px] font-bold">
                MÃ KHO: {WAREHOUSE_INFO.code}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Ghi nhận nhập vật tư, xuất vật tư sửa chữa và tự động tính toán số lượng tồn kho theo thời gian thực
            </p>
          </div>
        </div>

        {/* Quick Action Buttons */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={onOpenCreateReceipt}
            className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs rounded-xl flex items-center gap-1.5 shadow-lg shadow-emerald-600/20 transition whitespace-nowrap cursor-pointer active:scale-95"
          >
            <ArrowDownToLine className="w-4 h-4" />
            <span>+ Nhập Vật Tư</span>
          </button>
          <button
            onClick={onOpenCreateIssue}
            className="px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs rounded-xl flex items-center gap-1.5 shadow-lg shadow-amber-500/20 transition whitespace-nowrap cursor-pointer active:scale-95"
          >
            <ArrowUpFromLine className="w-4 h-4" />
            <span>- Xuất Vật Tư</span>
          </button>
          {onOpenCreateMaterial && (
            <button
              onClick={onOpenCreateMaterial}
              className="px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-sky-400 font-bold text-xs rounded-xl flex items-center gap-1.5 border border-slate-700 transition whitespace-nowrap cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>+ Thêm Mã Vật Tư</span>
            </button>
          )}
        </div>
      </div>

      {/* Sub Tab Navigation */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 border-b border-slate-800 scrollbar-thin">
        {tabs.map((t) => {
          const isActive = activeSubTab === t.id;
          return (
            <button
              key={t.id}
              onClick={() => onSelectSubTab(t.id)}
              className={`px-4 py-2.5 rounded-2xl text-xs font-bold whitespace-nowrap transition flex items-center gap-2 cursor-pointer ${
                isActive
                  ? 'bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/20 font-black'
                  : 'bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {t.icon}
              <span>{t.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
