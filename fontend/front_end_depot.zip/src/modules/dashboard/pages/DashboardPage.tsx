import React from 'react';
import { ContainerRecord } from '../../../services/mockDataStore';
import { formatVND } from '../../../utils/format';
import { StatusBadge } from '../../../components/common/StatusBadge/StatusBadge';
import { GateInSurveyWorkflowDiagram } from '../../../components/common/WorkflowDiagram/GateInSurveyWorkflowDiagram';
import {
  Container as ContainerIcon,
  LogIn,
  LogOut,
  CheckCircle2,
  AlertTriangle,
  Wrench,
  ShieldCheck,
  CreditCard,
  Truck,
  TrendingUp,
  DollarSign,
  Grid3X3,
  Layers,
  ArrowRight
} from 'lucide-react';

interface DashboardPageProps {
  containers: ContainerRecord[];
  onNavigateTab: (tabId: string) => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({
  containers,
  onNavigateTab
}) => {
  // Metric Calculations
  const totalInDepot = containers.filter((c) => c.status !== 'GATE_OUT').length;
  const gateInToday = containers.length;
  const gateOutToday = containers.filter((c) => c.status === 'GATE_OUT').length;

  const countAV = containers.filter((c) => c.condition === 'AV' && c.status !== 'GATE_OUT').length;
  const countCL = containers.filter((c) => c.condition === 'CL' && c.status !== 'GATE_OUT').length;
  const countDM = containers.filter((c) => c.condition === 'DM' && c.status !== 'GATE_OUT').length;

  const countRepairing = containers.filter((c) => c.status === 'REPAIRING').length;
  const countWaitingQC = containers.filter((c) => c.status === 'WAITING_QC').length;
  const countWaitingPayment = containers.filter((c) => c.status === 'WAITING_PAYMENT').length;
  const countWaitingForklift = containers.filter((c) => c.status === 'WAITING_FORKLIFT').length;

  const totalRevenue = containers.reduce(
    (sum, c) => sum + (c.tariffDetails?.total || 0),
    0
  );
  const totalCarrierDebt = containers.reduce(
    (sum, c) => sum + (c.estimateDetails?.totalCost || 0),
    0
  );

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="p-6 bg-gradient-to-r from-blue-900/60 via-slate-900 to-indigo-950 border border-blue-500/30 rounded-3xl shadow-2xl relative overflow-hidden flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-2 relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-500/20 text-blue-300 rounded-full border border-blue-400/30 text-xs font-bold font-mono">
            <Layers className="w-3.5 h-3.5" />
            <span>SOLUTION DEPOT WORKFLOW ENGINE</span>
          </div>
          <h2 className="text-2xl font-black text-white tracking-tight">
            Bảng Điều Khiển Trung Tâm Vận Hành Depot
          </h2>
          <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
            Giám sát thời gian thực toàn bộ 14 bước vòng đời Container: Giám định IICL, Gạch nợ VietQR, Điều bãi Xe nâng 2D, Báo giá EMR & Nghiệm thu QC.
          </p>
        </div>

        <div className="flex items-center gap-3 relative z-10">
          <button
            onClick={() => onNavigateTab('gate')}
            className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-2xl shadow-lg shadow-blue-600/30 transition flex items-center gap-2 cursor-pointer"
          >
            <LogIn className="w-4 h-4" />
            <span>Check-in Gate-In</span>
          </button>
          <button
            onClick={() => onNavigateTab('yard_map')}
            className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-2xl border border-slate-700 transition flex items-center gap-2 cursor-pointer"
          >
            <Grid3X3 className="w-4 h-4 text-teal-400" />
            <span>Sơ Đồ Bãi 2D</span>
          </button>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-semibold">Tồn Bãi Hiện Tại</span>
            <ContainerIcon className="w-4 h-4 text-blue-400" />
          </div>
          <p className="text-2xl font-black text-white">{totalInDepot}</p>
          <span className="text-[10px] text-emerald-400 font-medium">Cont trong bãi</span>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-semibold">Gate-In Hôm Nay</span>
            <LogIn className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-2xl font-black text-emerald-400">{gateInToday}</p>
          <span className="text-[10px] text-slate-400">Xe hạ cont</span>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-semibold">Gate-Out Hôm Nay</span>
            <LogOut className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-2xl font-black text-amber-400">{gateOutToday}</p>
          <span className="text-[10px] text-slate-400">Xe nhận vỏ</span>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-semibold">Container AV</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-2xl font-black text-white">{countAV}</p>
          <span className="text-[10px] text-emerald-400">Sẵn sàng cấp trả</span>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-semibold">Container CL</span>
            <AlertTriangle className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-2xl font-black text-amber-400">{countCL}</p>
          <span className="text-[10px] text-slate-400">Cần vệ sinh</span>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-semibold">Container DM</span>
            <Wrench className="w-4 h-4 text-rose-400" />
          </div>
          <p className="text-2xl font-black text-rose-400">{countDM}</p>
          <span className="text-[10px] text-slate-400">Cần sửa chữa EMR</span>
        </div>
      </div>

      {/* Interactive Operational Flowchart Diagram */}
      <GateInSurveyWorkflowDiagram containers={containers} onNavigateTab={onNavigateTab} />

      {/* Financial & Operational Status Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Doanh thu & Cước */}
        <div className="p-5 bg-slate-900 border border-slate-800 rounded-3xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-emerald-400" />
              <span>Thống Kê Tài Chính</span>
            </h3>
            <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800">
              REAL-TIME
            </span>
          </div>

          <div className="space-y-3">
            <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800/80 flex items-center justify-between">
              <div>
                <span className="text-xs text-slate-400 font-medium">Doanh Thu Thu Ngân (VietQR)</span>
                <p className="text-lg font-black text-emerald-400">{formatVND(totalRevenue)}</p>
              </div>
              <CreditCard className="w-6 h-6 text-emerald-400" />
            </div>

            <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800/80 flex items-center justify-between">
              <div>
                <span className="text-xs text-slate-400 font-medium">Công Nợ Báo Giá Hãng Tàu</span>
                <p className="text-lg font-black text-blue-400">{formatVND(totalCarrierDebt)}</p>
              </div>
              <TrendingUp className="w-6 h-6 text-blue-400" />
            </div>
          </div>
        </div>

        {/* Trạng Thái Chờ Trong Quy Trình */}
        <div className="p-5 bg-slate-900 border border-slate-800 rounded-3xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Truck className="w-4 h-4 text-amber-400" />
              <span>Tiến Độ Tự Động Hóa Workflow</span>
            </h3>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div
              onClick={() => onNavigateTab('payment')}
              className="p-3 bg-amber-950/20 border border-amber-800/40 rounded-2xl cursor-pointer hover:bg-amber-950/40 transition"
            >
              <span className="text-[10px] text-amber-300 font-bold block">Chờ Thanh Toán</span>
              <p className="text-xl font-black text-amber-400 mt-1">{countWaitingPayment}</p>
            </div>

            <div
              onClick={() => onNavigateTab('forklift')}
              className="p-3 bg-sky-950/20 border border-sky-800/40 rounded-2xl cursor-pointer hover:bg-sky-950/40 transition"
            >
              <span className="text-[10px] text-sky-300 font-bold block">Chờ Xe Nâng</span>
              <p className="text-xl font-black text-sky-400 mt-1">{countWaitingForklift}</p>
            </div>

            <div
              onClick={() => onNavigateTab('repair')}
              className="p-3 bg-rose-950/20 border border-rose-800/40 rounded-2xl cursor-pointer hover:bg-rose-950/40 transition"
            >
              <span className="text-[10px] text-rose-300 font-bold block">Đang Sửa Chữa</span>
              <p className="text-xl font-black text-rose-400 mt-1">{countRepairing}</p>
            </div>

            <div
              onClick={() => onNavigateTab('qc')}
              className="p-3 bg-purple-950/20 border border-purple-800/40 rounded-2xl cursor-pointer hover:bg-purple-950/40 transition"
            >
              <span className="text-[10px] text-purple-300 font-bold block">Chờ QC Kiểm Tra</span>
              <p className="text-xl font-black text-purple-400 mt-1">{countWaitingQC}</p>
            </div>
          </div>
        </div>

        {/* Tải Bãi Depot (Yard Occupancy) */}
        <div className="p-5 bg-slate-900 border border-slate-800 rounded-3xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Grid3X3 className="w-4 h-4 text-teal-400" />
              <span>Sức Chứa Bãi Depot</span>
            </h3>
            <span className="text-[10px] text-slate-400 font-mono">1,200 TEU</span>
          </div>

          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-xs font-semibold mb-1">
                <span className="text-slate-300">Block A (Khu EMR Sửa Chữa)</span>
                <span className="text-rose-400">75% (180/240 TEU)</span>
              </div>
              <div className="w-full h-2.5 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                <div className="h-full bg-rose-500 rounded-full w-[75%]" />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-semibold mb-1">
                <span className="text-slate-300">Block B (Khu Cấp Trả AV)</span>
                <span className="text-emerald-400">42% (210/500 TEU)</span>
              </div>
              <div className="w-full h-2.5 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                <div className="h-full bg-emerald-500 rounded-full w-[42%]" />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-semibold mb-1">
                <span className="text-slate-300">Block C (Khu Cont Lạnh Reefer)</span>
                <span className="text-amber-400">60% (120/200 TEU)</span>
              </div>
              <div className="w-full h-2.5 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                <div className="h-full bg-amber-500 rounded-full w-[60%]" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Danh Sách Container Vận Hành Gần Đây */}
      <div className="p-5 bg-slate-900 border border-slate-800 rounded-3xl space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <ContainerIcon className="w-4 h-4 text-blue-400" />
            <span>Danh Sách Container Vận Hành Mới Nhất</span>
          </h3>
          <button
            onClick={() => onNavigateTab('container')}
            className="text-xs text-blue-400 hover:text-blue-300 font-semibold flex items-center gap-1 cursor-pointer"
          >
            <span>Xem tất cả ({containers.length})</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-950/60">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-900/90 text-slate-400 font-semibold border-b border-slate-800">
              <tr>
                <th className="px-4 py-3">Số Container</th>
                <th className="px-4 py-3">ISO / Kích Thước</th>
                <th className="px-4 py-3">Hãng Tàu</th>
                <th className="px-4 py-3">Phân Loại</th>
                <th className="px-4 py-3">Trạng Thái Workflow</th>
                <th className="px-4 py-3">Vị Trí Bãi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {containers.slice(0, 5).map((c) => (
                <tr
                  key={c.id}
                  onClick={() => onNavigateTab('container')}
                  className="hover:bg-slate-800/50 cursor-pointer transition"
                >
                  <td className="px-4 py-3 font-mono font-bold text-white">{c.containerNo}</td>
                  <td className="px-4 py-3">{c.size} ({c.isoCode})</td>
                  <td className="px-4 py-3 font-semibold text-blue-400">{c.shippingLine}</td>
                  <td className="px-4 py-3">
                    <StatusBadge status={c.condition} size="sm" />
                  </td>
                  <td className="px-4 py-3">
                    <StatusBadge status={c.status} size="sm" />
                  </td>
                  <td className="px-4 py-3 font-mono text-slate-300">
                    {c.yardLocation
                      ? `Blk ${c.yardLocation.block} / Bay ${c.yardLocation.bay} / Row ${c.yardLocation.row}`
                      : 'Cổng Gate-In'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
