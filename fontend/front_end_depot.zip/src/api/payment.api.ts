import apiClient from './axios';
import { API_ENDPOINTS } from './endpoints';
import { ApiResponse } from '../types/common';
import { PaymentRecord } from '../types/container';

export const paymentApi = {
  processPayment: async (jobId: string, method: string, txRef: string, amount: number) => {
    const res = await apiClient.post<ApiResponse<PaymentRecord>>(`/depot/jobs/${jobId}/payment`, { method, txRef, amount });
    return res.data;
  },
  processBankWebhook: async (content: string, amount: number) => {
    const res = await apiClient.post<ApiResponse<string>>(API_ENDPOINTS.WEBHOOKS.BANK_VIETQR, { content, amount });
    return res.data;
  },
};

