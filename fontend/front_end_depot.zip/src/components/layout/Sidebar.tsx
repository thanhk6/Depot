import React from 'react';
import { useAuth } from '../../app/providers/AuthProvider';
import {
  LayoutDashboard,
  LogIn,
  ClipboardCheck,
  Droplets,
  CreditCard,
  Container,
  MapPin,
  Grid3X3,
  Truck,
  Calculator,
  ShieldCheck,
  Wrench,
  CheckCircle2,
  Warehouse,
  FileSpreadsheet,
  BarChart3,
  Layers,
  Settings,
  GitBranch,
  Boxes,
  Lock,
  Tag,
  Building2,
  Users,
  Receipt,
  FileCode,
  Hammer,
  Sparkles,
  Radio,
  Send,
  LogOut,
  Smartphone,
  X,
  Activity,
  Clock,
  Ship,
  FileText
} from 'lucide-react';

export interface MenuItem {
  id: string;
  label: string;
  icon: React.ReactNode;
  badge?: string;
  badgeColor?: string;
}

export interface MenuGroup {
  title: string;
  items: MenuItem[];
}

interface SidebarProps {
  activeTab: string;
  onSelectTab: (tabId: string) => void;
  isOpen?: boolean;
  isMobileOpen?: boolean;
  onCloseMobile?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  isOpen = false,
  isMobileOpen,
  onCloseMobile
}) => {
  const isDrawerOpen = isMobileOpen !== undefined ? isMobileOpen : isOpen;
  const { currentRole } = useAuth();
  const menuGroups: MenuGroup[] = [
    {
      title: 'TỔNG QUAN',
      items: [
        {
          id: 'dashboard',
          label: 'Dashboard ERP',
          icon: <LayoutDashboard className="w-4 h-4 text-sky-400" />
        },
        {
          id: 'workflow',
          label: 'Sơ Đồ Vòng Đời Nghiệp Vụ',
          icon: <GitBranch className="w-4 h-4 text-cyan-400" />,
          badge: '15 Module'
        }
      ]
    },
    {
      title: 'KHAI THÁC & GATE-IN',
      items: [
        {
          id: 'gate',
          label: '1. Tiếp Nhận Cổng (Gate-In)',
          icon: <LogIn className="w-4 h-4 text-emerald-400" />,
          badge: 'EDI'
        },
        {
          id: 'survey',
          label: '2. Giám Định (Survey e-EIR)',
          icon: <ClipboardCheck className="w-4 h-4 text-amber-400" />,
          badge: 'IICL-6'
        },
        {
          id: 'cleaning',
          label: '3. Tổ Vệ Sinh (Cleaning Bay)',
          icon: <Droplets className="w-4 h-4 text-cyan-300" />,
          badge: 'CL'
        },
        {
          id: 'operation',
          label: '4. Khai Thác Gate-In (Tariff)',
          icon: <FileSpreadsheet className="w-4 h-4 text-blue-400" />,
          badge: 'Khai Thác'
        },
        {
          id: 'payment',
          label: '5. Thanh Toán VietQR',
          icon: <CreditCard className="w-4 h-4 text-purple-400" />,
          badge: 'Napas247'
        }
      ]
    },
    {
      title: 'QUẢN LÝ CONTAINER & BÃI',
      items: [
        {
          id: 'container',
          label: 'Danh Sách Container',
          icon: <Boxes className="w-4 h-4 text-sky-400" />
        },
        {
          id: 'yard_map',
          label: 'Sơ Đồ Bãi 2D (Konva)',
          icon: <MapPin className="w-4 h-4 text-teal-400" />
        },
        {
          id: 'yard_blocks',
          label: 'Quản Lý Vị Trí Block',
          icon: <Grid3X3 className="w-4 h-4 text-indigo-400" />
        },
        {
          id: 'forklift',
          label: 'Lệnh Điều Xe Nâng',
          icon: <Truck className="w-4 h-4 text-amber-400" />,
          badge: 'Tablet'
        }
      ]
    },
    {
      title: 'BÁO GIÁ & SỬA CHỮA',
      items: [
        {
          id: 'estimate',
          label: 'Lập Báo Giá Estimate',
          icon: <Calculator className="w-4 h-4 text-orange-400" />,
          badge: 'IICL-5'
        },
        {
          id: 'approval',
          label: 'Phê Duyệt Hãng Tàu',
          icon: <ShieldCheck className="w-4 h-4 text-pink-400" />,
          badge: 'MNR'
        },
        {
          id: 'repair',
          label: 'Lệnh Sửa Chữa (WO)',
          icon: <Wrench className="w-4 h-4 text-rose-400" />,
          badge: 'Kanban'
        },
        {
          id: 'qc',
          label: '9. QC Nghiệm Thu (AV Grade)',
          icon: <CheckCircle2 className="w-4 h-4 text-emerald-400" />,
          badge: 'AV'
        },
        {
          id: 'shipping_api',
          label: '10. Truyền API Hãng Tàu',
          icon: <Radio className="w-4 h-4 text-sky-400" />,
          badge: 'REST API',
          badgeColor: 'bg-sky-950 text-sky-300 border-sky-800'
        }
      ]
    },
    {
      title: 'CỔNG XUẤT & CẤP VỎ (GATE-OUT)',
      items: [
        {
          id: 'gate_out',
          label: '11. Tổng Quan Cổng Xuất',
          icon: <LayoutDashboard className="w-4 h-4 text-indigo-400" />,
          badge: 'Dashboard',
          badgeColor: 'bg-indigo-950 text-indigo-300 border-indigo-800'
        },
        {
          id: 'gate_out_ready',
          label: '1. Vỏ Chờ Cấp (Ready In Yard)',
          icon: <Ship className="w-4 h-4 text-cyan-400" />,
          badge: 'AV Grade'
        },
        {
          id: 'gate_out_lane',
          label: '2. Tiếp Nhận Làn Cổng Xuất',
          icon: <Truck className="w-4 h-4 text-emerald-400" />,
          badge: 'Làn 03/04'
        },
        {
          id: 'gate_out_history',
          label: '3. Nhật Ký Xuất & Phiếu e-EIR',
          icon: <FileText className="w-4 h-4 text-sky-400" />,
          badge: 'e-EIR'
        }
      ]
    },
    {
      title: 'CÔNG NỢ HÃNG TÀU & BILLING',
      items: [
        {
          id: 'billing',
          label: 'Công Nợ Hãng Tàu (AR)',
          icon: <FileSpreadsheet className="w-4 h-4 text-sky-400" />,
          badge: 'SOA & VAT',
          badgeColor: 'bg-sky-950 text-sky-300 border-sky-800'
        }
      ]
    },
    {
      title: 'KHO VẬT TƯ & CƠ SỞ VẬT CHẤT',
      items: [
        {
          id: 'warehouse',
          label: 'Kho Vật Tư Sửa Chữa EMR',
          icon: <Warehouse className="w-4 h-4 text-amber-300" />,
          badge: 'Tồn Kho',
          badgeColor: 'bg-amber-950 text-amber-300 border-amber-800'
        }
      ]
    },
    {
      title: 'DANH MỤC MASTER DATA',
      items: [
        {
          id: 'master_data',
          label: 'Tất Cả Danh Mục',
          icon: <Layers className="w-4 h-4 text-indigo-400" />,
          badge: 'Core'
        },
        {
          id: 'departments',
          label: 'DM Phòng Ban Depot',
          icon: <Building2 className="w-4 h-4 text-indigo-400" />,
          badge: '12 Khối'
        },
        {
          id: 'tariff_services',
          label: 'Cước Nâng Hạ & Lưu Bãi',
          icon: <Receipt className="w-4 h-4 text-emerald-400" />,
          badge: 'Giá Tiền'
        },
        {
          id: 'cleaning_tariffs',
          label: 'Biểu Phí Vệ Sinh Container',
          icon: <Droplets className="w-4 h-4 text-cyan-400" />,
          badge: '10 Loại'
        },
        {
          id: 'container_types',
          label: 'DM Loại Container (ISO)',
          icon: <Container className="w-4 h-4 text-sky-400" />,
          badge: '14 Loại'
        },
        {
          id: 'damage_locations',
          label: 'DM Vị Trí Cấu Kiện',
          icon: <MapPin className="w-4 h-4 text-amber-400" />
        },
        {
          id: 'damage_codes',
          label: 'DM Mã Hư Hỏng IICL',
          icon: <FileCode className="w-4 h-4 text-rose-400" />
        },
        {
          id: 'repair_codes',
          label: 'DM Phương Án Sửa Chữa',
          icon: <Hammer className="w-4 h-4 text-blue-400" />
        },
        {
          id: 'grades',
          label: 'DM Phân Hạng Vỏ (Grade)',
          icon: <Sparkles className="w-4 h-4 text-emerald-400" />
        },
        {
          id: 'standards',
          label: 'DM Tiêu Chuẩn Giám Định',
          icon: <ShieldCheck className="w-4 h-4 text-purple-400" />
        }
      ]
    },
    {
      title: 'KHÁCH HÀNG & ĐỐI TÁC',
      items: [
        {
          id: 'customer_list',
          label: 'Khách Hàng (Trucking & FWD)',
          icon: <Truck className="w-4 h-4 text-amber-400" />,
          badge: '5 Đơn Vị'
        },
        {
          id: 'customer_classifications',
          label: 'DM Phân Loại Khách Hàng',
          icon: <Tag className="w-4 h-4 text-pink-400" />,
          badge: '5 Phân Loại'
        },
        {
          id: 'shipping_lines',
          label: 'Hãng Tàu (Maersk Line)',
          icon: <Building2 className="w-4 h-4 text-sky-400" />,
          badge: 'Độc Quyền'
        }
      ]
    },
    {
      title: 'ZALO GATEWAY & CHAT',
      items: [
        {
          id: 'zalo_overview',
          label: 'Tổng Quan Zalo OA',
          icon: <Radio className="w-4 h-4 text-emerald-400" />,
          badge: 'Online',
          badgeColor: 'bg-emerald-950 text-emerald-300 border-emerald-800'
        },
        {
          id: 'zalo_simulator',
          label: 'Zalo Simulator & Chat',
          icon: <Smartphone className="w-4 h-4 text-yellow-400 animate-pulse" />,
          badge: '2 Chiều',
          badgeColor: 'bg-yellow-950 text-yellow-300 border-yellow-800'
        },
        {
          id: 'zalo_templates',
          label: 'Mẫu Tin ZNS & OA',
          icon: <FileCode className="w-4 h-4 text-amber-400" />,
          badge: '12 Mẫu'
        },
        {
          id: 'zalo_settings',
          label: 'Cấu Hình Zalo OA & Token',
          icon: <Settings className="w-4 h-4 text-cyan-400" />
        },
        {
          id: 'zalo_logs',
          label: 'Nhật Ký Webhook & API',
          icon: <Receipt className="w-4 h-4 text-purple-400" />
        }
      ]
    },
    {
      title: 'HỆ THỐNG THÔNG BÁO TỔNG HỢP',
      items: [
        {
          id: 'notifications',
          label: 'Dashboard Thông Báo',
          icon: <Radio className="w-4 h-4 text-sky-400" />
        },
        {
          id: 'notifications_send',
          label: 'Gửi Thông Báo Mới',
          icon: <Send className="w-4 h-4 text-emerald-400" />
        },
        {
          id: 'notifications_employees',
          label: 'Thông Báo Nhân Viên',
          icon: <Users className="w-4 h-4 text-blue-400" />
        },
        {
          id: 'notifications_customers',
          label: 'Thông Báo Khách Hàng',
          icon: <Building2 className="w-4 h-4 text-indigo-400" />
        },
        {
          id: 'notifications_templates',
          label: 'Thư Viện Mẫu Tin',
          icon: <FileCode className="w-4 h-4 text-amber-400" />,
          badge: '16 Mẫu'
        },
        {
          id: 'notifications_history',
          label: 'Lịch Sử Gửi Toàn Hệ Thống',
          icon: <Receipt className="w-4 h-4 text-cyan-400" />
        },
        {
          id: 'notifications_queue',
          label: 'Hàng Đợi Gửi (Queue)',
          icon: <Layers className="w-4 h-4 text-pink-400" />,
          badge: '5'
        }
      ]
    },
    {
      title: 'BÁO CÁO & HIỆU SUẤT NHÂN SỰ',
      items: [
        {
          id: 'report_staff_realtime',
          label: '⚡ Công Việc Từng Người (Real-time)',
          icon: <Activity className="w-4 h-4 text-amber-400" />,
          badge: 'Live'
        },
        {
          id: 'report',
          label: 'Tổng Quan & Thông Lượng Bãi',
          icon: <BarChart3 className="w-4 h-4 text-cyan-400" />
        },
        {
          id: 'report_emr',
          label: 'Năng Suất Sửa Chữa EMR',
          icon: <Wrench className="w-4 h-4 text-emerald-400" />
        },
        {
          id: 'report_dwell_time',
          label: 'Thời Gian Lưu Bãi (Dwell Time)',
          icon: <Clock className="w-4 h-4 text-sky-400" />
        },
        {
          id: 'report_revenue',
          label: 'Doanh Thu & Biểu Cước',
          icon: <CreditCard className="w-4 h-4 text-teal-400" />
        }
      ]
    },
    {
      title: 'HỆ THỐNG & PHÂN QUYỀN',
      items: [
        {
          id: 'system',
          label: 'Phân Quyền RBAC & Users',
          icon: <Settings className="w-4 h-4 text-purple-400" />
        }
      ]
    }
  ];

  const renderSidebarContent = (isMobile = false) => (
    <div className="flex flex-col h-full overflow-hidden">
      {/* Brand Header */}
      <div className="h-16 px-4 border-b border-slate-800 flex items-center justify-between bg-[#070d1f] shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-sky-500 to-blue-600 p-0.5 flex items-center justify-center shadow-lg shadow-sky-500/20">
            <div className="w-full h-full bg-[#0a1128] rounded-[10px] flex items-center justify-center">
              <Boxes className="w-5 h-5 text-sky-400" />
            </div>
          </div>
          <div>
            <h1 className="font-extrabold text-sm text-white tracking-wide font-mono">
              EMR WORKFLOW 2026
            </h1>
            <p className="text-[10px] text-sky-400 font-bold tracking-widest uppercase">
              Depot Core v3.5
            </p>
          </div>
        </div>
        {isMobile && (
          <button
            onClick={onCloseMobile}
            className="p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition cursor-pointer"
            aria-label="Đóng menu"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* Role Selector Box */}
      <div
        onClick={() => {
          onSelectTab('system');
          if (isMobile && onCloseMobile) onCloseMobile();
        }}
        className="px-4 py-2.5 bg-[#091024] hover:bg-[#0c1633] border-b border-slate-800/80 flex items-center justify-between gap-2 shrink-0 cursor-pointer transition"
        title="Bấm để mở cấu hình Phân Quyền & Người Dùng"
      >
        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
          VAI TRÒ:
        </span>
        <div className="px-2.5 py-1 rounded-lg bg-purple-950/60 border border-purple-500/40 text-purple-300 font-bold text-xs shadow-inner truncate max-w-[140px]">
          {currentRole.name}
        </div>
      </div>

      {/* Navigation Menu */}
      <div className="p-3 space-y-4 overflow-y-auto flex-1 scrollbar-thin">
        {menuGroups.map((group, idx) => (
          <div key={idx} className="space-y-1">
            <div className="px-3 text-[10px] font-extrabold text-slate-500 tracking-wider uppercase">
              {group.title}
            </div>
            <div className="space-y-0.5">
              {group.items.map((item) => {
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      onSelectTab(item.id);
                      if (onCloseMobile) onCloseMobile();
                    }}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition cursor-pointer group ${
                      isActive
                        ? 'bg-sky-500 text-white shadow-lg shadow-sky-500/25 font-bold'
                        : 'text-slate-300 hover:text-white hover:bg-slate-800/60 active:bg-slate-800'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <span className={`shrink-0 ${isActive ? 'text-white' : ''}`}>
                        {item.icon}
                      </span>
                      <span className="truncate">{item.label}</span>
                    </div>
                    {item.badge && (
                      <span
                        className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded whitespace-nowrap ml-1.5 ${
                          isActive
                            ? 'bg-white/20 text-white'
                            : 'bg-slate-800 text-slate-400 border border-slate-700/80'
                        }`}
                      >
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Footer Info */}
      <div className="p-3 border-t border-slate-800 bg-[#070d1f] text-center shrink-0">
        <p className="text-[11px] font-bold text-slate-300 font-mono tracking-wide">
          SOLUTION DEPOT ERP v3.5
        </p>
        <p className="text-[9px] text-slate-500">Automated EMR & Yard System</p>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex w-64 bg-[#0a1128] border-r border-slate-800 text-slate-200 flex-col justify-between h-screen shrink-0 sticky top-0 z-40 select-none">
        {renderSidebarContent(false)}
      </aside>

      {/* Mobile Drawer */}
      {isDrawerOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm transition-opacity"
            onClick={onCloseMobile}
          />
          <aside className="relative w-72 max-w-[85vw] bg-[#0a1128] border-r border-slate-800 text-slate-200 flex flex-col justify-between h-full z-10 shadow-2xl select-none">
            {renderSidebarContent(true)}
          </aside>
        </div>
      )}
    </>
  );
};
